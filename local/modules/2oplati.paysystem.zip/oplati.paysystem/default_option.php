<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$oplati_payment_default_option = array(
    "payment_confirm_await_time" => "30",
);
