<?defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['IM_PG_MODULE_MODULE_NAME'] = 'Платёжная система Белгазпромбанк (BGPB Payment)';
$MESS['IM_PG_MODULE_MODULE_DESCRIPTION'] = 'Онлайн платежи для вашего сайта';
$MESS ['IM_PG_MODULE_PARTNER_NAME'] = 'БелГазПромБанк';

$MESS ['IM_PG_MODULE_DENIED'] = 'доступ закрыт';
$MESS ['IM_PG_MODULE_VIEW'] = 'просмотр всей статистики';
$MESS ['IM_PG_MODULE_ADMIN'] = 'полный административный доступ';