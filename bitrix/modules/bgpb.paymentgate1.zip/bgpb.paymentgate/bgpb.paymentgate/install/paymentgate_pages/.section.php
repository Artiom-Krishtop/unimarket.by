<?
$sSectionName = 'BGPB Payment';
$arDirProperties = Array(

);