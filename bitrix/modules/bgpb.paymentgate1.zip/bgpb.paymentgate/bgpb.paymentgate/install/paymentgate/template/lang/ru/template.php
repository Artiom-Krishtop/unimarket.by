<?php
$MESS['SALE_HPS_PAYMENTGATE_PAY'] = 'Оплатить';
$MESS['PAYMENT_GATE_ORDER_STATUS_0'] = 'Заказ зарегистрирован, но не оплачен';
$MESS['PAYMENT_GATE_ORDER_STATUS_2'] = 'Проведена полная авторизация суммы заказа';
$MESS['PAYMENT_GATE_ORDER_STATUS_3'] = 'Авторизация отменена';
$MESS['PAYMENT_GATE_ORDER_STATUS_4'] = 'По транзакции была проведена операция возврата';
$MESS['PAYMENT_GATE_ORDER_STATUS_5'] = 'Инициирована авторизация через ACS банка-эмитента';
$MESS['PAYMENT_GATE_ORDER_STATUS_6'] = 'Авторизация отклонена';
$MESS['BINDING_SELECT_LABEL'] = 'Выберите карту для оплаты';
$MESS['BINDING_OTHER_CART_LABEL'] = 'Другая';