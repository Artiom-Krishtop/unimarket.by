<?
$MESS['SALE_HPS_PAYMENTGATE_TEST'] = 'тестовый режим';
$MESS['SALE_HPS_PAYMENTGATE_BINDING'] = 'Использовать режим связок';
$MESS['SALE_HPS_PAYMENTGATE_ORDER_ID_ERROR'] = 'Ошибка идентификатора заказа';
$MESS['SALE_HPS_PAYMENTGATE_ALREADY_PAID'] = 'Оплата уже проведена';
$MESS['SALE_HPS_PAYMENTGATE_SUM_OR_ID_ERROR'] = 'Неверная сумма или идентификатор платежа';
$MESS['SALE_HPS_PAYMENTGATE_MODULE_NOT_FOUND'] = 'Модуль Белгазпромбанк (BGPB Payment) не найден';
$MESS['SALE_HPS_PAYMENTGATE_UNKNOWN_ERROR'] = 'Ошибка платёжной системы';
$MESS['SALE_HPS_PAYMENTGATE_BINDING_NOT_FOUNDED'] = 'Карта не найдена';
$MESS['SALE_HPS_PAYMENTGATE_STATUS_0'] = 'Заказ зарегистрирован, но не оплачен';
$MESS['SALE_HPS_PAYMENTGATE_STATUS_2'] = 'Заказ оплачен. Благодарим Вас за покупку!';
$MESS['SALE_HPS_PAYMENTGATE_STATUS_3'] = 'Авторизация отменена';
$MESS['SALE_HPS_PAYMENTGATE_STATUS_4'] = 'По транзакции была проведена операция возврата';
$MESS['SALE_HPS_PAYMENTGATE_STATUS_5'] = 'Инициирована авторизация через ACS банка-эмитента';
$MESS['SALE_HPS_PAYMENTGATE_STATUS_6'] = 'Авторизация отклонена';
$MESS['SALE_HPS_PAYMENTGATE_STATUS_OK'] = 'Заказ успешно обновлен';