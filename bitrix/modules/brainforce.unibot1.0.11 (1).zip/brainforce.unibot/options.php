<?php

/** @global $APPLICATION */
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/brainforce.unibot/autoload.php');

use Bitrix\Main\ArgumentNullException;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\HttpApplication;
use Bitrix\Main\Config\Option;
use UNI\Core\Main;
use UNI\Models\UserModel;

Loc::loadMessages(__FILE__);

$request = HttpApplication::getInstance()->getContext()->getRequest();

$module_id = htmlspecialcharsbx($request["mid"] != "" ? $request["mid"] : $request["id"]);

try {
    $arOptions = Option::getForModule($module_id, 'arOptions');
} catch (ArgumentNullException $e) {
    var_dump($e->getMessage());
    die();
}

if (strlen($arOptions['BOT_TOKEN'])) {

    $token = trim($arOptions['BOT_TOKEN']);
    /* Обозначаем вебхук по умолчанию */
    $default_webhook = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . "/local/unibot/hook.php";
    /* Проверяем заполнен ли кастомный урл */
    $required_webhook_url = $arOptions['WEBHOOK_URL'] ?: $default_webhook;

    $bot_main = new Main();
    /* Проверяем установлен ли вебхук */
    $webhook = $bot_main->get_webhook_info();
    if ($webhook['ok']) {
        /* Если установлен, проверяем урл */
        $current_webhook_url = $webhook['result']['url'];
        /* Если урлы разные, ставим на нужный */
        if ($current_webhook_url !== $required_webhook_url) {
            $bot_main->set_webhook($required_webhook_url, $token);
        }
    } else {
        $bot_main->set_webhook($required_webhook_url, $token);
    }
}


//For paid modules only BEGIN
$isExpired = CModule::IncludeModuleEx($module_id);
if ($isExpired != 4) {
//For paid modules only END

    $users_model = new UserModel();
    $users = $users_model->get_all();

    $aUsersValues = [
        0 => 'Не выбрано'
    ];
    foreach ($users as $user) {
        $aUsersValues[$user['ID']] = $user['UF_USERNAME'];
    }

    $aTabs = array(
        array(
            "DIV" => "edit",
            "TAB" => Loc::getMessage("BRAINFORCE_UNIBOT_OPTIONS_TAB_COMMON"),
            "TITLE" => Loc::getMessage("BRAINFORCE_UNIBOT_OPTIONS_TAB_NAME"),
            "OPTIONS" => array(
                Loc::getMessage("BRAINFORCE_UNIBOT_OPTIONS_MAIN"),
                array(
                    "BOT_TOKEN",
                    Loc::getMessage("BRAINFORCE_UNIBOT_OPTIONS_BOT_TOKEN"),
                    '',
                    array("text", 60)
                ),
                array(
                    "ID_MODERATOR",
                    Loc::getMessage("BRAINFORCE_UNIBOT_OPTIONS_BOT_MODERATOR"),
                    '',
                    array("selectbox", $aUsersValues)
                )
            )
        )
    );
    if ($request->isPost() && check_bitrix_sessid()) {

        foreach ($aTabs as $aTab) {

            foreach ($aTab["OPTIONS"] as $arOption) {

                if (!is_array($arOption)) {

                    continue;
                }

                if ($arOption["note"]) {

                    continue;
                }

                if ($request["apply"]) {

                    $optionValue = $request->getPost($arOption[0]);

                    if ($arOption[0] == "switch_on") {

                        if ($optionValue == "") {

                            $optionValue = "N";
                        }
                    }


                    Option::set($module_id, $arOption[0], is_array($optionValue) ? implode(",", $optionValue) : $optionValue);
                } elseif ($request["default"]) {
                    Option::set($module_id, $arOption[0], $arOption[2]);
                }
            }
        }

        LocalRedirect($APPLICATION->GetCurPage() . "?mid=" . $module_id . "&lang=" . LANG);
    }


    $tabControl = new CAdminTabControl(
        "tabControl",
        $aTabs
    );

    $tabControl->Begin();
    ?>
    <form action="<?php echo($APPLICATION->GetCurPage()); ?>?mid=<?php echo($module_id); ?>&lang=<?php echo(LANG); ?>"
          method="post" id="setparams">
        <?php
        foreach ($aTabs as $aTab) {

            if ($aTab["OPTIONS"]) {

                $tabControl->BeginNextTab();

                __AdmSettingsDrawList($module_id, $aTab["OPTIONS"]);
            }
        }
        $tabControl->Buttons();
        ?>
        <input type="submit" name="apply" value="<?php echo(Loc::GetMessage("BRAINFORCE_UNIBOT_OPTIONS_APPLY")); ?>"
               class="adm-btn-save"/>
        <?php
        echo(bitrix_sessid_post());
        ?>

    </form>
    <?php
    $tabControl->End();
    ?>
    <?php //For paid modules only BEGIN ?>
<?php } else {
    echo Loc::GetMessage("BRAINFORCE_TIM_EXPIRED");
}
?>
<?php //For paid modules only END ?>