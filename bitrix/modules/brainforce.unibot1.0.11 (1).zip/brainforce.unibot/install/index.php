<?php

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Entity\Base;
use Bitrix\Main\Application;
use Bitrix\Main\ModuleManager;

Loc::loadMessages(__FILE__);

class brainforce_unibot extends CModule
{

    var $MODULE_ID = "brainforce.unibot";

    public function __construct()
    {
        if (file_exists(__DIR__ . "/version.php")) {

            $arModuleVersion = [];
            include __DIR__ . '/version.php';

            $this->MODULE_ID = "brainforce.unibot";
            $this->MODULE_VERSION = $arModuleVersion["VERSION"];
            $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];

            $this->MODULE_NAME = Loc::getMessage('BRAINFORCE_UNIBOT_NAME');
            $this->MODULE_DESCRIPTION = Loc::getMessage('BRAINFORCE_UNIBOT_MODULE_DESCRIPTION');
            $this->PARTNER_NAME = Loc::getMessage("BRAINFORCE_UNIBOT_PARTNER_NAME");
            $this->PARTNER_URI = Loc::getMessage("BRAINFORCE_UNIBOT_PARTNER_URI");
        }
        return false;
    }

    public function DoInstall(): bool
    {
        global $APPLICATION;

        if (CheckVersion(ModuleManager::getVersion("main"), "14.00.00")) {

            ModuleManager::registerModule($this->MODULE_ID);
            $this->InstallDB();
            $this->InstallFiles();

        } else {

            $APPLICATION->ThrowException(Loc::getMessage("BRAINFORCE_UNIBOT_ERROR_VERSION"));
        }

        $APPLICATION->IncludeAdminFile(
            "Установка завершена \"" . Loc::getMessage("BRAINFORCE_UNIBOT_NAME") . "\"",
            __DIR__ . "/step.php"
        );

        return true;
    }

    public function InstallFiles(): bool
    {
        /* Создаем нужные папки */
        $dirs = [
            '/local',
            '/local/Unibot',
            '/unibot',
        ];

        foreach ($dirs as $dir) {
            if (!is_dir($_SERVER['DOCUMENT_ROOT'] . $dir)) {
                mkdir($_SERVER['DOCUMENT_ROOT'] . $dir);
            }
        }

        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/unibot/local", $_SERVER["DOCUMENT_ROOT"] . "/local/Unibot", true, true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/unibot/root", $_SERVER["DOCUMENT_ROOT"] . "/unibot", true, true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/themes", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/themes", true, true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/admin", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin", true, true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/js", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/js/brainforce.unibot", true, true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/css", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/css/brainforce.unibot", true, true);

        return true;
    }

    public function InstallDB()
    {
        Loader::includeModule($this->MODULE_ID);

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\BotTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\BotTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\DefaultMessageTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\DefaultMessageTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\DialogTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\DialogTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\InlineTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\InlineTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\MenuTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\MenuTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\MessageTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\MessageTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\MessageTemplateTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\MessageTemplateTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\OrderTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\OrderTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\ReplyTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\ReplyTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\SegmentTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\SegmentTable')->createDbTable();
        }

        if (!Application::getConnection()->isTableExists(
            Base::getInstance('\Brainforce\Unibot\Orm\UserTable')->getDBTableName()
        )) {
            Base::getInstance('\Brainforce\Unibot\Orm\UserTable')->createDbTable();
        }

    }

    public function InstallEvents(): bool
    {
        return true;
    }

    public function DoUninstall()
    {
        global $APPLICATION;
        $this->UnInstallFiles();
        //$this->UnInstallDB();
        ModuleManager::unRegisterModule($this->MODULE_ID);

        $APPLICATION->IncludeAdminFile(
            "Модуль удален \"" . Loc::getMessage("BRAINFORCE_UNIBOT_NAME") . "\"",
            __DIR__ . "/unstep.php"
        );

    }

    public function UnInstallFiles(): bool
    {
        //DeleteDirFilesEx("/local/Unibot");
        //DeleteDirFilesEx("/unibot");
        DeleteDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/admin", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/admin");
        DeleteDirFiles($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/install/themes/.default/", $_SERVER["DOCUMENT_ROOT"] . "/bitrix/themes/.default");//css

        return true;
    }

    public function UnInstallDB()
    {
        Loader::includeModule($this->MODULE_ID);

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\BotTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\DefaultMessageTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\DialogTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\InlineTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\MenuTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\MessageTemplateTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\OrderTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\ReplyTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\SegmentTable')->getDBTableName());

        Application::getConnection()->
        queryExecute('drop table if exists ' . Base::getInstance('\Brainforce\Unibot\Orm\UserTable')->getDBTableName());

    }

    public function UnInstallEvents(): bool
    {
        return true;
    }
}