<?php
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/admin/unibot_admin.php");
?>