<?php
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/admin/buttons/add_button_ajax.php");
?>