<?php
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/admin/messages/add_message.php");
?>