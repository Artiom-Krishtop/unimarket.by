<?php

namespace Unibot\Framework\Command;

use Symfony\Component\Console\Input\InputArgument;

class MakeCommandCommand extends GenerateCommand
{
    // the name of the command (the part after "bin/console")
    protected static $defaultName = 'make:command';
    public static $type = "Command";

    public static function getStub()
    {
        return file_get_contents(__DIR__. "/../stubs/command.stub");
    }


}