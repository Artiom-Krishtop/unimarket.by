<?php

namespace Unibot\Framework\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

abstract class GenerateCommand extends Command
{

    protected function configure(): void
    {
        $this->addArgument('name', InputArgument::REQUIRED);
    }

    protected static function makeDir($dirname) {
        mkdir(__DIR__."/../../app/".$dirname."s");
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {

        $stub = static::getStub();
        $type = static::$type;

        if(!is_dir(__DIR__."/../../app/".$type."s")) {
            self::makeDir($type);
        }

        $stub = str_replace('{{ class }}', $input->getArgument('name'), $stub);
        file_put_contents(__DIR__."/../../app/".$type."s/".$input->getArgument('name').".php", $stub);

        echo "\n=============\n";
        echo $type." ". $input->getArgument('name'). " created. Update in app/" . $type . "s.";
        echo "\n=============\n\n";

        return Command::SUCCESS;

    }
}