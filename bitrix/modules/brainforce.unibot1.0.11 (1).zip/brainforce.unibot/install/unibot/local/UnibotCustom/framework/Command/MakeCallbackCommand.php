<?php

namespace Unibot\Framework\Command;

use Symfony\Component\Console\Input\InputArgument;

class MakeCallbackCommand extends GenerateCommand
{
    // the name of the command (the part after "bin/console")
    protected static $defaultName = 'make:callback';
    public static $type = "Callback";

    public static function getStub()
    {
        return file_get_contents(__DIR__. "/../stubs/callback.stub");
    }


}