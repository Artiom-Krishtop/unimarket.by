<?php
/** @global $APPLICATION */
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

$APPLICATION->ShowHead();

use Bitrix\Main\UI\Extension;

Extension::load("ui.vue");

?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="/https://fonts.googleapis.com/icon?family=Material+Icons">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">

<style>
    .body {
        background: #F1FAEE;
    }

    .config_wrapper {

        margin-top: 50px;
        display: flex;
        flex-direction: column;
        align-items: center;
        font-family: 'Open Sans', sans-serif;
        color: #1D3557;

    }

    .select_wrapper {

        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 500px;

    }

    .select_title {

        font-size: 36px;
        font-weight: bold;
        margin-bottom: 15px;

    }

    .select_input {

        font-family: 'Open Sans', sans-serif;
        width: 500px;
        height: 35px;

        border-radius: 5px;
        padding: 0 15px;
        font-size: 16px;

        outline: none;

    }

    .result_item {
        padding: 20px;
        border: 1px solid;
        border-radius: 15px;
        margin-top: 25px;
        width: 700px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .result_item--success {
        border-color: lightgreen;
        background-color: rgba(144, 238, 144, 0.3);
    }

    .result_item--error {
        border-color: crimson;
        background-color: rgba(220, 20, 60, 0.3);
    }

    .result_item--warning {
        border-color: khaki;
        background-color: rgba(240, 230, 140, 0.3);
    }


</style>

<div id="uniconfig" class="config_wrapper">
    <div class="select_wrapper">
        <div class="select_title">Выберите бота</div>
        <select class="select_input" v-model="bot_id">
            <option class="select_option" value="">Не выбрано</option>
            <option class="select_option" v-for="bot in bot_list" v-bind:value="bot.ID">{{ bot.UF_NAME }}</option>
        </select>
    </div>

    <div class="result_container" v-if="bot_data">
        <div v-for="check in bot_data">
            <div class="result_item result_item--error" v-if="check.error">
                <div class="result_text">{{ check.error }}</div>
                <div class="result_icon--error"><img src="svg/close_black_24dp.svg"></div>
            </div>
            <div class="result_item result_item--success" v-if="check.success">
                <div class="result_text">{{ check.success }}</div>
                <div class="result_icon--success"><img src="svg/done_black_24dp.svg"></div>
            </div>
            <div class="result_item result_item--warning" v-if="check.warning">
                <div class="result_text">{{ check.warning }}</div>
                <div class="result_icon--warning"><img src="svg/warning_black_24dp.svg"></div>
            </div>
        </div>
    </div>
    <div v-if="is_drop_updates">
        <button v-on:click="drop_updates">Сбросить</button>
    </div>
</div>

<script>
    const uniconfig = BX.Vue.create({

        el: '#uniconfig',

        data: {
            bot_list: [],
            bot_id: '',
            bot_data: null,
            is_drop_updates: false,
        },

        methods: {

            post: async function (url, data) {
                const response = await fetch(url, {
                    method: 'POST',
                    body: data
                })
                return response.json();
            },

            get: async function (url) {
                const response = await fetch(url, {
                    method: 'GET',
                })
                return response.json();
            },

            get_bot_data: function () {
                let data = new FormData;
                data.append('bot_id', this.bot_id)

                this.post('/unibot/ajax.php', data)
                    .then((data) => {

                        this.is_drop_updates = !!data.pending_update_count.warning;

                        if (!data.error) {
                            this.bot_data = data
                        }

                        console.log(this.bot_data);

                    })
            },

            drop_updates: function () {
                let data = new FormData
                data.append('drop', '1');
                data.append('bot_id', this.bot_id)
                this.post('/unibot/ajax.php', data)
                    .then((data) => {
                        if (!data.error) {
                            this.bot_data = data
                        }
                        console.log(this.bot_data);
                        this.get_bot_data()
                    })

            },

            get_bots: function () {

                let data = new FormData
                data.append('get_bots', 1);

                this.post('/unibot/ajax.php', data)
                    .then((data) => {
                        if (!data.error) {
                            this.bot_list = data
                        }
                        console.log(this.bot_list);
                    })
            }


        },

        created: function () {

            this.get_bots()

        },

        watch: {
            bot_id: function () {
                if (this.bot_id !== '') {
                    this.get_bot_data()
                }
            }
        }

    })
</script>