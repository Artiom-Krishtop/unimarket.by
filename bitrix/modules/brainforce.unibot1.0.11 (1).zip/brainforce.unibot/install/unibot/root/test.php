<?php

require_once ($_SERVER['DOCUMENT_ROOT'] . "/bitrix/modules/brainforce.unibot/admin/uni_info.php");

$check = new UnibotInfo(2);

echo "<pre>";
var_dump($check->return_result());
echo "</pre>";
