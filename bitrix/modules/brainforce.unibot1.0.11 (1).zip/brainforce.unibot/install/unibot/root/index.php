<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
use Bitrix\Main\Config\Option;

$bot_options = Option::getForModule('brainforce.unibot', 'arOptions');
?>

<style>
    .uni_button {
        background-color: #A8DADC;
        padding: 10px 25px;
        border-radius: 50vmin;
        text-decoration: none;
        box-shadow: 0 5px 5px grey;
        border: 0;
        cursor: pointer;
        font-weight: 500;
        color: #457B9D;
    }

    .uni_button:hover {
        color: #1D3557;
    }

    .uni_button:active {
        box-shadow: 0 2px 5px grey;
        transform: translate(0, 3px);
    }
</style>

<div class="container"
     style="min-height: calc(100vh - 16px) ; display: flex; align-items: center; justify-content: center; background-color: #F1FAEE">
    <a href="https://tele.click/<?=$bot_options['BOT_USERNAME']?>" class="uni_button"
       style="font-family: Montserrat, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size: 32px">
        Подключить UNI бот
    </a>
</div>

