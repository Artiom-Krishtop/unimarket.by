<?php
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
CModule::IncludeModule('brainforce.unibot');

use Brainforce\Unibot\Core\UnibotInfo;
use Brainforce\Unibot\Models\BotModel;

if (isset($_POST['get_bots'])) {

    try {
        $model = new BotModel();
        $bots = $model->get_all();
        echo json_encode($bots);
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
        die();
    }
}

if(isset($_POST['drop'])) {
    $config = new UnibotInfo($_POST['bot_id']);
    $config->drop_pending_updates();
}


if (isset($_POST['bot_id'])) {
    $config = new UnibotInfo($_POST['bot_id']);
    $data = $config->return_result();

    echo json_encode($data);
}


?>

