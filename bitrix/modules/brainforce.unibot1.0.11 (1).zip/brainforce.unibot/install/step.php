<?php
/** @global $APPLICATION */
use Bitrix\Main\Localization\Loc;
use Bitrix\Highloadblock\HighloadBlockTable as HLBT;
CModule::IncludeModule('highloadblock');

Loc::loadMessages(__FILE__);

if(!check_bitrix_sessid()){
    return;
}

if($errorException = $APPLICATION->GetException()){
    CAdminMessage::ShowMessage($errorException->GetString());
}else{
    CAdminMessage::ShowNote(Loc::getMessage("BRAINFORCE_UNIBOT_STEP_BEFORE")." ".Loc::getMessage("BRAINFORCE_UNIBOT_STEP_AFTER"));
}
?>

<form action="<?php echo($APPLICATION->GetCurPage()); ?>">
    <input type="hidden" name="lang" value="<?php echo(LANG); ?>" />
    <input type="submit" value="<?php echo(Loc::getMessage("BRAINFORCE_UNIBOT_STEP_SUBMIT_BACK")); ?>">
</form>