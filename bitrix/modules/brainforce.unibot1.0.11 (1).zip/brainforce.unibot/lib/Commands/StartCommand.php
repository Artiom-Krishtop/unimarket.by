<?php

namespace Brainforce\Unibot\Commands;

use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Dto\UserDto;
use Exception;
use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;

class StartCommand extends Command
{

    public function __construct(ParamsCollection $params)
    {
        $params->action = "/start";
        parent::__construct($params);
    }

    public function pre_handle(): bool
    {

        try {

            UserModel::get_users_by_chat_ids([$this->chat['id']], $this->bot['ID']);
            return true;

        } catch (Exception $e) {

            try {

                $segments = SegmentModel::get_to_link();

                $user_dto = new UserDto();
                $user_dto->name = $this->chat['first_name'] . " " . $this->chat['last_name'];
                $user_dto->username = $this->chat['username'] ?: $this->chat['id'];
                $user_dto->chat_id = $this->chat['id'];
                $user_dto->segment = $segments[$this->params]['ID']
                        ? [$segments[$this->params]['ID'], $segments['user']['ID']]
                        : [$segments['user']['ID']];
                $user_dto->date_registration = new DateTime();
                $user_dto->bot_id = $this->bot['ID'];

                UserModel::add($user_dto);

                return true;

            } catch (Exception $e) {

                return false;

            }

        }

    }

}