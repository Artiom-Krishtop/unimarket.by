<?php

namespace Brainforce\Unibot\Commands;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Controllers\CatalogController;
use Brainforce\Unibot\Core\Controller;

class CatalogCommand extends Command
{
    public function __construct(ParamsCollection $params)
    {
        parent::__construct($params);
    }

    public function handle(): bool
    {
        if ($this->bot['UF_IBLOCK_ID'] > 0) {
            Controller::log_telegram_errors(var_export($this->bot, true));
            $keyboard = CatalogController::create_catalog_keyboard($this->bot['UF_IBLOCK_ID']);
            Controller::log_telegram_errors(var_export($keyboard, true));
            $message = MessageController::create_message('*Каталог*', $this->chat['id'], $keyboard);

        } else {
            $message = MessageController::create_message('Нет каталога', $this->chat['id']);
        }
        $bot = new BotController($this->bot['UF_API_KEY']);
        $bot->send([$message]);

        return true;

    }
}