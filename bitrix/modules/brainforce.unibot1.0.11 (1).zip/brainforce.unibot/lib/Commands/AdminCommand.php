<?php

namespace Brainforce\Unibot\Commands;

use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;
use Exception;

class AdminCommand extends Command
{

    public function __construct($chat, $params)
    {
        parent::__construct($chat, "/admin", $params);
    }


    public function check(): bool
    {
        try {

            $segment_model = new SegmentModel();
            $admin = $segment_model->get_by_name('admin');

            $user_model = new UserModel();
            $user = $user_model->get_users_by_chat_ids([$this->chat['id']])[0];
            if (in_array($admin['ID'], $user['UF_SEGMENT'])) {

                return true;

            }

            return false;

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return false;

        }

    }

}