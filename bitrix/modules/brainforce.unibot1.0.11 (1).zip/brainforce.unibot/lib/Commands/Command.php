<?php

namespace Brainforce\Unibot\Commands;

use Brainforce\Unibot\Core\Controller;
use Exception;
use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Dto\MessageDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MessageModel;

class Command
{
    public $chat;
    private $command;
    public $params;
    public $bot;
    public $message_id;

    /**
     * @throws Exception
     */
    public function __construct(ParamsCollection $params)
    {

        $this->chat = $params->chat;
        $this->message_id = $params->message_id;
        $this->command = $params->action;
        $this->params = $params->parameter;
        $this->bot = $params->bot;

        if (!$this->check()) {
            throw new Exception('Check forbidden');
        }

        if (!$this->pre_handle()) {
            throw new Exception('Pre handle error');
        }

        if (!$this->handle()) {
            throw new Exception('Message not found');
        }

        if (!$this->post_handle()) {
            throw new Exception('Post handle error');
        }
    }

    protected function check(): bool
    {
        return true;
    }

    protected function pre_handle(): bool
    {
        return true;
    }

    protected function handle(): bool
    {
        try {

            $messages = MessageController::create_for_command($this->chat['id'], $this->bot['ID'], $this->command);
            $bot = new BotController($this->bot['UF_API_KEY']);
            $bot->send($messages);
            return true;

        } catch (Exception $e) {

            return false;

        }

    }

    protected function post_handle(): bool
    {
        return true;
    }
}