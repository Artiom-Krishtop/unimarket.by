<?php

namespace Brainforce\Unibot\Commands;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Controllers\CatalogController;
use Brainforce\Unibot\Controllers\OrderController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Models\UserModel;

class CartCommand extends Command
{
    public function __construct(ParamsCollection $params)
    {
        parent::__construct($params);
    }

    public function handle(): bool
    {

        $user = UserModel::get_users_by_chat_ids([$this->chat['id']], $this->bot['ID'])[0];
        $order_data = OrderController::get_user_order($this->bot['ID'], $user['ID']);

        if($order_data) {

            $button = ButtonsController::create_inline_button('Оформить заказ', ['callbackData' => 'MakeOrder ' . $order_data['order_id']]);
            $keyboard = ButtonsController::create_inline_keyboard([[$button]]);
            $message = MessageController::create_message($order_data['message'], $this->chat['id'], $keyboard);

        } else {

            $button = ButtonsController::create_inline_button('В каталог', ['callbackData' => 'Command /catalog' ]);
            $keyboard = ButtonsController::create_inline_keyboard([[$button]]);
            $message = MessageController::create_message("Корзина пуста", $this->chat['id'], $keyboard);

        }
        
        $bot = new BotController($this->bot['UF_API_KEY']);
        $bot->send([$message]);

        return true;

    }
}