<?php

namespace Brainforce\Unibot\Core;

abstract class Main
{
    public $site_root_path;

    public function __construct()
    {
        $this->site_root_path = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    }

}