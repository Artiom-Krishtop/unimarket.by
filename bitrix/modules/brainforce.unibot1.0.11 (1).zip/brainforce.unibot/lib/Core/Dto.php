<?php

namespace Brainforce\Unibot\Core;

abstract class Dto
{
    /**
     * @var int
     */
    public $id;

    /**
     * @var bool
     */
    public $filtered;

    /**
     * Generating array, that requires table
     * Making from child class properties
     *
     * @return array
     */
    public function generate_data_array(): array
    {
        $object_fields = get_object_vars($this);
        unset($object_fields['id']);
        $data = [];
        foreach ($object_fields as $key => $value) {
            $data["UF_" . strtoupper($key)] = $value;
        }

        if ($this->filtered) {
            $data = array_filter($data);
        }
        return $data;
    }

    /**
     * Return an instance of child object with filled properties
     *
     * @param array $item
     * @return static
     */
    public static function make_instance(array $item)
    {
        $instance = new static();
        foreach ($item as $key => $value) {
            $prop_name = strtolower(str_replace("UF_", '', $key));
            $instance->$prop_name = $value;
        }
        return $instance;
    }

    /**
     * @return array
     */
    public static function get_fields(): array
    {
        return array_keys(get_class_vars(static::class));
    }
}