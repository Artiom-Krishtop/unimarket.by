<?php

namespace Brainforce\Unibot\Core;

use Exception;
use TgBotApi\BotApiBase\Method\GetUserProfilePhotosMethod;

abstract class Webhook
{

    /**
     * @throws Exception
     */
    public static function set_webhook($webhook_path, $token)
    {

        $webhook_url = "https://api.telegram.org/bot" . $token .
            "/setWebhook?url=" . (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://'
            . $_SERVER['HTTP_HOST'] . $webhook_path . "?drop_pending_updates=true";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $webhook_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $webhook = curl_exec($ch);
        curl_close($ch);

        $webhook_data = json_decode($webhook, true);
        if (!$webhook_data['ok']) {
            throw new Exception('Вебхук не установлен');
        }
    }

    /**
     * @throws Exception
     */
    public static function delete_webhook($token)
    {

        $webhook_url = "https://api.telegram.org/bot" . $token .
            "/deleteWebhook?drop_pending_updates=true";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $webhook_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $webhook = curl_exec($ch);
        curl_close($ch);

        $webhook_data = json_decode($webhook, true);
        if (!$webhook_data['ok']) {
            throw new Exception('Вебхук не удален');
        }
    }

    public static function get_me($token)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . $token . "/getMe");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $webhook_info = curl_exec($ch);
        curl_close($ch);

        return json_decode($webhook_info, true);
    }

    public static function get_photo($token)
    {
        /*https://core.telegram.org/bots/api#getuserprofilephotos*/
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . $token . "/getUserProfilePhotos?user_id=2015777970");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $webhook_info = curl_exec($ch);
        curl_close($ch);

        $files = json_decode($webhook_info, true)['result']['photos'][0];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . $token . "/getFile?file_id=" . $files[0]['file_id'] );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $photo = curl_exec($ch);
        curl_close($ch);

        return $photo;
    }

    public static function get_webhook_info($token)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . $token . "/getWebhookInfo");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $webhook_info = curl_exec($ch);
        curl_close($ch);

        return json_decode($webhook_info, true);
    }
}