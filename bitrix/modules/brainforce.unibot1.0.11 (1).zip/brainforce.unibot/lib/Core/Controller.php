<?php

namespace Brainforce\Unibot\Core;

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/brainforce.unibot/lib/Core/vendor/autoload.php");

abstract class Controller extends Main
{

    public function __construct()
    {
        parent::__construct();
    }

    public static function log_telegram_errors($e)
    {
        $error_str = date('Y-m-d H:i:s') . " ";
        $errors_log_file = $_SERVER['DOCUMENT_ROOT'] . "/local/tg_errors.txt";
        file_put_contents($errors_log_file, $error_str . $e . PHP_EOL, FILE_APPEND);
    }

    public static function log_telegram_requests($request)
    {
        $errors_log_file = $_SERVER['DOCUMENT_ROOT'] . "/local/tg_requests.txt";
        file_put_contents($errors_log_file, date('Y-m-d H:i:s') . PHP_EOL . var_export($request, true) . PHP_EOL, FILE_APPEND);
    }

}