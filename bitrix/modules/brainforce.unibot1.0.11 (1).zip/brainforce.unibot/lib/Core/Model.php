<?php

namespace Brainforce\Unibot\Core;

use Bitrix;
use Bitrix\Main\ArgumentException;
use Bitrix\Main\ObjectPropertyException;
use Bitrix\Main\SystemException;
use Brainforce\Unibot\Orm\InlineTable;
use Exception;

abstract class Model extends Main
{


    public function __construct()
    {
        parent::__construct();
    }

    /**
     *
     * @return string
     */
    public static function get_orm_class_name(): string
    {
        $class_name = explode("\\", static::class);
        $class_name = array_pop($class_name);
        return substr($class_name, 0, -5) . "Table";
    }

    /**
     *
     * @return string
     */
    public static function get_dto_class_name(): string
    {
        $class_name = explode("\\", static::class);
        $class_name = array_pop($class_name);
        return "Unibot\Dto\\".substr($class_name, 0, -5) . "Dto";
    }

    /**
     * @param array|string[] $select
     * @param array $filter
     * @param int|null $limit
     * @return array
     * @throws Exception
     */
    public static function get_all(array $select = ["*"], array $filter = [], int $limit = null): array
    {
        try {

            $class_name = "Brainforce\Unibot\Orm\\" . self::get_orm_class_name();
            return $class_name::getList([
                'select' => $select,
                'filter' => $filter,
                'limit' => $limit
            ])->fetchAll();

        } catch (ObjectPropertyException | ArgumentException | SystemException $e) {

            throw new Exception($e->getMessage());

        }

    }

    /**
     * @throws Exception
     */
    public static function first(array $select = ["*"], array $filter = [], int $limit = null) {
        return self::get_all($select, $filter, $limit)[0];
    }

    /**
     * @param int $bot_id
     * @param array|string[] $select
     * @param array $filter
     * @param null $limit
     * @return array
     * @throws Exception
     */
    public static function get_for_bot(int $bot_id, array $select = ["*"], array $filter = [], $limit = null): array
    {
        $filter['UF_BOT_ID'] = $bot_id;
        return self::get_all($select, $filter, $limit);
    }

    /**
     * @param int $id
     * @return array
     * @throws Exception
     */
    public static function get_by_id(int $id): array
    {
        return self::get_all(['*'], ['ID' => $id], 1)[0];
    }

    /**
     * @param Dto $dto
     * @return array
     * @throws Exception
     */
    public static function add(Dto $dto): array
    {
        $data = $dto->generate_data_array();
        $class_name = "Brainforce\Unibot\Orm\\" . self::get_orm_class_name();
        $result = $class_name::add($data);

        if ($result->isSuccess()) {

            $id = $result->getId();
            return self::get_by_id($id);

        } else {

            throw new Exception($result->getErrors()[0]);

        }

    }

    /**
     * @param Dto $dto
     * @return array
     * @throws Exception
     */
    public static function update(Dto $dto): array
    {
        $data = $dto->generate_data_array();
        $class_name = "Brainforce\Unibot\Orm\\" . self::get_orm_class_name();
        $result = $class_name::update($dto->id, $data);

        if ($result->isSuccess()) {

            $id = $result->getId();
            return self::get_by_id($id);

        } else {

            throw new Exception($result->getErrorMessages());

        }

    }


    /**
     * @param Dto $dto
     * @return bool
     * @throws Exception
     */
    public static function delete(Dto $dto): bool
    {

        $class_name = "Brainforce\Unibot\Orm\\" . self::get_orm_class_name();
        $result = $class_name::delete($dto->id);

        if ($result->isSuccess()) {

            return true;

        } else {

            throw new Exception($result->getErrorMessages());

        }

    }

}