<?php

namespace Brainforce\Unibot\Models;


use Brainforce\Unibot\Core\Model;

class OrderModel extends Model
{
    public function __construct()
    {
        parent::__construct();

    }

}