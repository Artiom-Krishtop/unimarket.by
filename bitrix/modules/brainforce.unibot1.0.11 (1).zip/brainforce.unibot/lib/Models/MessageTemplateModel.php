<?php

namespace Brainforce\Unibot\Models;


use Bitrix\Main\ArgumentException;
use Bitrix\Main\ObjectPropertyException;
use Bitrix\Main\SystemException;
use Exception;
use Brainforce\Unibot\Core\Model;

class MessageTemplateModel extends Model {

    public function __construct()
    {
        parent::__construct();
    }

}