<?php

namespace Brainforce\Unibot\Models;


use Brainforce\Unibot\Core\Model;

class DefaultMessageModel extends Model
{
    public function __construct()
    {
        parent::__construct();

    }

    /**
     * @throws \Exception
     */
    public static function get_by_text($text)
    {
        $button = self::get_all(['*']);
        $button_key = array_search($text, array_column($button, 'UF_BUTTON_TEXT'));
        if($button_key) {
            return $button[$button_key];
        } else {
            return [];
        }

    }

    public static function get_by_name($name)
    {
        return self::first(['*'],['UF_NAME' => $name]);
    }

}