<?php

namespace Brainforce\Unibot\Models;


use Bitrix\Main\ArgumentException;
use Bitrix\Main\ObjectPropertyException;
use Bitrix\Main\SystemException;
use Exception;
use Brainforce\Unibot\Core\Model;

class SegmentModel extends Model
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @throws Exception
     */
    public function get_by_name(string $name)
    {
        return $this->get_all(['*'], ['UF_NAME' => $name])[0];
    }

    /**
     * @throws Exception
     */
    public static function get_to_link(): array
    {
        $arr = self::get_all(['*'], ['UF_PUBLIC' => true]);
        $result = [];
        foreach ($arr as $value) {
            $result[$value['UF_NAME']] = $value;
        }
        return $result;
    }

    public function get_to_show (): array
    {
        $arr = $this->get_all();
        $result = [];
        foreach ($arr as $value) {
            $result[$value['ID']] = $value;
        }
        return $result;
    }
}