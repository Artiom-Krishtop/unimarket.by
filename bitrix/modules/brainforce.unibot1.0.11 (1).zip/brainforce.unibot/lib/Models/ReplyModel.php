<?php

namespace Brainforce\Unibot\Models;


use Brainforce\Unibot\Core\Model;


class ReplyModel extends Model
{


    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @throws \Exception
     */
    public static function get_by_text($text) {
        $button = self::get_all(['*']);
        $button_key = array_search($text, array_column($button, 'UF_TEXT'));
        if($button_key) {
            return $button[$button_key];
        } else {
            return [];
        }
    }

}