<?php

namespace Brainforce\Unibot\Models;


use Brainforce\Unibot\Core\Model;

class InlineModel extends Model
{
    public function __construct()
    {
        parent::__construct();

    }

}