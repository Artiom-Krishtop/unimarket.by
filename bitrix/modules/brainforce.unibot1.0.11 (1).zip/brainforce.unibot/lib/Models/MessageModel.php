<?php

namespace Brainforce\Unibot\Models;


use Bitrix\Main\ArgumentException;
use Bitrix\Main\ObjectPropertyException;
use Bitrix\Main\SystemException;
use Exception;
use Brainforce\Unibot\Core\Model;

class MessageModel extends Model {

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @throws Exception
     */
    public static function get_by_command ($command, $bot_id, $select = ['*']): array
    {
        return self::get_all($select, ['UF_COMMAND' => $command, 'UF_BOT_ID' => $bot_id])[0];
    }
}