<?php

namespace Brainforce\Unibot\Models;


use Brainforce\Unibot\Core\Model;

class MenuModel extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public static function get_by_name($name)
    {
       $menu = self::get_all(['*'], ['UF_NAME' => $name]);

       return $menu[0];
    }

}