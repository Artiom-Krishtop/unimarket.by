<?php

namespace Brainforce\Unibot\Models;


use Brainforce\Unibot\Core\Model;

class UserModel extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Возвращает пользователей по id чатов
     *
     * @throws \Exception
     */
    public static function get_users_by_chat_ids(array $chat_ids, $bot_id, $select = ['*']): array
    {
        $userArr = self::get_all($select, ['UF_CHAT_ID' => $chat_ids, 'UF_BOT_ID' => $bot_id]);
        if ($userArr) {
            return $userArr;
        } else {
            throw new \Exception('Пользователь на найден');
        }
    }

    /**
     * Возвращает пользователей по их id в hl блоке
     *
     * @throws \Exception
     */
    public static function get_users_by_ids(array $user_ids, $select = ['*']): array
    {
        $userArr = self::get_all($select, ['ID' => $user_ids]);
        if (count($userArr)) {
            return $userArr;
        } else {
            throw new \Exception('Пользователь на найден');
        }


    }

    public static function get_by_segment($segment_id)
    {
        $userArr = self::get_all();
        $result = [];
        foreach ($userArr as $user) {
            foreach ($segment_id as $segment) {
                if (in_array($segment, $user['UF_SEGMENT'])) {
                    $result[] = $user;
                }
            }

        }
        return array_unique($result, SORT_REGULAR);
    }
}