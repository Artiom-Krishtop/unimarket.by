<?php

namespace Brainforce\Unibot\Models;

use Bitrix\Main\ArgumentException;
use Bitrix\Main\ObjectPropertyException;
use Bitrix\Main\SystemException;
use Exception;
use Brainforce\Unibot\Core\Model;

class BotModel extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @throws Exception
     */
    public static function get_by_name($bot_name)
    {
        return self::get_all(['*'], ['UF_NAME' => $bot_name])[0];
    }

    public static function get_bot_by_id(int $id, int $user_id): array
    {
        return self::get_all(['*'], ['ID' => $id])[0];
    }
}