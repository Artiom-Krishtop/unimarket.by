<?php

namespace Brainforce\Unibot\Defaults;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Collections\SendMessageCollection;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Helpers\UserPhoneHelper;
use Brainforce\Unibot\Traits\SendMessageTrait;
use Exception;

class SendContactDefault
{

    use SendMessageTrait;

    /**
     * @param ParamsCollection $params
     * @return bool
     */
    public static function handle(ParamsCollection $params): bool
    {

        try {
            UserPhoneHelper::save($params->chat['id'], $params->bot['ID'], $params->phone);
        } catch (Exception $e) {
            Controller::log_telegram_errors($e->getMessage());
            $params->message_text = "Не удалось сохранить контакт";
        }

        $send_message_collection = SendMessageCollection::create($params->bot, $params->chat, $params->message_text);
        self::send($send_message_collection);

        return true;

    }
}