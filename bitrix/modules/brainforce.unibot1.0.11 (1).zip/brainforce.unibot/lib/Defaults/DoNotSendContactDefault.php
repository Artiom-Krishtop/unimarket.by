<?php

namespace Brainforce\Unibot\Defaults;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Collections\SendMessageCollection;
use Brainforce\Unibot\Traits\SendMessageTrait;

class DoNotSendContactDefault
{
    use SendMessageTrait;
    /**
     * @param ParamsCollection $params
     * @return bool
     */
    public static function handle(ParamsCollection $params): bool
    {

        $send_message_collection = SendMessageCollection::create($params->bot, $params->chat, $params->message_text);
        self::send($send_message_collection);
        return true;

    }
}