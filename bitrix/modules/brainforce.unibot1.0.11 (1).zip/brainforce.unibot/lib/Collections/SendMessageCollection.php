<?php

namespace Brainforce\Unibot\Collections;

use TgBotApi\BotApiBase\Type\InlineKeyboardMarkupType;
use TgBotApi\BotApiBase\Type\ReplyKeyboardMarkupType;

class SendMessageCollection
{
    /**
     * @var array
     */
    public $bot;

    /**
     * @var array
     */
    public $chat;

    /**
     * @var InlineKeyboardMarkupType | ReplyKeyboardMarkupType
     */
    public $keyboard;

    /**
     * @var string
     */
    public $text;

    /**
     * Creating parameters object for commands or callbacks
     *
     * @param array $bot
     * @param array $chat
     * @param InlineKeyboardMarkupType | ReplyKeyboardMarkupType | null $keyboard
     * @return SendMessageCollection
     */
    public static function create(array $bot, array $chat, string $text, $keyboard = null): SendMessageCollection
    {
        $instance = new static();
        $instance->bot = $bot;
        $instance->chat = $chat;
        $instance->keyboard = $keyboard;
        $instance->text = $text;
        return $instance;
    }

}