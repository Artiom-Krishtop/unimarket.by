<?php

namespace Brainforce\Unibot\Collections;

class ParamsCollection
{
    /**
     * @var array
     */
    public $bot;

    /**
     * @var array
     */
    public $chat;

    /**
     * @var string
     */
    public $action;

    /**
     * @var string
     */
    public $parameter;

    /**
     * @var string
     */
    public $message_id;

    /**
     * @var string
     */
    public $message_text;

    /**
     * @var string
     */
    public $phone;

    /**
     * Creating parameters object for commands or callbacks
     *
     * @param array $bot
     * @param array $chat
     * @param string $action
     * @param string|null $parameter
     * @param string|null $message_id
     * @return ParamsCollection
     */
    public static function create(
        array $bot,
        array $chat,
        string $action,
        string $parameter = null,
        string $message_id = null,
        string $message_text = null,
        string $phone = null
    ): ParamsCollection
    {
        $instance = new static();
        $instance->bot = $bot;
        $instance->chat = $chat;
        $instance->action = $action;
        $instance->parameter = $parameter;
        $instance->message_id = $message_id;
        $instance->message_text = $message_text;
        $instance->phone = $phone;
        return $instance;
    }

}