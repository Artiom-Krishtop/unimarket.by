<?php

namespace Brainforce\Unibot\Traits;

use Brainforce\Unibot\Collections\SendMessageCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Models\MenuModel;

trait SendMessageTrait
{
    public static function send(SendMessageCollection $params, bool $set_menu = true)
    {

        $message_controller = new MessageController();
        $bot_controller = new BotController($params->bot['UF_API_KEY']);

        if (!$params->keyboard && $set_menu) {
            $menu_id = MenuModel::get_by_name('main')['ID'];
            $params->keyboard = ButtonsController::create_menu($menu_id);
        }

        $message = $message_controller->create_message($params->text, $params->chat['id'], $params->keyboard);
        $bot_controller->send([$message]);

    }
}