<?php

namespace Brainforce\Unibot\Validators;


use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Models\DefaultMessageModel;
use Exception;
use Brainforce\Unibot\Models\ReplyModel;

abstract class TextTypeValidator
{
    /**
     * @param string $text
     * @return array
     */
    public static function validate(string $text): array
    {

        try {

            $button = ReplyModel::get_by_text($text);

            if ($button['UF_ACTION'] == "Command") {
                $type = 'command';
                $action = $button['UF_ACTION_VALUE'];
            } elseif ($button['UF_ACTION']) {
                $type = 'callback';
                $action = $button['UF_ACTION'];
                $parameter = $button['UF_ACTION_VALUE'];
            }

            if (!$button) {

                $button = DefaultMessageModel::get_by_text($text);

                $type = "default";
                $message = $button['UF_MESSAGE'];
                $action = $button['UF_NAME'];

            }

        } catch (Exception $e) {}


        if(!isset($button) || !$button) {
            $type = 'feedback';
            $message = $text;
            $action = 'feedback';
        }

        return [
            'type' => $type ?? '',
            'action' => $action ?? "",
            'parameter' => $parameter ?? "",
            'message' => $message ?? "",
        ];

    }
}