<?php

namespace Brainforce\Unibot\Validators;

use Exception;
use Brainforce\Unibot\Models\BotModel;

abstract class BotValidator
{

    public static function validate($bot_name)
    {
        try {

            $model = new BotModel();
            return $model->get_by_name($bot_name);

        } catch (Exception $e) {

            die();

        }

    }

}