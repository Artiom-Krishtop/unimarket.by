<?php

namespace Brainforce\Unibot\Validators;

use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Models\DefaultMessageModel;
use Exception;

abstract class RequestValidator
{

    /**
     * @param array $request
     * @return array
     */
    public static function validate(array $request): array
    {

        if ($request['message']['entities'] || $request['message']['entities'][0]['type'] == 'bot_command') {

            $type = 'command';

            $message = $request['message']['text'];
            $chat = $request['message']['chat'];
            $message_id = $request['message']['message_id'];

        } elseif ($request['callback_query']) {

            $type = 'callback';

            $message = $request['callback_query']['data'];
            $chat = $request['callback_query']['message']['chat'];
            $message_id = $request['callback_query']['message']['message_id'];

        } else {

            if ($request['message']['contact']) {

                $type = "contact";
                $phone = $request['message']['contact']['phone_number'];

                $default = DefaultMessageModel::get_by_name("send_contact");
                $action = 'send_contact';
                $message_text = $default['UF_MESSAGE'];

            } elseif ($request['message']['text']) {

                $validator = TextTypeValidator::validate($request['message']['text']);

                $type = $validator['type'];

                $action = $validator['action'];
                $parameter = $validator['parameter'];
                $message_text = $validator['message'];

            }

            $chat = $request['message']['chat'];
            $message_id = $request['message']['message_id'];

        }

        if (isset($message)) {
            $message = explode(" ", $message);
            $action = $message[0];
            unset($message[0]);
            $parameter = implode(" ", $message);
        }

        return [
            'chat' => $chat,
            'type' => $type ?? null,
            'action' => $action ?? null,
            'parameter' => $parameter ?? null,
            'message_id' => $message_id,
            'phone' => $phone ?? null,
            'message_text' => $message_text ?? null,
        ];

    }
}