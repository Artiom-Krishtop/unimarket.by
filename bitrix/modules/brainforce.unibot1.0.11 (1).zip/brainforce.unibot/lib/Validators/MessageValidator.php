<?php

namespace Brainforce\Unibot\Validators;

abstract class MessageValidator
{
    public static function validate (string $message): string
    {
        return $message;
    }
}