<?php

namespace Brainforce\Unibot\Dto;


use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Core\Dto;

class MessageDto extends Dto
{

    /**
     * @var string|null
     */
    public $command;

    /**
     * @var string|null
     */
    public $segments;

    /**
     * @var array|null
     */
    public $messages;

    /**
     * @var array|null
     */
    public $users;

    /**
     * @var DateTime
     */
    public $date;

    /**
     * @var int
     */
    public $bot_id;

    /**
     * @var int
     */
    public $sort;

}