<?php

namespace Brainforce\Unibot\Dto;


use Brainforce\Unibot\Core\Dto;

class SegmentDto extends Dto
{
    /**
     * @var string
     */
    public $name;

    /**
     * @var bool
     */
    public $public;

    /**
     * @var int
     */
    public $bot_id;
}
