<?php

namespace Brainforce\Unibot\Dto;


use Brainforce\Unibot\Core\Dto;

class BotDto extends Dto
{
    /**
     * @var string
     */
    public $name;

    /**
     * @var string
     */
    public $api_key;

    /**
     * @var int
     */
    public $user_id;

    /**
     * @var int
     */
    public $iblock_id;
}