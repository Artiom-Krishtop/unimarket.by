<?php

namespace Brainforce\Unibot\Dto;


use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Core\Dto;

class UserDto extends Dto
{
    /**
     * @var string
     */
    public $name;

    /**
     * @var string
     */
    public $username;

    /**
     * @var string
     */
    public $phone;

    /**
     * @var string
     */
    public $chat_id;

    /**
     * @var array
     */
    public $segment;

    /**
     * @var DateTime;
     */
    public $date_registration;

    /**
     * @var int
     */
    public $bot_id;

    /**
     * @var string
     */
    public $current_chat;

}