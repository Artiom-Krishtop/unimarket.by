<?php

namespace Brainforce\Unibot\Dto;


use Brainforce\Unibot\Core\Dto;

class MenuDto extends Dto
{
    /**
     * @var string
     */
    public $name;

    /**
     * @var array|null
     */
    public $row_1;

    /**
     * @var array|null
     */
    public $row_2;

    /**
     * @var array|null
     */
    public $row_3;

    /**
     * @var int
     */
    public $bot_id;
}
