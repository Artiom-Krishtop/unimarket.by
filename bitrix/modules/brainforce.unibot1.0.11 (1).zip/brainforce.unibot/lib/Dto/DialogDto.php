<?php

namespace Brainforce\Unibot\Dto;

use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Core\Dto;

class DialogDto extends Dto
{
    /**
     * @var string
     */
    public $message_id;

    /**
     * @var string
     */
    public $from;

    /**
     * @var string
     */
    public $to;

    /**
     * @var string
     */
    public $message;

    /**
     * @var DateTime
     */
    public $date;

    /**
     * @var int
     */
    public $bot_id;
}