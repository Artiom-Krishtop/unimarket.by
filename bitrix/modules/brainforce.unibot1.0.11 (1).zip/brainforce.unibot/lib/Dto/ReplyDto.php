<?php

namespace Brainforce\Unibot\Dto;


use Brainforce\Unibot\Core\Dto;

class ReplyDto extends Dto
{

    /**
     * @var string
     */
    public $text;

    /**
     * @var string
     */
    public $action;

    /**
     * @var string
     */
    public $action_value;

    /**
     * @var bool
     */
    public $location = false;

    /**
     * @var bool
     */
    public $contact = false;

    /**
     * @var string
     */
    public $description;

    /**
     * @var int
     */
    public $bot_id;
}
