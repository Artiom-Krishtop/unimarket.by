<?php

namespace Brainforce\Unibot\Dto;


use Brainforce\Unibot\Core\Dto;

class InlineDto extends Dto
{
    /**
     * @var string
     */
    public $text;

    /**
     * @var string
     */
    public $type;

    /**
     * @var string
     */
    public $action;

    /**
     * @var string
     */
    public $action_value;

    /**
     * @var string
     */
    public $description;

    /**
     * @var int
     */
    public $bot_id;
}
