<?php

namespace Brainforce\Unibot\Dto;


use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Core\Dto;

class MessageTemplateDto extends Dto
{

    /**
     * @var string
     */
    public $message;

    /**
     * @var array|null
     */
    public $buttons;

    /**
     * @var int|null
     */
    public $menu;

    /**
     * @var int|null
     */
    public $file;

    /**
     * @var bool
     */
    public $is_file = true;

    /**
     * @var int
     */
    public $bot_id;

}