<?php

namespace Brainforce\Unibot\Dto;

use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Core\Dto;
use Brainforce\Unibot\Models\OrderModel;

class OrderDto extends Dto
{
    /**
     * @var array[]
     */
    public $order;

    /**
     * @var int
     */
    public $iblock_id;

    /**
     * @var int
     */
    public $bot_id;

    /**
     * @var int
     */
    public $tg_user_id;

    /**
     * values:
     * "C" -> collecting
     * "A" -> approval
     * "P" -> paid
     * "D" -> delivered
     *
     * @var string
     */
    public $status;

    /**
     * @var DateTime
     */
    public $date;


    public static function create($bot_id, $tg_user_id, $iblock_id, $order_item)
    {

        $instance = new static();
        $exists_order = OrderModel::first(['*'], ['UF_BOT_ID' => $bot_id, 'UF_TG_USER_ID' => $tg_user_id]);

        if ($exists_order['UF_STATUS'] == "C") {

            $instance = self::make_instance($exists_order);
            $instance->order[] = $order_item;
            $instance->date = new DateTime();

        } else {

            $instance->order[] = $order_item;
            $instance->iblock_id = $iblock_id;
            $instance->bot_id = $bot_id;
            $instance->tg_user_id = $tg_user_id;
            $instance->status = "C";
            $instance->date = new DateTime();

        }

        return $instance;

    }
}