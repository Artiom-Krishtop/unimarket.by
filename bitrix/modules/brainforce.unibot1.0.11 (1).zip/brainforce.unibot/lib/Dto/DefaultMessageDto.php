<?php

namespace Brainforce\Unibot\Dto;


use Brainforce\Unibot\Core\Dto;

class DefaultMessageDto extends Dto
{
    /**
     * @var string
     */
    public $button_text;

    /**
     * @var string
     */
    public $message;

    /**
     * @var string
     */
    public $name;

    /**
     * @var int
     */
    public $bot_id;
}
