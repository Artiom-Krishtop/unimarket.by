<?php

namespace Brainforce\Unibot\Callbacks;

use Exception;
use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Commands\Command;
use Brainforce\Unibot\Core\Controller;


class CommandCallback
{
    public static function handle(ParamsCollection $params): bool
    {

        $response = true;

        try {

            $class_name = $params->parameter;
            $class_name = substr($class_name, 1);
            $class_name = ucfirst($class_name);
            $class_name = $class_name . "Command";
            $class_file = $class_name . ".php";
            if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/bitrix/modules/brainforce.unibot/lib/Commands/" . $class_file)) {

                $class_namespace = "Brainforce\Unibot\Commands\\";
                $class_name = $class_namespace . $class_name;
                new $class_name($params);

            } else {

                new Command($params);

            }

        } catch (Exception $e) {

            try {
                $params->action = "/error";
                new Command($params);

            } catch (Exception $e) {

                Controller::log_telegram_errors('Нет сообщения для команды /error');

                $response = false;
            }

        }

        return $response;

    }
}