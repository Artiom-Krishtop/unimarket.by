<?php

namespace Brainforce\Unibot\Callbacks;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Controllers\OrderController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Dto\OrderDto;
use Brainforce\Unibot\Models\UserModel;
use Exception;

class AddToCartCallback
{
    public static function handle(ParamsCollection $params): bool
    {
        try {

            $user = UserModel::get_users_by_chat_ids([$params->chat['id']], $params->bot['ID'])[0];
            $order_item = [
                'product' => $params->parameter,
                'count' => 1,
            ];

            $order_dto = OrderDto::create($params->bot['ID'], $user['ID'], 1, $order_item);
            $order = OrderController::create_order($order_dto);

            if ($order['ID']) {
                $message_text = "Товар добавлен в корзину";
                $button = ButtonsController::create_inline_button('Просмотреть корзину', ['callbackData' => 'Command /cart']);
                $keyboard = ButtonsController::create_inline_keyboard([[$button]]);
            } else {
                $message_text = "Что-то пошло не так";
            }

            $message = MessageController::create_message($message_text, $params->chat['id'], $keyboard ?? null);
            $bot = new BotController($params->bot['UF_API_KEY']);
            $bot->send([$message]);

            return true;

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return false;

        }

    }

}