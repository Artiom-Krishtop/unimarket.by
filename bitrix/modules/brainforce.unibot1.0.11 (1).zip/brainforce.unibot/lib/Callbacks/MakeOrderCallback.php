<?php

namespace Brainforce\Unibot\Callbacks;

use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Controllers\OrderController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Helpers\UserPhoneHelper;
use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Models\OrderModel;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;
use Exception;

class MakeOrderCallback
{
    public static function handle(ParamsCollection $params): bool
    {

        try {

            $order = OrderController::make_order($params->parameter);
            if ($order['ID']) {
                $message = "Заказ оформлен, номер заказа - " . $order['ID'];
            } else {
                $message = "Заказ не оформлен, попробуйте позже";
            }

            $message = MessageController::create_message($message, $params->chat['id']);

            $request_phone = UserPhoneHelper::get($params->chat['id'], $params->bot['ID']);
            $phone_message = MessageController::create_message($request_phone['message'], $params->chat['id'], $request_phone['keyboard']);

            $bot = new BotController($params->bot['UF_API_KEY']);
            $bot->send([$message, $phone_message]);

            $admin_segment_id = SegmentModel::first(['*'], ['UF_NAME' => 'admin']);

            $users = UserModel::get_by_segment([$admin_segment_id['ID']]);
            $order_user = UserModel::get_users_by_chat_ids([$params->chat['id']], $params->bot['ID'])[0];
            $order = OrderController::get_order($order['ID']);

            $message_text = self::create_message_text($order, $order_user);

            $messages = [];
            foreach ($users as $user) {
                $messages[] = MessageController::create_message($message_text, $user['UF_CHAT_ID']);
            }

            $bot->send($messages);
            return true;

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return false;

        }

    }

    public static function create_message_text($order, $order_user): string
    {

        $message_text = "*Заказ №" . $order['order_id'] . "*\n\n";
        $message_text .= "*Имя:* " . $order_user['UF_NAME'] . "\n";
        $message_text .= "*Имя пользователя:* @" . str_replace("_", "\_", $order_user['UF_USERNAME']) . "\n";
        $message_text .= $order_user['UF_PHONE'] ? "*Телефон:* " . $order_user['UF_PHONE'] . "\n\n" : "\n\n";
        $message_text .= "*Детали заказа:* \n\n";
        $message_text .= $order['message'];

        return $message_text;
    }
}