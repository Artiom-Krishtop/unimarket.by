<?php

namespace  Brainforce\Unibot\Callbacks;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\CatalogController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Core\Controller;
use Exception;

class GetSectionCallback
{

    public static function handle(ParamsCollection $params): bool
    {

        try {

            $message_controller = new MessageController();

            $id = explode(".", $params->parameter)[0];
            $page = explode(".", $params->parameter)[1];

            $keyboard = CatalogController::create_catalog_keyboard($params->bot['UF_IBLOCK_ID'], $id, $page);


            if ($params->parameter) {
                $section_name = CatalogController::get_section($id)['NAME'];
            } else {
                $section_name = 'Каталог';
            }

            $delete_message = $message_controller->delete_message($params->chat['id'], $params->message_id);
            $message = $message_controller->create_message("*".$section_name."*", $params->chat['id'], $keyboard);

            $bot = new BotController($params->bot['UF_API_KEY']);
            $bot->send([$message]);
            $bot->delete([$delete_message]);

            return true;

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return false;

        }

    }

}