<?php

namespace Brainforce\Unibot\Callbacks;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Dto\UserDto;
use Brainforce\Unibot\Models\UserModel;
use Exception;

class AcceptDialogCallback
{

    public static function handle(ParamsCollection $params): bool {

        try {

            $dialog_user = UserModel::get_users_by_chat_ids([$params->parameter], 1)[0];

            if ($admin = UserModel::first(["*"], ['UF_CURRENT_CHAT' => $params->parameter])) {

                $message_text = 'Администратор *'. $admin['UF_NAME']."* уже начал диалог с пользователем *" . $dialog_user['UF_NAME'] . "*";

            } else {

                $user = UserModel::get_users_by_chat_ids([$params->chat['id']], 1)[0];
                $user_dto = UserDto::make_instance($user);
                $user_dto->current_chat = $params->parameter;
                UserModel::update($user_dto);

                $button = ButtonsController::create_reply_button('Завершить диалог');
                $keyboard = ButtonsController::create_reply_keyboard([[$button]]);

                $message_text = '*Начат диалог с пользователем ' . $dialog_user['UF_NAME']."*";

            }

            $message = MessageController::create_message($message_text, $params->chat['id'], $keyboard ?? null);
            $delete_message = MessageController::update_inline_markup($params->chat['id'], $params->message_id, null);

            $bot = new BotController($params->bot['UF_API_KEY']);

            $bot->update([$delete_message]);
            $bot->send([$message]);

            return true;

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return false;

        }

    }

}