<?php

namespace Brainforce\Unibot\Callbacks;

use Brainforce\Unibot\Collections\ParamsCollection;

class PlumbCallback
{
    public static function handle(ParamsCollection $params): bool
    {
        return true;
    }
}