<?php

namespace Brainforce\Unibot\Callbacks;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Controllers\CatalogController;
use Brainforce\Unibot\Core\Controller;
use Exception;


class GetElementCallback
{

    public static function handle(ParamsCollection $params): bool
    {

        try {

            $message_controller = new MessageController();
            $element = CatalogController::get_element($params->parameter);

            $message_srt = "";
            $message_srt .= "*" . $element['NAME'] . "*\n\n";
            $message_srt .= "_" . $element['DETAIL_TEXT'] . "_\n\n";
            $message_srt .= "*Цена:* " . $element['PROPERTY_UF_PRICE_VALUE'] . " BYN";

            if ($element['DETAIL_PICTURE']) {
                $picture_src = $element['DETAIL_PICTURE'];
            }

            $buttons_controller = new ButtonsController();

            $order = $buttons_controller->create_inline_button("Заказать", ['callbackData' => "AddToCart " . $element['ID']]);
            $buttons[][] = $order;

            if ($element['PROPERTY_UF_URL_VALUE']) {
                $link = $buttons_controller->create_inline_button("🔗 Посмотреть на сайте", ['url' => $element['PROPERTY_UF_URL_VALUE']]);
                $buttons[][] = $link;
            }

            $button = $buttons_controller->create_inline_button("↩ Назад в раздел", ['callbackData' => 'GetSection ' . $element['IBLOCK_SECTION_ID'] . ".1"]);
            $buttons[][] = $button;

            $keyboard = $buttons_controller->create_inline_keyboard($buttons);

            $delete_message = $message_controller->delete_message($params->chat['id'], $params->message_id);
            $message = $message_controller->create_message($message_srt, $params->chat['id'], $keyboard, $picture_src ?? null);

            $bot = new BotController($params->bot['UF_API_KEY']);
            $bot->send([$message]);
            $bot->delete([$delete_message]);

            return true;

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return false;

        }

    }

}