<?php

namespace Brainforce\Unibot\Callbacks;

use Bitrix\Main\ArgumentNullException;
use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Dto\MessageDto;
use Brainforce\Unibot\Models\MessageModel;
use CFile;
use Exception;

class NextMessageCallback
{

    /**
     * @throws ArgumentNullException | Exception
     */
    public static function handle(ParamsCollection $params): bool
    {
        $message_model = new MessageModel();
        $message = $message_model->get_by_id($params->parameter);
        if ($message) {

            $templates = MessageController::get_templates($params->parameter);
            $messages_array = [];

            foreach ($templates as $template) {

                if ($template['UF_MENU']) {

                    $keyboard = ButtonsController::create_menu($template['UF_MENU']);

                } elseif ($template['UF_BUTTONS']) {

                    $keyboard = ButtonsController::create_buttons($template['UF_BUTTONS']);

                }

                if ($template['UF_FILE']) {

                    if ($message['UF_IS_FILE']) {

                        $is_file = true;

                    }

                    $file_src = "https://tim-bot.ru" . CFile::GetPath($template['UF_FILE']);

                }

                $messages_array[] = MessageController::create_message($template['UF_MESSAGE'], $params->chat['id'], $keyboard ?? null, $file_src ?? null, $is_file ?? null);

                unset($is_file);
                unset($keyboard);
                unset($file_src);

            }

            $bot = new BotController($params->bot['UF_API_KEY']);
            $bot->send($messages_array);

            $response = true;

        } else {

            $response = false;

        }

        return $response;
    }

}