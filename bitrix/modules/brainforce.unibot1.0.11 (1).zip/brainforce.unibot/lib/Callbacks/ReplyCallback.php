<?php

namespace Brainforce\Unibot\Callbacks;

use Brainforce\Unibot\Collections\ParamsCollection;

class ReplyCallback
{
    public function handle(ParamsCollection $params)
    {

    }
}