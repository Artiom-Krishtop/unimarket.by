# UNIBOT v1.0.8

## Подключение

_________________

### Таблицы

**Таблица "uni_bots"**\
Хранит в себе ботов

**Поля**

* UF_NAME - Имя бота
* UF_API_KEY - Токен
* UF_USER_ID - ID пользователя в системе
_______

**Таблица "uni_users"**\
Хранит в себе пользователей бота

**Поля**

* UF_USERNAME - Никнейм пользователя, добавляется в виде json строки
* UF_NAME - Имя пользователя
* UF_CHAT_ID - ID чата пользователя, хранится в виде строки
* UF_DATE_REGISTRATION - Дата подключения пользователя, хранится в формате даты с использованием секунд
* UF_BOT_ID - ID бота
_______

**Таблица "uni_messages"**\
Хранит в себе сообщения разных типов

**Поля**

* UF_MESSAGE - Текст сообщения, добавляется в виде json строки
* UF_COMMAND - Если сообщение выводится для определенной команды, заполняется, пример: "/help"
* UF_FILE - Картинка для отправки вместе с сообщением
* UF_DATE - Дата создания сообщения, хранится в формате даты с использованием секунд
* UF_DATE - Дата создания сообщения, хранится в формате даты с использованием секунд
* UF_USERS - Список пользователей, которым было отправлено сообщение при создании, множественное, привязка в таблице
  пользователей
* UF_BUTTONS - Список кнопок, которые отправляются вместе с сообщением, множестенное, приязка к таблице кнопок сообщений
* UF_MENU - Меню, которое отправляется вместе с сообщением, приязка к таблице кнопок меню
* UF_BOT_ID - ID бота
______

**Таблица "uni_menu"**\
Хранит в себе меню

**Поля**

* UF_NAME - Название меню, желательно называть по имени команды
* UF_ROW_1 - UF_ROW_3 - Порядок кнопок в рядах, множественное поле, целое число, ID кнопки меню
* UF_BOT_ID - ID бота

_______

**Таблица "uni_buttons_inline"**
Хранит в себе кнопки для сообщений
**Поля**

* UF_TEXT - Название кнопки, добавляется в виде json строки
* UF_TYPE - Типы кнопок согласно API телеграма
* UF_ACTION - Действие, которое выполняет кнопка
* UF_ACTION_VALUE - Заполняется, если требуется пояснение к действию
* UF_BOT_ID - ID бота

> Кнопка с типом callbackData, ей передается действие NextMessage - отправка следующего сообщения, требуетя указать, какое сообщение нужно отправить, для этого в UF_ACTION_VALUE передается ID сообщения

______


**Таблица "uni_buttons_reply"**\
Хранит в себе кнопки для меню

**Поля**

* UF_TEXT - Название кнопки, добавляется в виде json строки
* UF_CONTACT - true, если кнопка передает контакт пользователя
* UF_LOCATION - true, если кнопка передает местоположение пользователя
* UF_ACTION - Действие, которое выполняет кнопка
* UF_ACTION_VALUE - Заполняется, если требуется пояснение к действию
* UF_BOT_ID - ID бота

______
______

### Добавление бота
/bitrix/admin/unibot_bot_add.php

После добавления добавится строка в таблицу ботов, файл вебхука в local/Unibot и поставится вебхук
______
______

## Модели

Для создания модели требуется создать класс в папке **Models** в пространстве имен **UNI\Models**\
Разберем на примере модели пользователей

```injectablephp
namespace Unibot\Models;


use Brainforce\Unibot\Core\Model;

class UserModel extends Model
{ 
    /* Определяем имя таблицы */
    const TABLE_NAME = 'uni_users';
    
     public function __construct()
    {
        parent::__construct();
    }
}
```

Теперь создавая экземпляр класса **UserModel** мы можем работать соответствующей таблицей
___

### Методы *add(array $data)*, *update(int $id, array $data)* и *delete(int $id)*

Пример добавления пользователя в таблицу

```injectablephp
use UNI\Models\UserModel;

$user = new UserModel()
$user_data = [
    'UF_NAME' => $this->chat['first_name']. " " . $this->chat['last_name'],
    'UF_USERNAME' => $this->chat['username'] ? : $this->chat['id'],
    'UF_CHAT_ID' => $this->chat['id'],
    'UF_DATE_REGISTATION' => date('d.m.Y H:i:s')
];

/* 
 * В родительском классе Model есть метод add(array $data), 
 * который добавит данные в таблицу
 * */
try {
    $user->add($user_data)
} catch (\Exception $e) {
    /*
     * Обработка ошибки
     * */
     echo $e->getMessage()l
}
```

> Из базовых методов работы с данными также существуют *update(int $id, array $data)* и *delete(int $id)*
___

### Метод *get_all(array $select, array $filter)*

Метод принимает в себя два параметра\
*select* - массив полей, которые вернутся с каждым элементом\
*filter* - массив полей для фильтрации

*По умолчанию $select = ['*'], $filter = []*

```injectablephp
$user_model = new UserModel();
$users_array = $user_model->get_all(["ID", "UF_NAME"], ["ID" => [1, 5, 7]])
```

Вернет следующий массив

```injectablephp
[
    0 => [
        'ID' => 1,
        'UF_NAME' => 'Кононова Милена',
    ],
    1 => [
        'ID' => 5,
        'UF_NAME' => 'Ткачев Дмитрий',
    ],
    2 => [
        'ID' => 7,
        'UF_NAME' => 'Муравьев Семён',
    ],
    
]
```

___

### Кастомизация методов

К примеру, было бы удобно искать пользователя ID чата\
Воспользуемся уже существующим методом ***get_all()***

```injectablephp
    
    
    function get_by_chat_id(array $chat_id, $select = ['*']): array
    {
        $user_model = new UserModel();
        $userArr = $user_model->get_all($select, ['UF_CHAT_ID' => $chat_ids]);
        if (count($userArr)) {
            return $userArr[0];
        } else {
            throw new \Exception('Пользователь на найден');
        }
    }
```

> Методы теперь находят конкретного пользователя по определенному полю
___
___

## Контроллеры

Контроллеры позволяют соединить логику работы бота и данные на сайте\
К примеру, требуется отправить сообщение пользователю, для этого надо понимать какому пользователю отправлять какое
сообщение, какие кнопки в сообщении создать, а так же добавить это сообщение в таблицу
___

### Метод create_inline_button()

Создает кнопку для сообщения\
К примеру нам надо чтобы в сообщении было две кнопки, одна это ссылка на google.com, вторая отправляет сообщение c ID
74 *(часть про колбеки)*

```injectablephp
$controller = new \Unibot\Core\Controller();

$google_button = $controller->create_inline_button("Google", ["url" => "google.com"]);
$next_message_button = $controller->create_inline_button("Следующее сообщение", ["callbackData" => "NextMessage 74"])

```

> Метод принимает два параметра, первый - это текст кнопки, второй - массив из одного элемента, где ключ - это тип кнопки, согласно API телеграма
___

### Метод create_inline_keyboard()

Теперь из этих кнопок надо создать клавиатуру

```injectablephp
$inline_keyboard = $controller->create_inline_keyboard([[$google_button], [$next_message_button]])
```

> Метод принимает массив массивов кнопок
> ```
> [[button1, button2]] - в один ряд
> [[button1], [button2]] - в два ряда
> ```
> В нашем случае кнопки будут располагаться в сообщении друг под другом
___

### Метод create_message() и send()

Теперь все готово для создания сообщения.\
Соединяя возможности контроллера и моделей создадим контроллер сообщений

```injectablephp
namespace Unibot\Controllers;


use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Models\UserModel;

class MessageController extends Controller
{
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function send_message($text, $user_id, $bot) 
    {
        $google_button = $this->create_inline_button("Google", ["url" => "google.com"]);
        $next_message_button = $this->create_inline_button("Следующее сообщение", ["callbackData" => "NextMessage 74"]);
        
        $inline_keyboard = $controller->create_inline_keyboard([[$google_button], [$next_message_button]]);
        
        $user_model = new UserModel();
        $user = $user_model->get_all($select, ['ID' => $user_id])[0];
        $chat_id = $user['UF_CHAT_ID'];
        
        $message = $this->create_message($text, $chat_id, $inline_keyboard);
        
        $bot = new BotController($bot['UF_API_KEY']);
        $bot->send([$message]);
        
    }

}
```

Теперь для того, чтобы отправить сообщение пользователю с ID 5 требуется

```injectablephp

use Brainforce\Unibot\Controllers\MessageController

$text = "Добро пожаловать в UNI-Bot";
$user_id = 5;
$message_controller = new MessageController();
$message_controller->send_message($text, $user_id);
```

> Поиск пользователя по ID чата будет корректнее разместить в модели UserModel
___
___

## Роутер

Для определения того, что хочет пользователь, в корне располагается файл **Router.php**

При создании экземпляра класса, в него передается запрос, который пришел от телеграма и имя бота, затем определяем тип сообщения и
в итоге определяем, к методу какого класса обратиться, чтобы отправить нужный ответ

Сейчас роутер определяет три типа запроса, это **команда**, **колбек** и **текст**
___
___

## Команды

Пример обработчика команды старт

* Записать пользователя в таблицу пользователей
* Отправить пользователю сообщение для команды /start, которое хранится в таблице сообщений

### Создаем класс StartCommand

Для работы с пользователями понадобится модель пользователей, для работы с сообщениями - сообщений\
Телеграм в запросе отправляет данные чата, они понадобятся для записи пользователя,
Поскольку нам нужно сообщение отправить, воспользуемся ранее созданным контроллером сообщений

```injectablephp
namespace Unibot\Commands


use UNI\Models\MessageModel;
use UNI\Models\UserModel;
use UNI\Controllers\MessageController;

class StartCommand
{
    public $chat;
    
    public function __construct($chat) 
    {
        $this->chat = $chat;
    }
    
}
```

Создаем метод обработчик, проверим есть ли такой пользователь, если нет, добавляем в таблицу

```injectablephp
public function handle() 
{
    $user_model = new UserModel();
    $user = $user_model->get_all(["ID"], ["UF_CHAT_ID" => $this->chat['id']])
        
    if (!$user[0]) 
    {
        $user_data = [
            'UF_NAME' => $this->chat['first_name']. " " . $this->chat['last_name'],
            'UF_USERNAME' => $this->chat['username'] ? : $this->chat['id'],
            'UF_CHAT_ID' => $this->chat['id'],
            'UF_DATE_REGISTATION' => date('d.m.Y H:i:s')
        ];
            
        $user_model->add($user_data)
    }
}
```

Найдем в таблице сообщений сообщение для команды **/start** и отправим пользователю

```injectablephp
public function handle() 
{
    /* Предыдущий код */
    $message_model = new MessageModel();
    $start_message = $message_model->get_all(["*"], ["UF_COMMAND" => "/start"])[0]; // 0 потому что нам требуется одно сообщение
    
    $message_controller = new MessageController();
    
    /* Проверим есть ли вообще такое сообщение */
    if ($start_message) {
        $text = json_decode($start_message['UF_MESSAGE']); // Тексты сообщений хранятся в json, см. Подключение => [UNI] Сообщения
    } else {
        $text = "Добро пожаловать в UNI-Bot";
    }
    
    $chat_id = $this->chat['id'];
    $message_controller->send_message($text, $chat_id);
}
```
Теперь в роутере в методе **command_routes()**, в случае, если команда **/start** вызвать метод handle у класса StartCommand
```injectablephp
 public function commands_route()
    {
        switch ($this->command) {
            case "/start":
                $start = new StartCommand($this->chat);
                $start->handle();
                break;
            default:
                $default = new DefaultCommand($this->chat, $this->command);
                $default->handle();
                break;
        }
```
> Если роутер не распознает команду, то он отправит команду в класс **DefaultCommand**, где найдет сообщение, соответствующее команде
___
___
## Колбэки
Телеграм поддерживает способ отправки данный как колбэк, это нужно для того, чтобы в тексте кнопки не содержалось данных, 
которые нужны для обработки
___
Предположим, в сообщении по команде /start передается кнопка, при нажатии на которую отправится сообщение с контактами
### Класс NextMessageCallback
Для начала посмотрим как работает обработчик колбэков
```injectablephp
if ($this->request['callback_query']) {

    $this->type = 'callback';
    $data = explode(" ", $this->request['callback_query']['data']);
    $this->callback = $data[0];

    unset($message[0]);
    $this->params = implode(" ", $data);
}
```
> Все данные приходят в callback_query\
> При создании кнопки ей переделись определенные параметры ['callbackData' => 'callbackName params'], а в 
> callback_query эти данные так и придут в виде строки
> 
> Принцип следующий, при создании кнопки пишем **['callbackData' => 'NextMessage 74']**, где **NextMessage** - название колбэка, 
> которое покажет в какой обработчик отправлять данные, а **74** - это данные, которые отправятся в обработчик, то есть ID сообщения

Для начала требуется создать сообщение контактов, взять его ID, предположим 74, и в параметры кнопки записать **['callbackData' => 'NextMessage 74']**

По аналогии с классами команд, создадим класс колбэка.\
Все, что нужно сделать колбэку - это найти сообщение и отправить нужному пользователю.\
Попробуем метод **handle()** статическим, чтобы не создавать экземпляр класса и в него передадим данные о чате.\
Также воспользуемся контроллером отправки сообщений.

```injectablephp
namespace UNI\Callbacks;


use UNI\Controllers\MessageController;

class NextMessageCallback {

    public static function handle($message_id, $chats) 
    {
        
    }

}

```
В роутер пропишем обработчик
```injectablephp
public function callback_route()
    {
        switch ($this->callback) {
            case "NextMessage":
                NextMessageCallback::handle($this->params, $this->chat);
                break;
        }
    }
```
>В параметрах мы знаем, что передается ID сообщения, также мы ранее в роуте сохранили чат в свойство

Завершим метод **handle()**
```injectablephp
public static function handle($message_id, $chat_id) 
{
    $message_model = new MessageModel();
    $message = $message_model->get_all(["*"], ["ID" => $message_id])[0];
    $text = $message['UF_MESSAGE'];
    
    $message_controller = new MessageController();
    $message_controller->send_message($text, $chat_id)
}
```