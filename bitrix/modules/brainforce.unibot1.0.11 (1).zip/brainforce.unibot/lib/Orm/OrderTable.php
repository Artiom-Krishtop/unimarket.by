<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class OrderTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_orders';
    }

    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),

            new Entity\TextField('UF_ORDER', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\DatetimeField('UF_DATE', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_IBLOCK_ID', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_BOT_ID', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_TG_USER_ID', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_STATUS', array(
                'nullable' => true
            )),
        );
    }
}