<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class MessageTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_messages';
    }

    /**
     * @throws \Bitrix\Main\SystemException
     */
    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_COMMAND', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_SEGMENTS', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\TextField('UF_MESSAGES', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\TextField('UF_USERS', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\DatetimeField('UF_DATE', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_BOT_ID', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_SORT', array(
                'nullable' => true
            )),
        );
    }
}