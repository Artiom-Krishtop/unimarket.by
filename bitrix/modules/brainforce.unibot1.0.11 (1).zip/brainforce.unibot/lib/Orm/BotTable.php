<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class BotTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_bots';
    }

    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_NAME', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_API_KEY', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_USER_ID', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_IBLOCK_ID', array(
                'nullable' => true
            )),
        );
    }
}