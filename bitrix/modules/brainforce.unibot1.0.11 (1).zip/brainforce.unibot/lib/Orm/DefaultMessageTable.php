<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class DefaultMessageTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_default_messages';
    }

    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_BUTTON_TEXT', array(
                'nullable' => true,
                'fetch_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_decode($value);
                        }
                    );
                },
                'save_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_encode($value);
                        }
                    );
                },
            )),
            new Entity\StringField('UF_MESSAGE', array(
                'nullable' => true,
                'fetch_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_decode($value);
                        }
                    );
                },
                'save_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_encode($value);
                        }
                    );
                },
            )),
            new Entity\StringField('UF_NAME', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_BOT_ID', array(
                'nullable' => true
            )),
        );
    }
}