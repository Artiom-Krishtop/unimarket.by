<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class MenuTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_menu';
    }

    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_NAME'),
            new Entity\StringField('UF_ROW_1', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\StringField('UF_ROW_2', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\StringField('UF_ROW_3', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\IntegerField('UF_BOT_ID'),
        );
    }
}