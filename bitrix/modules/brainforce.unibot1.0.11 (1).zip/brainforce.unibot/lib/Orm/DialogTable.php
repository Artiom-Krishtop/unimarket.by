<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class DialogTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_dialogs';
    }

    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_MESSAGE_ID', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_FROM', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_TO', array(
                'nullable' => true
            )),
            new Entity\TextField('UF_MESSAGE', array(
                'nullable' => true,
                'fetch_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_decode($value);
                        }
                    );
                },
                'save_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_encode($value);
                        }
                    );
                },
            )),
            new Entity\DatetimeField('UF_DATE'),
            new Entity\IntegerField('UF_BOT_ID', array(
                'nullable' => true
            )),

        );
    }
}