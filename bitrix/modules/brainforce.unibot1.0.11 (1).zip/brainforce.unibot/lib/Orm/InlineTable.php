<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class InlineTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_buttons_inline';
    }

    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_TEXT', array(
                'nullable' => true,
                'fetch_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_decode($value);
                        }
                    );
                },
                'save_data_modification' => function () {
                    return array(
                        function ($value) {
                            return json_encode($value);
                        }
                    );
                },
            )),
            new Entity\StringField('UF_TYPE', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_ACTION', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_ACTION_VALUE', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_DESCRIPTION', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_BOT_ID', array(
                'nullable' => true
            )),
        );
    }
}