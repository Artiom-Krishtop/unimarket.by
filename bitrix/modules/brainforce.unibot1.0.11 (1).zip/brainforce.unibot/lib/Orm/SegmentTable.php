<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class SegmentTable extends Entity\DataManager
{
    public static function getTableName(): string
    {
        return 'uni_segments';
    }

    public static function getMap(): array
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_NAME', array(
                'nullable' => true
            )),
            new Entity\BooleanField('UF_PUBLIC', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_BOT_ID', array(
                'nullable' => true
            )),
        );
    }
}