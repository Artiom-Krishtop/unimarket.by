<?php

namespace Brainforce\Unibot\Orm;

use Bitrix\Main\Entity;
use Bitrix\Main\Type;

class UserTable extends Entity\DataManager
{
    public static function getTableName()
    {
        return 'uni_users';
    }

    public static function getMap()
    {
        return array(
            new Entity\IntegerField('ID', array(
                'primary' => true,
                'autocomplete' => true
            )),
            new Entity\StringField('UF_NAME', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_USERNAME', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_PHONE', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_CHAT_ID'),
            new Entity\StringField('UF_SEGMENT', array(
                'serialized' => true,
                'nullable' => true
            )),
            new Entity\DatetimeField('UF_DATE_REGISTRATION', array(
                'nullable' => true
            )),
            new Entity\IntegerField('UF_BOT_ID', array(
                'nullable' => true
            )),
            new Entity\StringField('UF_CURRENT_CHAT', array(
                'nullable' => true
            )),
        );
    }
}