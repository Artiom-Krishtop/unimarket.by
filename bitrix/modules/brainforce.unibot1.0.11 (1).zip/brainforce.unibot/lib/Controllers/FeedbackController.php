<?php

namespace Brainforce\Unibot\Controllers;

use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Dto\DialogDto;
use Brainforce\Unibot\Dto\UserDto;
use Brainforce\Unibot\Models\DialogModel;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;
use TgBotApi\BotApiBase\Type\InlineKeyboardMarkupType;


class FeedbackController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public static function send_message(ParamsCollection $params)
    {
        $messages = [];

        if ($chat = self::is_set_current_chat($params)) {

            $messages[] = MessageController::create_message($params->message_text, $chat);

        } else {

            $admins = self::get_admin($params);

            if (!$admins['cur_chat']) {

                $keyboard = self::create_accept_keyboard($params->chat['id']);

            }

            foreach ($admins['admins'] as $admin) {

                $messages[] = MessageController::create_message($params->message_text, $admin['UF_CHAT_ID'], $keyboard ?? null);

            }
        }

        $bot = new BotController($params->bot['UF_API_KEY']);

        $bot->send($messages);

        $dialog_dto = new DialogDto();
        $dialog_dto->from = $params->chat['id'];
        $dialog_dto->to = $messages[0]->chatId;
        $dialog_dto->message_id = $params->message_id;
        $dialog_dto->message = $params->message_text;
        $dialog_dto->date = new DateTime();
        $dialog_dto->bot_id = $params->bot['ID'];
        DialogModel::add($dialog_dto);

    }

    public static function get_admin(ParamsCollection $params): array
    {

        $admin = UserModel::first(['*'], ['UF_CURRENT_CHAT' => $params->chat['id']]);

        if ($admin) {

            return ['admins' => [$admin], 'cur_chat' => true];

        } else {

            $segments = SegmentModel::get_for_bot($params->bot['ID']);

            $admins = UserModel::get_by_segment([array_column($segments, 'ID', 'UF_NAME')['admin']]);
            return ['admins' => $admins, 'cur_chat' => false];

        }

    }

    public static function create_accept_keyboard($chat_id): InlineKeyboardMarkupType
    {

        $accept_button = ButtonsController::create_inline_button("Начать диалог", ['callbackData' => 'AcceptDialog ' . $chat_id]);
        return ButtonsController::create_inline_keyboard([[$accept_button]]);

    }

    public static function is_set_current_chat(ParamsCollection $params)
    {

        $user = UserModel::get_users_by_chat_ids([$params->chat['id']], $params->bot['ID'])[0];

        if ($user['UF_CURRENT_CHAT']) {

            return $user['UF_CURRENT_CHAT'];

        } else {

            return null;

        }

    }

    public static function close_dialog(ParamsCollection $params)
    {

        $user = UserModel::get_users_by_chat_ids([$params->chat['id']], 1)[0];
        $user_dto = UserDto::make_instance($user);
        $user_dto->current_chat = "";
        UserModel::update($user_dto);

    }

}