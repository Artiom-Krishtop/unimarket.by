<?php

namespace Brainforce\Unibot\Controllers;


use Brainforce\Unibot\Models\DefaultMessageModel;
use Exception;
use TgBotApi\BotApiBase\Type\InlineKeyboardButtonType;
use TgBotApi\BotApiBase\Type\InlineKeyboardMarkupType;
use TgBotApi\BotApiBase\Type\KeyboardButtonType;
use TgBotApi\BotApiBase\Type\ReplyKeyboardMarkupType;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Models\InlineModel;
use Brainforce\Unibot\Models\ReplyModel;
use Brainforce\Unibot\Models\MenuModel;

class ButtonsController extends Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @throws Exception
     */
    public static function create_menu($menu_id): ReplyKeyboardMarkupType
    {
        $menu_model = new MenuModel();
        $menu = $menu_model->get_by_id($menu_id);

        $rows = [];
        foreach ($menu as $key => $value) {
            if (strstr($key, 'UF_ROW')) {
                $rows[$key] = $value;
            }
        }

        $buttons_array = [];

        array_walk_recursive($rows, function ($item, $key) use (&$buttons_array) {
            $buttons_array[] = $item;
        });

        $buttons_array = array_unique($buttons_array);

        $buttons_model = new ReplyModel();
        $hl_buttons = $buttons_model->get_all(['*'], ['ID' => $buttons_array]);
        $buttons = [];

        foreach ($hl_buttons as $hl_button) {
            $buttons[$hl_button['ID']] = self::create_reply_button(
                $hl_button['UF_TEXT'],
                [
                    'contact' => !!$hl_button['UF_CONTACT'],
                    'location' => !!$hl_button['UF_LOCATION']
                ]);
        }

        foreach ($rows as $row_number => $row_value) {
            if (is_array($row_value)) {
                foreach ($row_value as $button_key => $button_value) {
                    $rows[$row_number][$button_key] = $buttons[$button_value];
                }
            }
        }

        $rows = array_filter($rows);

        return self::create_reply_keyboard(array_values($rows));
    }

    public static function create_buttons($buttons_arr): ?InlineKeyboardMarkupType
    {

        $buttons = [];

        foreach ($buttons_arr as $button_id) {

            $button = InlineModel::get_by_id($button_id);
            $button_text = $button['UF_TEXT'];
            if ($button['UF_ACTION_VALUE']) {
                $button_params = [$button['UF_TYPE'] => $button['UF_ACTION'] . " " . $button['UF_ACTION_VALUE']];
            } else {
                $button_params = [$button['UF_TYPE'] => $button['UF_ACTION']];
            }
            $button = ButtonsController::create_inline_button($button_text, $button_params);
            $buttons[][] = $button;

        }

        if ($buttons) {

            return ButtonsController::create_inline_keyboard($buttons);

        } else {

            return null;
        }
    }

    /**
     * @throws Exception
     */
    public static function create_default_reply_button($name, $bot_id, $params = null): KeyboardButtonType
    {
        $default_button = DefaultMessageModel::first(['*'], ['UF_NAME' => $name, 'UF_BOT_ID' => $bot_id]);

        return self::create_reply_button($default_button['UF_BUTTON_TEXT'], $params);
    }

    public static function create_inline_button($text, $params = ['url' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ']): InlineKeyboardButtonType
    {
        $button = new InlineKeyboardButtonType;
        $method = array_keys($params)[0];
        $button->text = $text;
        $button->$method = $params[$method];
        return $button;
    }

    public static function create_reply_button($text, $params = ['contact' => false, 'location' => false]): KeyboardButtonType
    {
        $button = new KeyboardButtonType;
        $button->text = $text;
        $button->requestContact = $params['contact'];
        $button->requestLocation = $params['location'];
        return $button;
    }

    public static function create_inline_keyboard($buttons): InlineKeyboardMarkupType
    {
        $keyboard = new InlineKeyboardMarkupType;
        $keyboard->inlineKeyboard = $buttons;
        return $keyboard;
    }

    public static function create_reply_keyboard($buttons, $one_time = false): ReplyKeyboardMarkupType
    {
        $keyboard = new ReplyKeyboardMarkupType;
        $keyboard->keyboard = $buttons;
        $keyboard->resizeKeyboard = true;
        $keyboard->oneTimeKeyboard = $one_time;
        return $keyboard;
    }

}