<?php

namespace Brainforce\Unibot\Controllers;

use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\MessageTemplateModel;
use Brainforce\Unibot\Models\UserModel;
use CFile;
use Exception;
use TgBotApi\BotApiBase\Method\DeleteMessageMethod;
use TgBotApi\BotApiBase\Method\EditMessageReplyMarkupMethod;
use TgBotApi\BotApiBase\Method\EditMessageTextMethod;
use TgBotApi\BotApiBase\Method\SendDocumentMethod;
use TgBotApi\BotApiBase\Method\SendMessageMethod;
use TgBotApi\BotApiBase\Method\SendPhotoMethod;

class MessageController extends Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public static function create_message($text, $chat_id, $keyboard = null, $file_src = null , $as_document = false)
    {
        if ($file_src) {

            if ($as_document) {

                $message = new SendDocumentMethod;
                $message->document = $file_src;

            } else {

                $message = new SendPhotoMethod;
                $message->photo = $file_src;

            }

            $message->caption = $text;

        } else {

            $message = new SendMessageMethod;
            $message->text = $text;

        }

        $message->chatId = $chat_id;
        $message->parseMode = 'Markdown';

        if ($keyboard) {

            $message->replyMarkup = $keyboard;

        }

        return $message;
    }

    public static function update_inline_markup ($chat_id, $message_id, $keyboard) {
        $message = new EditMessageReplyMarkupMethod();
        $message->replyMarkup = $keyboard;
        $message->chatId = $chat_id;
        $message->messageId = $message_id;

        return $message;
    }


    public static function update_message($chat_id, $message_id, $keyboard, $text): EditMessageTextMethod
    {
        $message = new EditMessageTextMethod();
        $message->chatId = $chat_id;
        $message->messageId = $message_id;
        $message->parseMode = 'Markdown';
        $message->text = $text;
        $message->replyMarkup = $keyboard;

        return $message;
    }

    public static function delete_message($chat_id, $message_id): DeleteMessageMethod
    {
        $message = new DeleteMessageMethod();
        $message->chatId = $chat_id;
        $message->messageId = $message_id;

        return $message;
    }

    /**
     * @throws Exception
     */
    public static function create_for_command($chat_id, $bot_id, $command): array
    {
        $user = UserModel::first(['*'], ['UF_CHAT_ID' => $chat_id, 'UF_BOT_ID' => $bot_id]);
        $messages = MessageModel::get_for_bot($bot_id, ['*'], ['UF_COMMAND' => $command]);

        $messages_array = [];
        foreach ($messages as $message) {
            if (!$message['UF_SEGMENTS']) {
                $messages_array[$message['ID']] = $message;
            } else {
                foreach ($message['UF_SEGMENTS'] as $segment) {
                    if (in_array($segment, $user['UF_SEGMENT'])) {
                        $messages_array[$message['ID']] = $message;
                    }
                }
            }

        }

        $messages_array = self::sort_messages($messages_array);

        $messages_id = [];
        foreach ($messages_array as $message) {
            $messages_id = array_merge($messages_id, $message['UF_MESSAGES']);
        }

        $messages_id = array_unique($messages_id);

        $messages_result = [];

        foreach ($messages_id as $message_id) {

            $message = MessageTemplateModel::get_by_id($message_id);

            if ($message['UF_MENU']) {

                $keyboard = ButtonsController::create_menu($message['UF_MENU']);

            } elseif ($message['UF_BUTTONS']) {

                $keyboard = ButtonsController::create_buttons($message['UF_BUTTONS']);

            }

            if ($message['UF_FILE']) {

                if ($message['UF_IS_FILE']) {

                    $is_file = true;

                }

                $file_src = "https://tim-bot.ru" . CFile::GetPath($message['UF_FILE']);

            }

            $messages_result[] = self::create_message($message['UF_MESSAGE'], $chat_id, $keyboard ?? null, $file_src ?? null, $is_file ?? null);

            unset($is_file);
            unset($keyboard);
            unset($file_src);

        }

        return $messages_result;

    }

    public static function sort_messages($messages_array)
    {

        usort($messages_array, function ($a, $b) {

            if ($a['UF_SORT'] == $b['UF_SORT']) {

                return ($a['ID'] < $b['ID']) ? -1 : 1;

            }

            return ($a['UF_SORT'] < $b['UF_SORT']) ? 1 : -1;

        });

        return $messages_array;

    }

    public static function get_templates ($message_id) {

        $message = MessageModel::get_by_id($message_id);
        $templates = MessageTemplateModel::get_all(['*'], ['ID' => $message['UF_MESSAGES']]);

        $result = [];
        foreach ($message['UF_MESSAGES'] as $id) {
            $result[] = $templates[array_search($id, array_column($templates, "ID"))];
        }

        return $result;

    }

}