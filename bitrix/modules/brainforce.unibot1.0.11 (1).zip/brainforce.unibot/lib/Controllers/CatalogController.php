<?php

namespace Brainforce\Unibot\Controllers;

use CFile;
use CIBlockElement;
use CIBlockSection;
use CModule;
use Exception;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Helpers\PaginationButtonsHelper;
use TgBotApi\BotApiBase\Type\InlineKeyboardMarkupType;

CModule::IncludeModule('iblock');

class CatalogController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public static function get_sections($iblock_id, $section_id = null, $page = 1): array
    {
        $section_list_filer = ["IBLOCK_ID" => $iblock_id, 'ACTIVE' => 'Y', 'SECTION_ID' => $section_id];
        $section_list_select = ['IBLOCK_ID', 'ID', 'NAME', 'IBLOCK_SECTION_ID'];

        $section_count = CIBlockSection::GetCount($section_list_filer);
        Controller::log_telegram_errors($section_count);
        $section_list_obj = CIBlockSection::GetList(
            ["ID" => "ASC"],
            $section_list_filer,
            true,
            $section_list_select,
            ['iNumPage' => $page, 'nPageSize' => 10]
        );

        $section_list = [];
        while ($section = $section_list_obj->Fetch()) {

            $section_list['sections'][$section['ID']] = $section;

        }

        $section_list['count'] = $section_count;

        return $section_list;

    }

    public static function get_section($section_id): array
    {
        return CIBlockSection::GetByID($section_id)->Fetch();
    }


    public static function get_items($iblock_id, $section_id, $page = 1): array
    {
        $element_list_filer = ["IBLOCK_ID" => $iblock_id, 'IBLOCK_SECTION_ID' => $section_id, 'ACTIVE' => 'Y'];
        $element_list_select = ['IBLOCK_ID', 'ID', 'NAME', 'IBLOCK_SECTION_ID'];

        $element_list_count = CIBlockSection::GetSectionElementsCount($section_id, ['CNT_ACTIVE' => 'Y']);
        $element_list_obj = CIBlockElement::GetList(
            ["ID" => "ASC"],
            $element_list_filer,
            false,
            ["iNumPage" => $page, "nPageSize" => 10],
            $element_list_select
        );

        $element_list = [];

        while ($element = $element_list_obj->Fetch()) {
            $element_list['elements'][] = $element;
        }
        $element_list['count'] = $element_list_count;

        return $element_list;

    }

    /**
     * @throws Exception
     */
    public static function get_element($element_id): array
    {
        $element_filer = ['ID' => $element_id];
        $element_select = ['ID', 'IBLOCK_ID', 'NAME', 'IBLOCK_SECTION_ID', 'DETAIL_TEXT', 'PROPERTY_UF_PRICE', 'DETAIL_PICTURE', 'PROPERTY_UF_URL'];
        $element = CIBlockElement::GetList(["SORT" => "ASC"],
            $element_filer,
            false,
            false,
            $element_select
        )->Fetch();

        if ($element) {
            if ($element['DETAIL_PICTURE']) {
                $element['DETAIL_PICTURE'] = "https://tim-bot.ru" . CFile::GetPath($element['DETAIL_PICTURE']);
            }
            return $element;
        } else {
            throw new Exception('Нет элемента с ID ' . $element_id);
        }

    }

    /**
     * @throws Exception
     */
    public static function create_catalog_keyboard($iblock_id, $id = null, $page = null): InlineKeyboardMarkupType
    {
        $section_list = self::get_sections($iblock_id, $id, $page);
        $elements_list = self::get_items($iblock_id, $id, $page);

        if ($section_list['count'] > 0) {

            self::log_telegram_errors(var_export($section_list, true));
            return self::create_sections_keyboard($section_list, $id, $page);

        } elseif ($elements_list['count'] > 0) {

            self::log_telegram_errors(var_export($elements_list, true));
            return self::create_elements_keyboard($elements_list, $id, $page);

        } else {

            throw new Exception("В этом разделе ничего нет");

        }

    }

    public static function create_sections_keyboard($section_list, $id = null, $page = null): InlineKeyboardMarkupType
    {
        $section_buttons = [];
        foreach ($section_list['sections'] as $section) {

            $button = ButtonsController::create_inline_button("🗂 " . $section['NAME'], ['callbackData' => 'GetSection ' . $section['ID'] . "." . "1"]);
            $section_buttons[][] = $button;

        }

        if ($id) {
            $parent_section = self::get_section($id);
            $pager_buttons = PaginationButtonsHelper::load($id, $page, $section_list['count'], $parent_section['IBLOCK_SECTION_ID']);

            if (count($pager_buttons)) {
                $section_buttons = array_merge($section_buttons, $pager_buttons);
            }
        }


        return ButtonsController::create_inline_keyboard($section_buttons);

    }

    public static function create_elements_keyboard($elements_list, $id, $page): InlineKeyboardMarkupType
    {

        $parent_section = self::get_section($id);

        $elements_buttons = [];

        foreach ($elements_list['elements'] as $element) {
            $button = ButtonsController::create_inline_button("✅ " . $element['NAME'], ['callbackData' => 'GetElement ' . $element['ID']]);
            $elements_buttons[][] = $button;
        }

        $pager_buttons = PaginationButtonsHelper::load($id, $page, $elements_list['count'], $parent_section['IBLOCK_SECTION_ID']);

        if (count($pager_buttons)) {
            $elements_buttons = array_merge($elements_buttons, $pager_buttons);
        }

        return ButtonsController::create_inline_keyboard($elements_buttons);
    }
}


