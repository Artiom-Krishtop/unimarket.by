<?php

namespace Brainforce\Unibot\Controllers;

use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Dto\OrderDto;
use Brainforce\Unibot\Models\OrderModel;
use CIBlockElement;
use CModule;
use Brainforce\Unibot\Core\Controller;


class DefaultMessageController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

}