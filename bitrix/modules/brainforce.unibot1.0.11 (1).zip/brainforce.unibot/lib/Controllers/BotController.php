<?php

namespace Brainforce\Unibot\Controllers;

use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Core\Dto;
use Brainforce\Unibot\Core\Webhook;
use Brainforce\Unibot\Dto\DefaultMessageDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\DefaultMessageModel;
use Exception;
use Http\Adapter\Guzzle6\Client;
use Http\Factory\Guzzle\RequestFactory;
use Http\Factory\Guzzle\StreamFactory;
use TgBotApi\BotApiBase\ApiClient;
use TgBotApi\BotApiBase\BotApi;
use TgBotApi\BotApiBase\BotApiNormalizer;
use TgBotApi\BotApiBase\Exception\ResponseException;
use TgBotApi\BotApiBase\Method\GetMeMethod;

class BotController extends Controller
{

    protected $token;
    protected $bot;

    public function __construct($token)
    {
        parent::__construct();
        $this->token = $token;
        $this->bot = $this->set_bot();
    }

    public static function add(Dto $dto): array
    {
        try {

            $bot_model = new BotModel();
            $new_bot_data = $bot_model->add($dto);

            $defaults = [
                [
                    'UF_BUTTON_TEXT' => 'Отправить контакт',
                    'UF_MESSAGE' => 'Контакт отправлен',
                    'UF_NAME' => 'send_contact'
                ],
                [
                    'UF_BUTTON_TEXT' => '"Не отправлять',
                    'UF_MESSAGE' => 'Контакт не отправлен',
                    'UF_NAME' => 'do_not_send_contact'
                ],
                [
                    'UF_BUTTON_TEXT' => 'Завершить диалог',
                    'UF_MESSAGE' => 'Диалог завершен',
                    'UF_NAME' => 'close_dialog'
                ]
            ];

            foreach ($defaults as $default) {
                $default_dto = DefaultMessageDto::make_instance($default);
                $default_dto->bot_id = $new_bot_data['ID'];
                DefaultMessageModel::add($default_dto);
            }

            $path_to_hooks = $_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/hooks/";
            $hook_model = file_get_contents($path_to_hooks . 'hook.stub');
            $hook_file = $path_to_hooks . $new_bot_data['UF_NAME'] . ".php";
            file_put_contents($hook_file, $hook_model);

            $hook_file_path = "/local/Unibot/hooks/" . $new_bot_data['UF_NAME'] . ".php";
            Webhook::set_webhook($hook_file_path, $new_bot_data['UF_API_KEY']);

            return $new_bot_data;

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return [];

        }
    }

    public static function webhook_info($bot_name): array
    {
        $bot_model = new BotModel();
        try {

            $bot = $bot_model->get_by_name($bot_name);
            return Webhook::get_webhook_info($bot['UF_API_KEY']);

        } catch (Exception $e) {

            Controller::log_telegram_errors($e->getMessage());
            return [];
        }

    }

    private function set_bot(): BotApi
    {
        $requestFactory = new RequestFactory();
        $streamFactory = new StreamFactory();
        $client = new Client();
        $apiClient = new ApiClient($requestFactory, $streamFactory, $client);

        return new BotApi($this->token, $apiClient, new BotApiNormalizer());
    }


    public function send($messages)
    {
        $i = 1;

        foreach ($messages as $message) {

            if ($i > 30) {
                sleep(1);
            }

            $i++;

            try {
                $this->bot->send($message);
            } catch (ResponseException $e) {
                $this->log_telegram_errors($e->getMessage());
            }

        }

    }

    public function update($messages)
    {

        $i = 0;

        foreach ($messages as $message) {

            if ($i > 30) {
                sleep(1);
            }

            $i++;

            try {
                $this->bot->edit($message);
            } catch (ResponseException $e) {
                $this->log_telegram_errors($e->getMessage());
            }

        }

    }

    public function delete($messages)
    {
        $i = 0;

        foreach ($messages as $message) {

            if ($i > 30) {
                sleep(1);
            }

            $i++;

            try {
                $this->bot->delete($message);
            } catch (ResponseException $e) {
                $this->log_telegram_errors($e->getMessage());
            }

        }

    }

}