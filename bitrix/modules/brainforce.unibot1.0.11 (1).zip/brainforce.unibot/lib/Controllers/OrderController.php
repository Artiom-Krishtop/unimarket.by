<?php

namespace Brainforce\Unibot\Controllers;

use Bitrix\Main\Type\DateTime;
use Brainforce\Unibot\Dto\OrderDto;
use Brainforce\Unibot\Models\OrderModel;
use CIBlockElement;
use CModule;
use Brainforce\Unibot\Core\Controller;
use phpDocumentor\Reflection\Types\Self_;

CModule::IncludeModule('iblock');

class OrderController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public static function create_order(OrderDto $order_dto): array
    {
        if ($order_dto->id) {
            $order = OrderModel::update($order_dto);
        } else {
            $order = OrderModel::add($order_dto);
        }

        return $order;
    }

    public static function make_order($order_id): array
    {
        $exists_order = OrderModel::get_by_id($order_id);
        $order_dto = OrderDto::make_instance($exists_order);
        $order_dto->id = $order_id;
        $order_dto->date = new DateTime();
        $order_dto->status = "A";
        return OrderModel::update($order_dto);
    }

    public static function close_order($order_id): array
    {
        $exists_order = OrderModel::get_by_id($order_id);
        $order_dto = OrderDto::make_instance($exists_order);
        $order_dto->id = $order_id;
        $order_dto->date = new DateTime();
        $order_dto->status = "D";
        return OrderModel::update($order_dto);
    }

    public static function get_user_order($bot_id, $tg_user_id, $status = "C"): array
    {
        $order = OrderModel::first(['*'], ['UF_TG_USER_ID' => $tg_user_id, 'UF_BOT_ID' => $bot_id, 'UF_STATUS' => $status]);

        if ($order) {
            return self::make_order_str($order);
        } else {
            return [];
        }

    }

    public static function get_order($order_id)
    {
        $order = OrderModel::get_by_id($order_id);

        if ($order) {
            return self::make_order_str($order);
        } else {
            return [];
        }
    }

    public static function make_order_str ($order): array
    {

        $item_select = ['ID', 'IBLOCK_ID', 'NAME', 'PROPERTY_UF_PRICE'];
        $item_filer = ['ID' => array_column($order['UF_ORDER'], 'product')];
        $items_obj = CIBlockElement::GetList(
            ["ID" => "ASC"],
            $item_filer,
            false,
            false,
            $item_select

        );
        $str = "";
        $total = 0;
        while ($item = $items_obj->Fetch()) {
            $str .= "*Наименование*: " . $item['NAME'] . "\n";

            if ($item['PROPERTY_UF_PRICE_VALUE']) {
                $str .= "*Стоимость*: " . $item['PROPERTY_UF_PRICE_VALUE'] . " BYN\n";
                $total += $item['PROPERTY_UF_PRICE_VALUE'];
            }
            $str .= "\n";

        }

        $str .= "*Итого: " . $total . " BYN*";

        return [
            'message' => $str,
            'order_id' => $order['ID'],
        ];
    }
}