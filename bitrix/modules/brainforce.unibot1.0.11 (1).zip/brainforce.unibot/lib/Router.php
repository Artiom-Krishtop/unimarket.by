<?php

namespace Brainforce\Unibot;

use Brainforce\Unibot\Collections\ParamsCollection;
use Brainforce\Unibot\Commands\Command;
use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\FeedbackController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Helpers\ClassAutoloadHelper;
use Brainforce\Unibot\Validators\BotValidator;
use Brainforce\Unibot\Validators\RequestValidator;
use Exception;

class Router
{

    public function __construct($request, $bot_name)
    {

        $bot = BotValidator::validate($bot_name);
        $request_info = RequestValidator::validate($request);

        $params = ParamsCollection::create(
            $bot,
            $request_info['chat'],
            $request_info['action'],
            $request_info['parameter'],
            $request_info['message_id'],
            $request_info['message_text'],
            $request_info['phone']
        );

        switch ($request_info['type']) {
            case 'command' :
                $this->commands_route($params);
                break;
            case "callback" :
                $this->callback_route($params);
                break;
            case "default":
                $this->defaults_route($params);
                break;
            case "contact":
                $params->action = "send_contact";
                $this->defaults_route($params);
                break;
            case "feedback":
                $this->feedback_route($params);
                break;
        }

        return true;
    }

    public function commands_route(ParamsCollection $params)
    {

        $class_helper = ClassAutoloadHelper::load($params->action);
        try {
            if ($class_helper->class_name !== "") {

                new $class_helper->class_name($params);

            } else {

                new Command($params);

            }

        } catch (Exception $e) {

            $message_controller = new MessageController();
            $bot_controller = new BotController($params->bot['UF_API_KEY']);
            $message = $message_controller->create_message('Такой команды не существует', $params->chat['id']);
            $bot_controller->send([$message]);

        }

    }

    public function callback_route(ParamsCollection $params)
    {
        $class_helper = ClassAutoloadHelper::load($params->action);

        if ($class_helper->class_name !== "") {

            $class_helper->class_name::handle($params);

        } else {

            Controller::log_telegram_errors($params->action . ' нет обработчика');

        }
    }

    public function defaults_route(ParamsCollection $params)
    {
        $class_helper = ClassAutoloadHelper::load($params->action);

        if ($class_helper->class_name !== "") {

            $class_helper->class_name::handle($params);

        } else {

            Controller::log_telegram_errors($params->action . ' нет обработчика');

        }
    }

    public function feedback_route(ParamsCollection $params) {
        FeedbackController::send_message($params);
    }

}