<?php

namespace Brainforce\Unibot\Helpers;

use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Dto\UserDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MenuModel;
use Brainforce\Unibot\Models\UserModel;

class UserPhoneHelper
{
    public static function get($chat_id, $bot_id): array
    {
        $user = UserModel::get_users_by_chat_ids([$chat_id], $bot_id)[0];
        if (!$user['UF_PHONE']) {

            $send_contact_button = ButtonsController::create_default_reply_button('send_contact', $bot_id, ['contact' => true]);
            $cancel_send_contact_button = ButtonsController::create_default_reply_button('do_not_send_contact', $bot_id);
            $keyboard = ButtonsController::create_reply_keyboard([[$send_contact_button, $cancel_send_contact_button]], true);

            return [
                'phone' => false,
                'message' => "Отправить номер телефона",
                'keyboard' => $keyboard
            ];
        } else {
            return [
                'phone' => true,
                'message' => "Менеджер свяжется с вами по телефону " . $user['UF_PHONE'],
                'keyboard' => null
            ];
        }
    }

    /**
     * @throws \Exception
     */
    public static function save($chat_id, $bot_id, $phone)
    {
        
        $user = UserModel::get_users_by_chat_ids([$chat_id], $bot_id)[0];
        $user_dto = UserDto::make_instance($user);
        $user_dto->phone = $phone;
        UserModel::update($user_dto);

    }

}