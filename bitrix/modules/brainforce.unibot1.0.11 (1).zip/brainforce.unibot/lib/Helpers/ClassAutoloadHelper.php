<?php

namespace Brainforce\Unibot\Helpers;

use Brainforce\Unibot\Core\Controller;

class ClassAutoloadHelper
{
    public $class_name;
    public $error;

    public static function load(string $action): ClassAutoloadHelper
    {

        $instance = new static();
        Controller::log_telegram_errors($action);
        if (substr($action, 0, 1) === "/") {

            $class_name = substr($action, 1);
            $class_name = ucfirst($class_name);
            $class_name = $class_name . "Command";
            $type = "Commands";

        } elseif ($action{0} === strtoupper($action{0})) {

            $class_name = ucfirst($action);
            $class_name = $class_name . "Callback";
            $type = "Callbacks";

        } else {

            $class_name = explode("_", $action);
            $class_name = array_map("ucfirst", $class_name);
            $class_name = implode('', $class_name);
            $class_name = $class_name."Default";
            $type = "Defaults";

        }

        $class = self::check_file($type, $class_name);
        $instance->class_name = $class;

        return $instance;

    }

    private static function check_file($type, $class_name): string
    {

        if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/UnibotCustom/app/$type/$class_name.php")) {

            $class = "\Brainforce\UnibotCustom\\$type\\$class_name";
            require_once ($_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/UnibotCustom/app/$type/$class_name.php");

        } elseif (file_exists($_SERVER['DOCUMENT_ROOT'] . "/bitrix/modules/brainforce.unibot/lib/$type/$class_name.php")) {

            $class = "\Brainforce\Unibot\\$type\\$class_name";

        } else {

            $class = "";

        }

        return $class;

    }

}