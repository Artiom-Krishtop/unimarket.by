<?php

namespace Brainforce\Unibot\Helpers;

use Brainforce\Unibot\Controllers\ButtonsController;

class PaginationButtonsHelper
{

    public static function load($id, $page = null, $count = null, $parent_section = null): array
    {

        $pager_buttons = [];

        if ($count > 10) {
            $pager_buttons[] = self::calculate_pagination($page, $count, $id);
        }

        if ($parent_section) {
            $button = ButtonsController::create_inline_button("↩ Назад в раздел", ['callbackData' => 'GetSection ' . $parent_section]);
        } else {
            $button = ButtonsController::create_inline_button("↩ Назад в каталог", ['callbackData' => 'GetSection']);
        }

        $pager_buttons[][] = $button;


        return $pager_buttons;
    }

    private static function calculate_pagination($page, $count, $id): array
    {
        $page_buttons = [];

        $cur_page = $page."/". ceil($count/10) ;

        $prev_button = ButtonsController::create_inline_button(" ", ['callbackData' => 'Plumb']);
        $center_button = ButtonsController::create_inline_button($cur_page, ['callbackData' => 'Plumb']);
        $next_button = ButtonsController::create_inline_button(" ", ['callbackData' => 'Plumb']);

        if (intval($page) > 1) {

            $prev_button = ButtonsController::create_inline_button(
                "⬅ Назад",
                ['callbackData' => 'GetSection ' . $id . "." . (intval($page) - 1)]);

        }

        if (intval($page) <= intval($count / 10)) {

            $next_button = ButtonsController::create_inline_button(
                "Вперед ➡",
                ['callbackData' => 'GetSection ' . $id . "." . (intval($page) + 1)]);

        }

        $page_buttons[] = $prev_button;
        $page_buttons[] = $center_button;
        $page_buttons[] = $next_button;

        return $page_buttons;
    }
}