<?php

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

CModule::IncludeModule('brainforce.unibot');

use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\UserModel;

global $USER;

if (isset($_GET['bot'])) {

    $bot = BotModel::get_bot_by_id($_GET['bot'], $USER->GetID());
    $users = UserModel::get_for_bot($_GET['bot']);
    if ($bot) {
        $data = [
            'users' => $users,
            'bot' => $bot,
        ];
        echo json_encode($data);
    }
}
