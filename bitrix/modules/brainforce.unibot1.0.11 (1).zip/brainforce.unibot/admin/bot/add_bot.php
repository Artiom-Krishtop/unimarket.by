<?php
/** @global $APPLICATION */

use Bitrix\Main\UI\Extension;

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

CModule::IncludeModule('brainforce.unibot');
Extension::load("ui.vue");

global $USER;

?>

    <style>
        .add_wrapper {
            background-color: white;
            border-radius: 15px;
            width: 80%;
        }

        .add_table {

            display: table;
            border-spacing: 15px;
        }

        .add_row {
            display: table-row;
        }

        .add_cell {
            display: table-cell;
        }

        .add_cell--left {
            width: 150px;
            text-align: right;

            font-size: 13px;
            font-weight: bold;
        }

        .add_cell--right {

        }

        .add_bot_button {
            margin-top: 25px !important;
        }
    </style>
    <div class="add_wrapper" id="add_bot">

        <div class="add_table">
            <div class="add_row">

                <div class="add_cell add_cell--right">
                    <input type="button" value="Назад" onclick="location.href = 'unibot_bot_list.php'" style="margin-bottom: 15px">

                </div>
            </div>
            <div class="add_row">
                <div class="add_cell add_cell--left">Имя бота</div>
                <div class="add_cell add_cell--right">
                    <label>
                        <input type="text" v-model="bot_username">
                    </label>
                </div>
            </div>
            <div class="add_row">
                <div class="add_cell add_cell--left">Токен</div>
                <div class="add_cell add_cell--right">
                    <label>
                        <input type="text" v-model="bot_token">
                    </label>
                </div>
            </div>
            <input type="button" class="add_bot_button" value="Добавить" v-on:click="add_bot">
        </div>

    </div>

    <script>
        const add_bot = BX.Vue.create({
            el: '#add_bot',
            data: {
                bot_username: '',
                bot_token: '',
                bot_user: '<?=$USER->GetID()?>'
            },
            methods: {

                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                add_bot: function () {

                    let data = new FormData

                    data.append('bot_username', this.bot_username);
                    data.append('bot_token', this.bot_token);
                    data.append('bot_user', this.bot_user);

                    this.post('/bitrix/admin/unibot_ajax_bot_add.php', data)
                        .then((data) => console.log(data))

                }
            }
        })
    </script>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php';
