<?php
/** @global $APPLICATION */
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

CModule::IncludeModule('brainforce.unibot');

use Brainforce\Unibot\Models\BotModel;

$bots = BotModel::get_all();

global $USER;
?>

    <style>
        .table_wrapper {
            background-color: white;
            padding: 40px;
        }
        .table {
            margin-top: 15px;
            display: table;
            width: 100%;
            border: 1px solid;
            border-color: #d9e0e4 #89979d #919b9d #ebeef0;
        }

        .table_head {
            display: table-row-group;
        }

        .table_head__row {
            display: table-row;
        }

        .table_head__cell {
            display: table-cell;
            background-color: #aebbc0;
            background-image: -webkit-linear-gradient(top, #b9c7cd, #aab6b8);
            background-image: linear-gradient(to bottom, #b9c7cd, #aab6b8);
            border: 1px solid;
            border-color: #d9e0e4 #89979d #919b9d #ebeef0;
            font-weight: bold;
            height: 21px;
            vertical-align: middle;
            padding: 6px 0 4px 0;
        }

        .table_head__cell--inner {
            font-size: 13px;
            font-weight: bold;
            min-height: 18px;
            padding: 0 16px 0 16px;
            position: relative;
        }

        .table_body {
            display: table-row-group;
        }

        .table_body__row {
            display: table-row;
        }

        .table_body__row:nth-child(2n - 1) {
            background-color: #F5F9F9;
        }

        .table_body__row:hover {
            background-color: #d3e0e0
        }

        .table_body__cell {
            display: table-cell;
            border: none;
            color: #000;
            font-size: 13px;
            height: 15px;
            padding: 11px 0 10px 16px;
            text-align: left;
            vertical-align: top;
        }

    </style>
    <div class="table_wrapper">
        <input type="button" value="Добавить бота" class="add_button"
               onclick="document.location.href = 'unibot_bot_add.php'">
        <div class="table">
            <div class="table_head">
                <div class="table_head__row">
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            ID
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Имя бота
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Токен
                        </div>
                    </div>
                </div>
            </div>
            <div class="table_body">
                <? foreach ($bots as $bot): ?>
                    <div class="table_body__row">
                        <div class="table_body__cell"><?=$bot['ID']?></div>
                        <div class="table_body__cell"><?=$bot['UF_NAME']?></div>
                        <div class="table_body__cell"><?=$bot['UF_API_KEY']?></div>
                    </div>
                <? endforeach; ?>
            </div>
        </div>
    </div>


<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php';
