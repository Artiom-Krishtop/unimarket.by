<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Brainforce\Unibot\Core\Webhook;
use Brainforce\Unibot\Dto\BotDto;
use Brainforce\Unibot\Models\BotModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {

    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);

    if($bot) {

        if(file_exists($_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/" . $_POST['bot_old_name'] . ".php")) {

            rename(
                $_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/" . $_POST['bot_old_name'] . ".php",
                $_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/" . $_POST['bot_name'] . ".php"
            );

        } else {

            echo json_encode('Нет файла');
            die();

        }

        try {

            Webhook::set_webhook( "/local/Unibot/" . $_POST['bot_name'] . ".php", $_POST['bot_token'] );

            $bot_dto = new BotDto();
            $bot_dto->id = $_POST['bot'];
            $bot_dto->api_key = $_POST['bot_token'];
            $bot_dto->name = $_POST['bot_name'];
            $bot_dto->filtered = true;
            BotModel::update($bot_dto);


        } catch (Exception $e) {

            rename(
                $_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/" . $_POST['bot_name'] . ".php",
                $_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/" . $_POST['bot_old_name'] . ".php"
            );

            echo json_encode($e->getMessage());
            die();

        }

        echo json_encode(['success' => 'ok']);

    }

}


