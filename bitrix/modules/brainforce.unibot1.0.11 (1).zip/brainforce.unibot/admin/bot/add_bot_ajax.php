<?php

require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

CModule::IncludeModule('brainforce.unibot');

use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Dto\BotDto;

if (isset($_POST['bot_username']) && isset($_POST['bot_token']) && isset($_POST['bot_user'])) {

    $bot_dto = new BotDto();
    $bot_dto->name = $_POST['bot_username'];
    $bot_dto->api_key = $_POST['bot_token'];
    $bot_dto->user_id = $_POST['bot_user'];

    try {

        $new_bot = BotController::add($bot_dto);
        echo json_encode(['success' => $new_bot]);

    } catch (Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }

} else {
    echo json_encode(['error' => 'Все поля должны быть заполнены']);
}

