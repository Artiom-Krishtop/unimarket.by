<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Dto\MessageDto;
use Brainforce\Unibot\Dto\MessageTemplateDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\MessageTemplateModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {
    $bot_model = new BotModel();
    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);
}


if (isset($bot) && $bot) {

    $message = MessageTemplateModel::get_by_id($_POST['message']);
    $message_dto = MessageTemplateDto::make_instance($message);

    $message_dto->id = $_POST['message'];
    $message_dto->message = $_POST['message_text'];
    $message_dto->buttons = $_POST['message_buttons'];
    $message_dto->menu = $_POST['message_menu'];
    $message_dto->bot_id = $_POST['bot'];
    $message_dto->is_file = $_POST['is_file'];

    if ($_POST['remove_file'] == "Y") {
        $message_dto->file = '';
    }

    if ($_FILES['message_file']) {
        if ($file_id = CFile::SaveFile($_FILES['message_file'], 'unibot/pictures')) {
            $message_dto->file = $file_id;
        }
    }



    $message_controller = new MessageTemplateModel();
    $message = $message_controller->update($message_dto);
    echo json_encode($message);
}


