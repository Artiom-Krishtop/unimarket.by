<?php
/** @global $APPLICATION */

use Brainforce\Unibot\Models\BotModel;
use Bitrix\Main\UI\Extension;

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

CModule::IncludeModule('brainforce.unibot');
Extension::load("ui.vue");

global $USER;

if (isset($_GET['bot'])) {
    $bot_model = new BotModel();
    $bot = $bot_model->get_bot_by_id($_GET['bot'], $USER->GetID());
}

if (isset($bot) && $bot):
    ?>

    <style>

        .table_wrapper {
            background-color: white;
            padding: 40px;
            width: 80%;
        }

        .table_title {
            font-size: 26px;
            margin-bottom: 40px;
        }

        .table {
            display: flex;
            flex-direction: column;
        }

        .table_row {

            display: flex;
            margin-bottom: 20px;
        }

        .table_row--divider {

            border-bottom: 1px solid black;

        }

        .table_cell {
            width: 300px;
            min-height: 40px;
            display: flex;
            flex-direction: column;
            margin-right: 25px;
        }

        .table_cell__title {
            text-align: center;
            font-size: 15px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .table_cell--right {
            width: 70%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding-left: 15px;

        }

        .table_cell--left {
            width: 150px;
            display: flex;
            justify-content: right;
            align-items: center;
            padding-right: 15px;
            font-weight: bold;
        }

        .table_cell__message--buttons {
            display: flex;
            flex-direction: column;
        }

        .table_cell__message {
            margin-top: 15px;
        }

        .table_cell__message--image {
            margin-bottom: 8px;
        }

        .table_cell__message--text {
            margin-bottom: 8px;
        }

        .button_wrapper {
            border: 1px solid black;
            border-radius: 5px;
            width: 100%;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 2px;
            position: relative;
        }

        .table_cell--plus {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .table_row--title {
            justify-content: center;
            font-weight: bold;
            font-size: 15px;
            text-decoration: underline;
        }

        select {
            min-width: 300px;
        }


        .table_row--messages_wrapper {
            padding-bottom: 30px;
            border-bottom: 1px solid black;
            margin-bottom: 30px;
        }

        .button_more_info {
            position: absolute;
            height: 50px;
            width: 350px;
            background-color: #A8DADC;
            display: flex;
            justify-content: center;
            align-items: center;
        }

    </style>
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/preloader.css">
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/alert.css">


    <div class="table_wrapper" id="add_message">
        <input type="button" value="Назад" onclick="location.href = 'unibot_admin.php?bot=<?= $_GET['bot'] ?>'"
               style="margin-bottom: 15px">
        <div class="alert_message alert_message--success" v-if="success">
            Сообщение обновлено
        </div>

        <div class="alert_message alert_message--error" v-if="error">
            Сообщение не обновлено
        </div>

        <div class="preloader" v-if="is_fetching">
            <div class="lds-dual-ring"></div>
        </div>
        <div class="table_title">
            Обновление сообщения
        </div>
        <div class="table">
            <div class="table_row table_row--messages_wrapper">
                <div class="table_cell" v-for="selected in selected_templates">
                    <div class="table_cell__title">Сообщение {{ selected.order }}</div>
                    <select v-on:change="change_message(selected.order, $event.target.value)">
                        <option value="">Не выбрано</option>
                        <option v-for="template in templates" v-bind:value="template.ID">
                            {{ template.UF_MESSAGE.substr(0, 40) }}
                        </option>
                    </select>
                    <div class="table_cell__message">
                        <img class="table_cell__message--image" v-if="selected.template.UF_FILE"
                             :src="selected.template.UF_FILE" alt="" width="300px">
                        <div class="table_cell__message--text" v-if="selected.template.UF_MESSAGE">
                            {{ selected.template.UF_MESSAGE.substr(0, 150) }}
                        </div>
                        <div class="table_cell__message--buttons" v-if="selected.template.UF_INLINE_BUTTONS">
                            <div class="button_wrapper" v-for="inline_button in selected.template.UF_INLINE_BUTTONS"
                                 v-bind:title="inline_button.UF_TYPE +' '+ inline_button.UF_ACTION +' '+ inline_button.UF_ACTION_VALUE">
                                {{ inline_button.UF_TEXT}}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table_cell" v-if="messages_count < 3">
                    <div class="table_cell--plus">
                        <input type="button" value="+" v-on:click="add_template">
                    </div>
                </div>
            </div>

            <div class="table_row table_row--title">
                Параметры сообщения
            </div>

            <div class="table_row">
                <div class="table_cell--left">
                    Команда
                </div>
                <div class="table_cell--right">
                    <input type="text" v-model="command">
                </div>
            </div>

            <div class="table_row">
                <div class="table_cell--left">
                    Сегменты
                </div>
                <div class="table_cell--right">
                    <select v-model="segments" multiple>
                        <option v-for="segment in segments_list" v-bind:value="segment.ID">{{ segment.UF_NAME}}
                        </option>
                    </select>
                </div>
            </div>


            <div class="table_row">
                <div class="table_cell--left">
                    <input type="button" value="Сохранить" v-on:click="save_message">
                </div>
            </div>

        </div>
    </div>


    <script>
        const add_message = BX.Vue.create({
            el: '#add_message',

            data: {
                messages_count: 1,

                cur_message: {},

                command: "",
                segments: [],

                templates: [],
                selected_templates: [],

                is_fetching: true,
                success: false,
                error: false,

                segments_list: [],
                users_list: []

            },

            methods: {
                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                get: async function (url) {
                    const response = await fetch(url, {
                        method: 'GET',
                    })
                    return response.json();
                },

                add_template: function () {
                    let new_template = {
                        order: this.selected_templates.length + 1,
                        template: []
                    }
                    this.selected_templates.push(new_template)
                    this.messages_count = this.messages_count + 1
                },

                change_message: function (order, template_id) {
                    if (template_id) {
                        this.selected_templates[order - 1].template = this.templates.find((element) => {
                            if (element.ID === template_id) {
                                return element.ID
                            }
                        })
                    } else {
                        this.selected_templates[order - 1].template = [];
                    }

                },

                save_message: function () {
                    this.is_fetching = true;
                    let data = new FormData;
                    data.append('command', this.command);

                    data.append('message_id', this.cur_message.ID);
                    this.segments.forEach((item) => {
                        data.append('segments[]', item)
                    })

                    this.selected_templates.forEach((item) => {
                        if (item.template.ID !== undefined) {
                            data.append('templates[]', item.template.ID)
                        }
                    })

                    data.append('bot', <?=$_GET['bot']?>)
                    data.append('user', <?=$USER->GetID()?>)

                    this.post('/bitrix/admin/unibot_ajax_message_update.php', data)
                        .then((data) => {
                            if (data.error) {

                                this.error = true
                                this.success = false

                            } else {

                                this.error = false
                                this.success = true
                                console.log(data)

                            }
                        })
                        .finally(() => {
                            this.is_fetching = false
                        })

                }
            },

            created: function () {

                this.get('/bitrix/admin/unibot_ajax_message.php?bot='
                    + <?=$_GET['bot']?> + '&user=' + <?=$USER->GetID()?> + "&message=" + <?=$_GET['message']?>)
                    .then((data => {
                        this.templates = data.data.templates
                        this.segments_list = data.data.segments
                        this.cur_message = data.data.message

                        this.command = this.cur_message.UF_COMMAND
                        this.segments = this.cur_message.UF_SEGMENTS

                        this.cur_message.UF_MESSAGES.forEach((item, index) => {

                            let template = {
                                order: index + 1,
                                template: this.templates.find((element) => {
                                    if (element.ID == item) {
                                        return element
                                    }
                                })
                            }
                            this.selected_templates.push(template)
                        })

                        console.log(data)
                    }))
                    .finally(() => {
                        this.is_fetching = false
                    })
            },


        })
    </script>


<?php
endif;
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php'; ?>
