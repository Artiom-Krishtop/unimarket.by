<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\InlineModel;
use Brainforce\Unibot\Models\MenuModel;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\MessageTemplateModel;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_GET['bot']) && isset($_GET['user'])) {
    $bot_model = new BotModel();
    $bot = $bot_model->get_bot_by_id($_GET['bot'], $_GET['user']);
}

if (isset($bot) && $bot):

    try {

        $data = [];

        $data['templates'] = MessageTemplateModel::get_for_bot($bot['ID']);
        $data['segments'] = SegmentModel::get_for_bot($bot['ID']);
        $data['users'] = UserModel::get_for_bot($bot['ID']);
        $inline_buttons = InlineModel::get_for_bot($bot['ID']);

        foreach ($data['templates'] as $key => $template) {
            if($template['UF_BUTTONS']) {
                foreach ($template['UF_BUTTONS'] as $button) {
                    $data['templates'][$key]['UF_INLINE_BUTTONS'][] = $inline_buttons[array_flip(array_column($inline_buttons, 'ID'))[$button]];
                }
            }

            if ($template['UF_FILE']) {

                $data['templates'][$key]['UF_FILE'] = CFile::GetPath($template['UF_FILE']);
            }

        }

        if (isset($_GET['message'])) {
            $message_model = new MessageModel();
            $message = $message_model->get_for_bot($bot['ID'],['*'], ['ID' => $_GET['message']])[0];
            $data['message'] = $message;
        }

        echo json_encode(['data' => $data]);

    } catch (Exception $e) {

        echo json_encode(['error' => $e->getMessage()]) ;

    }

endif;