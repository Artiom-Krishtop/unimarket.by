<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Dto\MessageDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\UserModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {
    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);
}

if (isset($bot) && $bot) {

    try {
        $message_dto = new MessageDto();
        $message_dto->messages = $_POST['templates'];
        $message_dto->segments = $_POST['segments'];
        $message_dto->command = $_POST['command'];
        $message_dto->date = new \Bitrix\Main\Type\DateTime();
        $message_dto->bot_id = $_POST['bot'];
        $message_dto->sort = 100;

        $message = MessageModel::add($message_dto);

        if ($_POST['users_to_send']) {

            $users = UserModel::get_all(['*'], ['ID' => $_POST['users_to_send']]);

        } elseif ($_POST['segments_to_send']) {

            $users = UserModel::get_by_segment($_POST['segments_to_send']);

        }

        if (isset($users)) {

            $templates = MessageController::get_templates($message['ID']);

            $messages = [];

            foreach ($users as $user) {

                foreach ($templates as $template) {

                    if ($template['UF_MENU']) {

                        $keyboard = ButtonsController::create_menu($template['UF_MENU']);

                    } elseif ($template['UF_BUTTONS']) {

                        $keyboard = ButtonsController::create_buttons($template['UF_BUTTONS']);

                    }

                    if ($template['UF_FILE']) {

                        if ($template['UF_IS_FILE']) {

                            $is_file = true;

                        }

                        $file_src = "https://brainforce.by" . CFile::GetPath($template['UF_FILE']);

                    }

                    $messages[] = MessageController::create_message($template['UF_MESSAGE'], $user['UF_CHAT_ID'], $keyboard ?? null, $file_src ?? null, $is_file ?? null);

                    unset($is_file);
                    unset($keyboard);
                    unset($file_src);

                }

            }

            $bot_controller = new BotController($bot['UF_API_KEY']);
            $bot_controller->send($messages);

        }

        echo json_encode(['success' => $message]);

    } catch (Exception $e) {

        Controller::log_telegram_errors($e->getMessage());
        echo json_encode(['error' => $e->getMessage()]);

    }


}