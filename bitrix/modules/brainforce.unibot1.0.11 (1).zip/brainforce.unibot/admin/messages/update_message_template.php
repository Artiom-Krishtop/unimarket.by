<?php
/** @global $APPLICATION */

use Brainforce\Unibot\Models\BotModel;
use Bitrix\Main\UI\Extension;

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

CModule::IncludeModule('brainforce.unibot');
Extension::load("ui.vue");

global $USER;

if (isset($_GET['bot'])) {
    $bot = BotModel::get_bot_by_id($_GET['bot'], $USER->GetID());
}

if (isset($bot) && $bot):
    ?>


    <style>
        .table_wrapper {
            background-color: white;
            padding: 40px;
            width: 80%;
        }

        .table_title {
            font-size: 26px;
            margin-bottom: 40px;
        }

        .table {
            display: flex;
            flex-direction: column;
        }

        .table_row {

            display: flex;
            margin-bottom: 20px;
        }

        .table_cell {
            min-height: 40px;
        }

        .table_cell--right {
            width: 70%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding-left: 15px;

        }

        .table_cell--left {
            width: 150px;
            display: flex;
            justify-content: right;
            align-items: center;
            padding-right: 15px;
            font-weight: bold;
        }

        .file_preview img {
            padding-top: 25px;
            width: 300px;
        }

        select {
            min-width: 300px;
        }

        .is_file_wrapper {
            margin-top: 15px;
        }

        .file_preview {
            margin-top: 15px;
        }
        .file_preview--file {
            width: 150px;
            height: 150px;
            background-color: #e0ecec;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 5px;
        }
        .file_preview--file_wrapper {
            width: 120px;
            height: 120px;
            border: 2px dashed gray;
            display: flex;
            align-items: center;
            flex-direction: column;
            justify-content: center;
            border-radius: 2px;
        }

    </style>
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/preloader.css">
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/alert.css">

    <div class="table_wrapper" id="add_message">
        <input type="button" value="Назад" onclick="location.href = 'unibot_admin.php?bot=<?=$_GET['bot']?>'" style="margin-bottom: 15px">

    <div class="alert_message alert_message--success" v-if="success">
            Сообщение обновлено
        </div>

        <div class="alert_message alert_message--error" v-if="error">
            Сообщение не обновлено
        </div>

        <div class="preloader" v-if="is_fetching">
            <div class="lds-dual-ring"></div>
        </div>

        <div class="table_title">
            Обновить сообщения
        </div>
        <div class="table">
            <div class="table_row">
                <div class="table_cell table_cell--left">Файл</div>
                <div class="table_cell table_cell--right">
                    <div>
                        <div class="adm-input-file">
                            <span>Добавить файл</span>
                            <input type="file" name="message_file" ref="file" class="adm-designed-file"
                                   v-on:change="handleFileUpload">
                        </div>

                        <div class="is_file_wrapper">
                            Как файл
                            <input type="checkbox" v-model="is_file">
                        </div>
                    </div>
                    <div class="file_preview">
                        <img class="file_preview--image" v-bind:src="preview_file_src" alt=""
                             v-if="preview_file_src && is_image" v-on:click="removeImage">
                        <div v-if="(!is_image && message_file.name) || (!is_image && filename)" class="file_preview--file" v-on:click="removeImage">
                            <div class="file_preview--file_wrapper">
                                <div>
                                    <svg xmlns="http://www.w3.org/2000/svg" height="48px" viewBox="0 0 24 24" width="48px"
                                         fill="#000000">
                                        <path d="M0 0h24v24H0V0z" fill="none"/>
                                        <path d="M8 16h8v2H8zm0-4h8v2H8zm6-10H6c-1.1 0-2 .9-2 2v16c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/>
                                    </svg>
                                </div>
                                <div>
                                    {{ filename }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table_row">
                <div class="table_cell table_cell--left">Текст сообщения</div>
                <div class="table_cell table_cell--right">
                    <label>
                        <textarea cols="60" rows="10" v-model="message_text"></textarea>
                    </label>
                </div>
            </div>
            <div class="table_row">
                <div class="table_cell table_cell--left"></div>
                <div class="table_cell table_cell--right">
                    <i>Для сообщения можно выбрать либо меню, либо кнопки</i>
                </div>
            </div>
            <div class="table_row">
                <div class="table_cell table_cell--left">Кнопки</div>
                <div class="table_cell table_cell--right">
                    <label>
                        <select multiple v-model="message_buttons">
                            <option v-for="button in buttons_list" v-bind:value="button.ID">
                                {{ button.UF_TEXT }}
                            </option>
                        </select>
                    </label>
                </div>
            </div>
            <div class="table_row">
                <div class="table_cell table_cell--left">Меню</div>
                <div class="table_cell table_cell--right">
                    <label>
                        <select v-model="message_menu">
                            <option value="">Без меню</option>
                            <option v-for="menu in menu_list" v-bind:value="menu.ID">
                                {{ menu.UF_NAME }}
                            </option>
                        </select>
                    </label>
                </div>
            </div>
            <div class="table_row">
                <div class="table_cell table_cell--left">
                    <input type="button" value="Отправить" v-on:click="update_message">
                </div>
            </div>
        </div>
    </div>


    <script>
        const add_message = BX.Vue.create({

            el: '#add_message',

            data: {

                message_text: '',
                message_buttons: [],
                message_menu: '',
                message_file: '',
                prev_file_src: '',
                preview_file_src: '',
                is_file: true,
                is_image: false,

                filename: "",

                buttons_list: [],
                menu_list: [],

                is_fetching: true,
                success: false,
                error: false

            },

            methods: {

                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                get: async function (url) {
                    const response = await fetch(url, {
                        method: 'GET',
                    })
                    return response.json();
                },

                handleFileUpload: function () {
                    this.message_file = this.$refs.file.files[0];
                    console.log(this.message_file);

                    const preview = (file) => {
                        if (this.message_file.type.match(/image.*/)) {
                            this.is_image = true;
                            this.is_file = false;
                        } else {
                            this.is_image = false;
                            this.is_file = true;
                        }
                        const reader = new FileReader();
                        reader.addEventListener('load', (evt) => {
                            this.preview_file_src = evt.target.result
                        })
                        reader.readAsDataURL(file);

                        this.preview_file_name = this.message_file.name


                    }
                    preview(this.message_file)
                },

                removeImage: function () {

                    this.message_file = ''
                    this.preview_file_src = ''
                    this.$refs.file.value = ''
                    this.filename = ""

                },

                update_message: function () {
                    this.is_fetching = true
                    console.log(this.$data);
                    let data = new FormData

                    data.append('message_text', this.message_text)
                    data.append('message_menu', this.message_menu)

                    this.message_buttons.forEach((item) => {
                        data.append('message_buttons[]', item)
                    })


                    if (this.prev_file_src !== this.preview_file_src && this.preview_file_src !== "") {
                        data.append('message_file', this.message_file)
                    }

                    if (this.preview_file_src === "") {
                        data.append('remove_file', "Y");
                    }
                    data.append('is_file', this.is_file);
                    data.append('bot', <?=$_GET['bot']?>)
                    data.append('user', <?=$USER->GetID()?>)
                    data.append('message', <?=$_GET['message']?>)

                    this.post("/bitrix/admin/unibot_ajax_message_template_update.php", data)
                    
                        .then((data) => {
                            if (data.error) {

                                this.error = true
                                this.success = false

                            } else {

                                this.error = false
                                this.success = true

                            }

                            console.log(data)
                        })
                        .finally(() => {
                            this.is_fetching = false
                        })

                }

            },

            created: function () {

                this.get('/bitrix/admin/unibot_ajax_message_template.php?bot='
                    + <?=$_GET['bot']?> + '&user=' + <?=$USER->GetID()?> + "&message=" + <?=$_GET['message']?> )
                    .then((data => {

                        console.log(data)
                        this.message_text = data.data.message.UF_MESSAGE
                        this.message_buttons = data.data.message.UF_BUTTONS ?  data.data.message.UF_BUTTONS : []
                        this.message_menu = data.data.message.UF_MENU ?  data.data.message.UF_MENU : ''
                        this.preview_file_src = data.data.message.UF_FILE
                        this.prev_file_src = data.data.message.UF_FILE

                        if (data.data.message.is_image) {
                            this.is_file = false
                            this.is_image = true
                        } else  {
                            this.is_file = true
                            this.is_image = false
                        }

                        if (data.data.message.filename) {
                            this.filename = data.data.message.filename
                        }

                        this.buttons_list = data.data.inline_buttons
                        this.menu_list = data.data.menus

                    })).finally(() => {

                        this.is_fetching = false

                    })

            }
        })
    </script>


<?php
endif;
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php'; ?>
