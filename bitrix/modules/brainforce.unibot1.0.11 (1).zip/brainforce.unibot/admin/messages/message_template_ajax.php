<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\InlineModel;
use Brainforce\Unibot\Models\MenuModel;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\MessageTemplateModel;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_GET['bot']) && isset($_GET['user'])) {
    $bot_model = new BotModel();
    $bot = $bot_model->get_bot_by_id($_GET['bot'], $_GET['user']);
}

if (isset($bot) && $bot):

    $inline_buttons_model = new InlineModel();
    $menu_model = new MenuModel();
    $user_model = new UserModel();
    $segment_model = new SegmentModel();

    try {

        $data = [];
        $data['inline_buttons'] = $inline_buttons_model->get_for_bot($bot['ID']);
        $data['menus'] = $menu_model->get_for_bot($bot['ID']);
        $data['users'] = $user_model->get_for_bot($bot['ID']);
        $data['segments'] = $segment_model->get_for_bot($bot['ID']);

        if (isset($_GET['message'])) {
            $message_model = new MessageTemplateModel();
            $message = $message_model->get_for_bot($bot['ID'], ['*'], ['ID' => $_GET['message']])[0];
            if ($message['UF_FILE']) {
                $file_array = CFile::GetFileArray($message['UF_FILE']);
                $message['UF_FILE'] = $file_array['SRC'];
                $message['filename'] = $file_array['ORIGINAL_NAME'];
                if (CFile::IsImage($file_array['ORIGINAL_NAME'])) {
                    $message['is_image'] = true;
                } else {
                    $message['is_image'] = false;
                }
            }
            $data['message'] = $message;
        }

        echo json_encode(['data' => $data]);

    } catch (Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }

endif;