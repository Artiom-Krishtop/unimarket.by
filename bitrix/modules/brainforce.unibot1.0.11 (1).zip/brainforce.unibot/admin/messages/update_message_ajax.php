<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Brainforce\Unibot\Controllers\BotController;
use Brainforce\Unibot\Controllers\ButtonsController;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Core\Controller;
use Brainforce\Unibot\Dto\MessageDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\UserModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {
    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);
}

if (isset($bot) && $bot) {

    try {
        $message_dto = new MessageDto();
        $message_dto->id = $_POST['message_id'];
        $message_dto->messages = $_POST['templates'];
        $message_dto->segments = $_POST['segments'];
        $message_dto->command = $_POST['command'];
        $message_dto->date = new \Bitrix\Main\Type\DateTime();
        $message_dto->bot_id = $_POST['bot'];
        $message_dto->sort = 100;

        $message = MessageModel::update($message_dto);

        echo json_encode(['success' => $message]);

    } catch (Exception $e) {

        Controller::log_telegram_errors($e->getMessage());
        echo json_encode(['error' => $e->getMessage()]);

    }


}