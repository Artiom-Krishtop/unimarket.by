<?php
/** @global $APPLICATION */
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Brainforce\Unibot\Models\BotModel;

Loader::includeModule('brainforce.unibot');
Loc::loadMessages(__FILE__);

if ($APPLICATION->GetGroupRight('conversion') == 'D')
{
    return false;
}
else
{

    $bot_model = new BotModel();
    try {
        $items = [];
        $bots = $bot_model->get_all();

        foreach ($bots as $bot) {
            $items[] = [
                "text" => $bot['UF_NAME'],
                "url" => "unibot_admin.php?lang=".LANGUAGE_ID."&bot=".$bot['ID'],
                "more_url" => array(),
                "title" => $bot['UF_NAME'],
            ];
        }


    } catch (Exception $e) {

    }

    $menu_array = [
            'parent_menu' => 'global_menu_marketing',
            'section' => 'UNI-bot',
            'sort' => 100,
            'text' => Loc::getMessage('BRAINFORCE_UNIBOT_TEXT'),
            'title' => Loc::getMessage('BRAINFORCE_UNIBOT_TITLE'),
            'icon' => 'brainforce_unibot_menu_icon',
            'page_icon' => 'brainforce_unibot_page_icon',
            'url' => 'unibot_bot_list.php',
            'items_id' => 'menu_brainforce_unibot',
    ];

    if (isset($items)) {
        $menu_array['items'] = $items;
    }

    $menu = array(
        $menu_array
    );

    return $menu;
}