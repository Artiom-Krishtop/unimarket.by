<?php
/** @global $APPLICATION */

use Brainforce\Unibot\Models\BotModel;
use Bitrix\Main\UI\Extension;

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

CModule::IncludeModule('brainforce.unibot');
Extension::load("ui.vue");

global $USER;

if (isset($_GET['bot'])) {
    $bot = BotModel::get_bot_by_id($_GET['bot'], $USER->GetID());
}

if (isset($bot) && $bot):

    ?>
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/preloader.css">
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/alert.css">
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/style.css">

    <div class="table_wrapper" id="update_button">
        <input type="button" value="Назад" onclick="location.href = 'unibot_admin.php?bot=<?=$_GET['bot']?>'" style="margin-bottom: 15px">

        <div class="alert_message alert_message--success" v-if="success">
            Пользователь обновлен
        </div>

        <div class="alert_message alert_message--error" v-if="error">
            Пользователь не обновлен
        </div>

        <div class="preloader" v-if="is_fetching">
            <div class="lds-dual-ring"></div>
        </div>

        <div class="table_title">
            Редактирование пользователя
        </div>

        <div class="table">

            <div class="table_row">
                <div class="table_cell table_cell--left">Имя</div>
                <div class="table_cell table_cell--right">
                    {{ name }}
                </div>
            </div>

            <div class="table_row">
                <div class="table_cell table_cell--left">Имя пользователя</div>
                <div class="table_cell table_cell--right">
                    {{ username }}
                </div>
            </div>

            <div class="table_row">
                <div class="table_cell table_cell--left">Имя пользователя</div>
                <div class="table_cell table_cell--right">
                    <select v-model="segments" multiple>
                        <option v-for="segment in segments_list" v-bind:value="segment.ID">{{segment.UF_NAME}}</option>
                    </select>
                </div>
            </div>

            <div class="table_row">
                <div class="table_cell table_cell--left">

                </div>
                <div class="table_cell table_cell--right">
                    <input type="button" value="Обновить пользователя" v-on:click="update_user">
                </div>
            </div>

        </div>
    </div>

    <script>
        const add_message = BX.Vue.create({

            el: '#update_button',

            data: {
                name: '',
                username: '',
                segments: [],
                segments_list: [],

                is_fetching: true,
                success: false,
                error: false
            },
            methods: {

                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                get: async function (url) {
                    const response = await fetch(url, {
                        method: 'GET',
                    })
                    return response.json();
                },

                update_user: function () {
                    this.is_fetching = true
                    let data = new FormData

                    this.segments.forEach((segment) => {
                        data.append('segments[]', segment)
                    })

                    data.append('bot', <?=$_GET['bot']?>)
                    data.append('user', <?=$USER->GetID()?>)
                    data.append('tg_user', <?=$_GET['tg_user']?>)

                    this.post('/bitrix/admin/unibot_ajax_user_update.php', data)
                        .then((data) => {
                            if (data.error) {

                                this.error = true
                                this.success = false

                            } else {

                                this.error = false
                                this.success = true

                            }

                            console.log(data)
                        })
                        .finally(() => {
                            this.is_fetching = false
                        })

                }

            },

            created: function () {

                this.get('/bitrix/admin/unibot_ajax_user.php?bot='
                    + <?=$_GET['bot']?> + '&user=' + <?=$USER->GetID()?> + '&tg_user=' + <?=$_GET['tg_user']?>)
                    .then((data) => {
                        this.name = data.user.UF_NAME
                        this.username = data.user.UF_USERNAME
                        this.segments = data.user.UF_SEGMENT
                        this.segments_list = data.segments
                        console.log(data)

                    })
                    .finally(() => {
                        this.is_fetching = false
                    })

            }
        })
    </script>


<?php

endif;

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php'; ?>
