<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

CModule::IncludeModule('brainforce.unibot');

use Bitrix\Main\DB\SqlQueryException;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\BotModel;

if (isset($_GET['bot']) && isset($_GET['user'])) {
    $bot = BotModel::get_bot_by_id($_GET['bot'], $_GET['user']);
}

if (isset($bot) && $bot) {

    try {

        echo json_encode(['data' => SegmentModel::get_for_bot($bot['ID'])]);

    } catch (SqlQueryException | Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }
}