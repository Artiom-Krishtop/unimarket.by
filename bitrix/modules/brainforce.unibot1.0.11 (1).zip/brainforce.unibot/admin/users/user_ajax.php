<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

CModule::IncludeModule('brainforce.unibot');

use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;

if (isset($_GET['bot']) && isset($_GET['user'])) {

    $bot = BotModel::get_bot_by_id($_GET['bot'], $_GET['user']);

    if (isset($bot) && $bot) {

        try {

            $user = UserModel::get_by_id($_GET['tg_user']);
            $segments = SegmentModel::get_for_bot($bot['ID']);
            echo json_encode(['user' => $user, 'segments' => $segments]);

        } catch (\Bitrix\Main\DB\SqlQueryException | Exception $e) {

            echo json_encode(['error' => $e->getMessage()]);

        }
    }

}

