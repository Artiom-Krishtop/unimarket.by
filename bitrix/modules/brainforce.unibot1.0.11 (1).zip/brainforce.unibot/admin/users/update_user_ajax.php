<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

CModule::IncludeModule('brainforce.unibot');

use Bitrix\Main\DB\SqlQueryException;
use Brainforce\Unibot\Dto\UserDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\UserModel;

if (isset($_POST['bot']) && isset($_POST['user'])) {

    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);

    if (isset($bot) && $bot) {

        try {
            $user_dto = new UserDto();
            $user_dto->id = $_POST['tg_user'];
            $user_dto->segment = $_POST['segments'];
            $user_dto->filtered = true;

            $user = UserModel::update($user_dto);

            echo json_encode(['success' => $user]);

        } catch (SqlQueryException | Exception $e) {

            echo json_encode(['error' => $e->getMessage()]);

        }
    }

}