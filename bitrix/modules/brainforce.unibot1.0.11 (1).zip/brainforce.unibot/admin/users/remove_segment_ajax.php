<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Bitrix\Main\DB\SqlQueryException;
use Brainforce\Unibot\Dto\SegmentDto;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\BotModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {
    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);
}

if (isset($bot) && $bot) {
    try {

        $segment_dto = new SegmentDto();
        $segment_dto->id = intval($_POST['segment']);

        SegmentModel::delete($segment_dto);

        echo json_encode(['data' => 'success']);

    } catch (SqlQueryException | Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }
}