<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Bitrix\Main\DB\SqlQueryException;
use Brainforce\Unibot\Dto\SegmentDto;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\BotModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {
    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);
}

if (isset($bot) && $bot) {
    try {

        $segment_dto = new SegmentDto();
        $segment_dto->name = $_POST['segment_name'];
        $segment_dto->public = $_POST['segment_public'] == 'true' ? 1 : 0;
        $segment_dto->bot_id = $_POST['bot'];

        $new_segment = SegmentModel::add($segment_dto);

        echo json_encode(['data' => $new_segment]);

    } catch (SqlQueryException | Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }
}