<?php

use Brainforce\Unibot\Core\Webhook;
use Brainforce\Unibot\Models\BotModel;

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";


CModule::IncludeModule('brainforce.unibot');


class UnibotInfo
{
    public $bot_id;
    public $bot;
    public $webhook_info;
    public $php_version;
    public $unibot_version;
    public $webhook;
    public $pending_update_count;
    public $file_check;

    public function __construct($bot_id)
    {

        $this->bot_id = $bot_id;

        $this->bot = $this->get_bot();
        $this->php_version = $this->get_php_version();
        $this->unibot_version = $this->get_unibot_version();
        $this->webhook = $this->get_webhook_info();
        $this->pending_update_count = $this->get_pending_update_count();
        $this->file_check = $this->check_webhook_file();
    }

    public function get_bot(): array
    {
        try {
            $bot_model = new BotModel();
            $bot = $bot_model->get_by_id($this->bot_id);
            return ['success' => $bot];
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }

    }

    public function get_php_version(): array
    {
        $php_ver = floatval(phpversion());
        return $php_ver >= 7.3 ? ['success' => "Версия PHP " . phpversion()] : ['error' => "Версия должна быть не ниже 7.3"];
    }

    public function get_unibot_version(): array
    {
        if (CheckVersion(\Bitrix\Main\ModuleManager::getVersion('brainforce.unibot'), '1.0.6')) {
            return ['success' => 'Версия модуля актуальна'];
        } else {
            return ['error' => 'Версия модуля устарела'];
        }
    }

    public function get_webhook_info(): array
    {
        if (isset($this->bot['success'])) {
            $bot = $this->bot['success'];
            $webhook_info = Webhook::get_webhook_info($bot['UF_API_KEY']);

            if ($webhook_info['ok'] && $webhook_info['result']['url']) {
                $this->webhook_info = $webhook_info;
                return ['success' => 'Вебхук настроен, URL: ' . $webhook_info['result']['url']];
            } else {
                return ['error' => 'Вебхук не настроен'];
            }
        } else {
            return ['error' => "Нет бота"];
        }

    }

    public function get_pending_update_count()
    {
        if (isset($this->webhook_info)) {
            $pending_update_count = $this->webhook_info['success']['result']['pending_update_count'];
            if ($pending_update_count == 0) {
                return ['success' => 'Нет необработанных запросов'];
            } else {
                return ['warning' => 'Необработанных запросов - '. $pending_update_count];
            }
        } else {
            return ['error' => "Нет бота"];
        }
    }

    public function check_webhook_file(): array
    {
        if (isset($this->webhook_info)) {
            $webhook_url = $this->webhook_info['success']['result']['url'];
            $webhook_file_name = explode("/", $webhook_url);
            $webhook_file_name = $webhook_file_name[count($webhook_file_name) - 1];
            $webhook_file_name = explode('?', $webhook_file_name);
            $webhook_file_name = $webhook_file_name[0];

            if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/local/Unibot/" . $webhook_file_name)) {
                return ['success' => 'Файл вебхука присутствует'];
            } else {
                return ['error' => "Нет файла вебхука!"];
            }

        } else {
            return ['error' => "Нет бота"];
        }
    }

    public function return_result(): array
    {
        return [
            'php_version' => $this->php_version,
            'unibot_version' => $this->unibot_version,
            'webhook' => $this->webhook,
            'pending_update_count' => $this->pending_update_count,
            'file_check' => $this->file_check,
        ];
    }

}