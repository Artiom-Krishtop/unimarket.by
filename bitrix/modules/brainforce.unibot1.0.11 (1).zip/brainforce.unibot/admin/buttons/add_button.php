<?php
/** @global $APPLICATION */

use Brainforce\Unibot\Models\BotModel;
use Bitrix\Main\UI\Extension;

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

CModule::IncludeModule('brainforce.unibot');
Extension::load("ui.vue");

global $USER;

if (isset($_GET['bot'])) {
    $bot = BotModel::get_bot_by_id($_GET['bot'], $USER->GetID());
}

if (isset($bot) && $bot):
    ?>

    <style>
        .table_wrapper {
            background-color: white;
            padding: 40px;
            width: 80%;
        }

        .table_title {
            font-size: 26px;
            margin-bottom: 40px;
        }

        .table {
            display: flex;
            flex-direction: column;
        }

        .table_row {

            display: flex;
            margin-bottom: 20px;
        }

        .table_cell {
            min-height: 40px;
        }

        .table_cell--right {
            width: 70%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding-left: 15px;

        }

        .table_cell--left {
            width: 150px;
            display: flex;
            justify-content: right;
            align-items: center;
            padding-right: 15px;
            font-weight: bold;
        }

        select {
            min-width: 300px;
        }

    </style>
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/preloader.css">
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/alert.css">
    <div class="table_wrapper" id="add_button">
        <input type="button" value="Назад" onclick="location.href = 'unibot_admin.php?bot=<?=$_GET['bot']?>'" style="margin-bottom: 15px">

        <div class="alert_message alert_message--success" v-if="success">
            Кнопка добавлена
        </div>

        <div class="alert_message alert_message--error" v-if="error">
            Кнопка не добавлена
        </div>

        <div class="preloader" v-if="is_fetching">
            <div class="lds-dual-ring"></div>
        </div>

        <div class="table_title">
            Добавление кнопки
        </div>
        <div class="table">
            <div class="table_row">
                <div class="table_cell table_cell--left">Текст</div>
                <div class="table_cell table_cell--right">
                    <input type="text" v-model="button_text">
                </div>
            </div>

            <div class="table_row">
                <div class="table_cell table_cell--left">Краткое описание</div>
                <div class="table_cell table_cell--right">
                    <textarea v-model="button_description"></textarea>
                </div>
            </div>

            <div class="table_row">
                <div class="table_cell table_cell--left">Вид кнопки</div>
                <div class="table_cell table_cell--right">
                    <select v-model="button_kind">
                        <option v-for="kind in button_kinds" v-bind:value="kind.value">{{ kind.text }}</option>
                    </select>
                </div>
            </div>

            <div class="table_row" v-if="button_kind === 'inline'">
                <div class="table_cell table_cell--left">Тип кнопки</div>
                <div class="table_cell table_cell--right">
                    <select v-model="button_type">
                        <option v-for="type in inline_button_types" v-bind:value="type.value">{{ type.text }}</option>
                    </select>
                </div>
            </div>

            <div class="table_row" v-if="button_kind === 'reply'">
                <div class="table_cell table_cell--left">Тип кнопки</div>
                <div class="table_cell table_cell--right">
                    <select v-model="button_type">
                        <option v-for="type in reply_button_types" v-bind:value="type.value">{{ type.text }}</option>
                    </select>
                </div>
            </div>

            <div class="table_row" v-if="button_type === 'NextMessage'">
                <div class="table_cell table_cell--left">Сообщение</div>
                <div class="table_cell table_cell--right">
                    <select v-model="button_next_message">
                        <option v-for="message in messages_list" v-bind:value="message.ID">
                            {{ message.UF_MESSAGE.substr(0,100)}}
                        </option>
                    </select>
                </div>
            </div>

            <div class="table_row" v-if="button_type === 'Command'">
                <div class="table_cell table_cell--left">Команда</div>
                <div class="table_cell table_cell--right">
                    <input type="text" v-model="button_command">
                </div>
            </div>

            <div class="table_row" v-if="button_type === 'url'">
                <div class="table_cell table_cell--left">Ссылка</div>
                <div class="table_cell table_cell--right">
                    <input type="text" v-model="button_url">
                </div>
            </div>


            <div class="table_row">
                <div class="table_cell table_cell--left">
                    <input type="button" value="Добавить" v-on:click="add_button">
                </div>
                <div class="table_cell table_cell--right"></div>
            </div>

        </div>
    </div>


    <script>
        const add_button = BX.Vue.create({

            el: '#add_button',

            data: {
                button_text: '',
                button_description: '',
                button_kind: '',
                button_type: '',
                button_next_message: '',
                button_command: '',
                button_url: '',
                is_fetching: true,
                success: false,
                error: false,

                button_kinds: [
                    {
                        value: '',
                        text: 'Не выбрано'
                    },
                    {
                        value: 'inline',
                        text: 'Кнопка сообщения'
                    },
                    {
                        value: 'reply',
                        text: 'Кнопка меню'
                    }
                ],
                inline_button_types: [
                    {
                        value: '',
                        text: 'Не выбрано'
                    },
                    {
                        value: 'url',
                        text: 'Ссылка'
                    },
                    {
                        value: 'NextMessage',
                        text: 'Следующее сообщение'
                    },
                    {
                        value: 'Command',
                        text: 'Команда'
                    }
                ],
                reply_button_types: [
                    {
                        value: '',
                        text: 'Не выбрано'
                    },
                    {
                        value: 'text',
                        text: 'Текст'
                    },
                    {
                        value: 'NextMessage',
                        text: 'Следующее сообщение'
                    },
                    {
                        value: 'Command',
                        text: 'Команда'
                    },
                    {
                        value: 'Contact',
                        text: 'Контакт'
                    },
                    {
                        value: 'Location',
                        text: 'Местоположение'
                    },
                ],
                messages_list: []

            },

            methods: {

                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                get: async function (url) {
                    const response = await fetch(url, {
                        method: 'GET',
                    })
                    return response.json();
                },

                add_button: function () {
                    this.is_fetching = true
                    let data = new FormData
                    data.append('button_text', this.button_text)
                    data.append('button_description', this.button_description)
                    data.append('button_kind', this.button_kind)
                    data.append('button_type', this.button_type)
                    if (this.button_next_message !== '') {
                        data.append('button_next_message', this.button_next_message)
                    }
                    if (this.button_command !== '') {
                        data.append('button_command', this.button_command)
                    }
                    if (this.button_url !== '') {
                        data.append('button_url', this.button_url)
                    }

                    data.append('bot', <?=$_GET['bot']?>)
                    data.append('user', <?=$USER->GetID()?>)

                    this.post("/bitrix/admin/unibot_ajax_button_add.php", data)
                        .then((data) => {
                            if (data.error) {

                                this.error = true
                                this.success = false

                            } else {

                                this.error = false
                                this.success = true

                            }
                        })
                        .finally(() => {
                            this.is_fetching = false
                        })

                }

            },

            created: function () {

                this.get('/bitrix/admin/unibot_ajax_button.php?bot='
                    + <?=$_GET['bot']?> + '&user=' + <?=$USER->GetID()?>)
                    .then((data => {
                        this.messages_list = data.data.messages

                    })).finally(() => {
                    this.is_fetching = false
                })

            },

            watch: {
                button_kind: function () {
                    this.button_type = ''
                    this.button_next_message = ''
                    this.button_command = ''
                    this.button_url = ''
                },
                button_type: function () {
                    this.button_next_message = ''
                    this.button_command = ''
                    this.button_url = ''
                },
                button_next_message: function () {
                    this.button_command = ''
                    this.button_url = ''
                },
                button_command: function () {
                    this.button_next_message = ''
                    this.button_url = ''
                },
                button_url: function () {
                    this.button_command = ''
                    this.button_next_message = ''
                }
            }
        })
    </script>


<?php
endif;
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php'; ?>
