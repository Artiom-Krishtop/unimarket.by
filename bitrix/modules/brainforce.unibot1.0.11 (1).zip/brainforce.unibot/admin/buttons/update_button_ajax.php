<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Brainforce\Unibot\Dto\InlineDto;
use Brainforce\Unibot\Dto\ReplyDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\InlineModel;
use Brainforce\Unibot\Models\ReplyModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {
    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);
}

if (isset($bot) && $bot) {

    try {

        if ($_POST['button_kind'] == 'reply') {

            $button_dto = new ReplyDto();
            $button_dto->id = $_POST['button_id'];
            $button_dto->text = $_POST['button_text'];
            $button_dto->description = $_POST['button_description'];
            $button_dto->bot_id = $bot['ID'];
            $button_dto->action = $_POST['button_type'];

            switch ($_POST['button_type'] ) {
                case 'NextMessage':
                    $button_dto->action_value = $_POST['button_next_message'];
                    $button_dto->contact = 0;
                    $button_dto->location = 0;
                    break;
                case 'Command':
                    $button_dto->action_value = $_POST['button_command'];
                    $button_dto->contact = 0;
                    $button_dto->location = 0;
                    break;
                case 'Contact':
                    $button_dto->action_value = '';
                    $button_dto->contact = 1;
                    $button_dto->location = 0;
                    break;
                case 'Location':
                    $button_dto->action_value = '';
                    $button_dto->contact = 0;
                    $button_dto->location = 1;
                    break;
                default:
                    break;
            }

            $reply_button_model = new ReplyModel();
            $new_button = $reply_button_model->update($button_dto);

        } elseif ($_POST['button_kind'] == 'inline') {

            $button_dto = new InlineDto();
            $button_dto->id = $_POST['button_id'];
            $button_dto->text = $_POST['button_text'];
            $button_dto->description = $_POST['button_description'];
            $button_dto->bot_id = $bot['ID'];
            $button_dto->action = $_POST['button_type'];
            switch ($_POST['button_type'] ) {
                case 'NextMessage':
                    $button_dto->type = 'callbackData';
                    $button_dto->action = 'NextMessage';
                    $button_dto->action_value = $_POST['button_next_message'];
                    break;
                case 'Command':
                    $button_dto->type = 'callbackData';
                    $button_dto->action = 'Command';
                    $button_dto->action_value = $_POST['button_command'];
                    break;
                case 'url':
                    $button_dto->type = 'url';
                    $button_dto->action = $_POST['button_url'];
            }

            $inline_button_model = new InlineModel();
            $new_button = $inline_button_model->update($button_dto);

        } else {

            throw new Exception('Неправильный вид кнопки: ' . $_POST['button_kind'] );

        }

        echo json_encode(['success' => $new_button]);


    } catch (Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }
}