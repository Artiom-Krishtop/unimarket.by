<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\InlineModel;
use Brainforce\Unibot\Models\MessageTemplateModel;
use Brainforce\Unibot\Models\ReplyModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_GET['bot']) && isset($_GET['user'])) {
    $bot = BotModel::get_bot_by_id($_GET['bot'], $_GET['user']);
}

if (isset($bot) && $bot):

    try {

        $messages = MessageModel::get_for_bot($bot['ID']);
        $data = [];

        foreach ($messages as $key => $message) {
            $messages[$key]['UF_MESSAGE'] = MessageTemplateModel::get_by_id($message['UF_MESSAGES'][0])['UF_MESSAGE'];
        }
        $data['messages'] = $messages;

        if (isset($_GET['button_id']) && isset($_GET['button_kind'])) {
            if ($_GET['button_kind'] == 'reply') {

                $button_model = new ReplyModel();

            } elseif ($_GET['button_kind'] == 'inline'){

                $button_model = new InlineModel();

            } else {

                throw new Exception('Неправильный вид кнопки: ' . $_GET['button_kind']);

            }

            $data['button_kind'] = $_GET['button_kind'];
            $data['button'] = $button_model->get_for_bot($bot['ID'],['*'], ['ID' => $_GET['button_id']])[0];

        }

        echo json_encode(['data' => $data]);

    } catch (Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }

endif;