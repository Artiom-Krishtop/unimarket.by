<?php
/** @global $APPLICATION */
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

use Bitrix\Main\UI\Extension;
use Brainforce\Unibot\Controllers\MessageController;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\InlineModel;
use Brainforce\Unibot\Models\MenuModel;
use Brainforce\Unibot\Models\MessageModel;
use Brainforce\Unibot\Models\MessageTemplateModel;
use Brainforce\Unibot\Models\ReplyModel;
use Brainforce\Unibot\Models\SegmentModel;
use Brainforce\Unibot\Models\UserModel;

CModule::IncludeModule('brainforce.unibot');
Extension::load("ui.vue");

global $USER;

if (isset($_GET['bot'])) {
    $bot_model = new BotModel();
    $bot = $bot_model->get_bot_by_id($_GET['bot'], $USER->GetID());
}

if (isset($bot) && $bot):

    $message_template_model = new MessageTemplateModel();
    $message_model = new MessageModel();
    $inline_buttons_model = new InlineModel();
    $reply_buttons_model = new ReplyModel();
    $menu_model = new MenuModel();
    $user_model = new UserModel();
    $segment_model = new SegmentModel();

    try {
        $messages = $message_model->get_for_bot($bot['ID']);
        $message_templates = $message_template_model->get_for_bot($bot['ID']);

        $inline_buttons = $inline_buttons_model->get_for_bot($bot['ID']);
        $inline_buttons = array_map(function ($item) {
            $item['KIND'] = 'Кнопка сообщений';
            return $item;
        }, $inline_buttons);

        $reply_buttons = $reply_buttons_model->get_for_bot($bot['ID']);
        $reply_buttons = array_map(function ($item) {
            $item['KIND'] = 'Кнопка меню';
            return $item;
        }, $reply_buttons);

        $all_buttons = array_merge($inline_buttons, $reply_buttons);

        $menus = $menu_model->get_for_bot($bot['ID']);

        $users = $user_model->get_for_bot($bot['ID']);

        $segments = $segment_model->get_for_bot($bot['ID']);

    } catch (Exception $e) {
        echo $e->getMessage();
        return;
    }

    $aTabs = [
        [
            'DIV' => "messages_list",
            'TAB' => "Сообщения"
        ],
        [
            "DIV" => "buttons_list",
            "TAB" => "Кнопки"
        ],
        [
            "DIV" => "menu_list",
            "TAB" => "Меню"
        ],
        [
            "DIV" => "users_list",
            "TAB" => "Пользователи"
        ],
        [
            "DIV" => "bot_settings",
            "TAB" => "Настройки"
        ],
    ];

    ?>
    <style>
        .table_wrapper {
            background-color: white;
            padding: 40px;
        }

        .table {
            margin-top: 15px;
            display: table;
            width: 100%;
            border: 1px solid;
            border-color: #d9e0e4 #89979d #919b9d #ebeef0;
        }

        .table--mini {
            width: 40%;
            float: left;
            margin-bottom: 25px;
        }

        .table_head {
            display: table-row-group;
        }

        .table_head__row {
            display: table-row;
        }

        .table_head__cell {
            display: table-cell;
            background-color: #aebbc0;
            background-image: -webkit-linear-gradient(top, #b9c7cd, #aab6b8);
            background-image: linear-gradient(to bottom, #b9c7cd, #aab6b8);
            border: 1px solid;
            border-color: #d9e0e4 #89979d #919b9d #ebeef0;
            font-weight: bold;
            height: 21px;
            vertical-align: middle;
            padding: 6px 0 4px 0;
        }

        .table_head__cell--inner {
            font-size: 13px;
            font-weight: bold;
            min-height: 18px;
            padding: 0 16px 0 16px;
            position: relative;
        }

        .table_body {
            display: table-row-group;
        }

        .table_body__row {
            display: table-row;
        }

        .table_body__row--settings {
            display: flex;
            margin: 10px 0;

        }

        .table_body__row:nth-child(2n - 1) {
            background-color: #F5F9F9;
        }

        .table_body__row:hover {
            background-color: #d3e0e0
        }

        .table_body__cell {
            display: table-cell;
            border: none;
            color: #000;
            font-size: 13px;
            height: 15px;
            padding: 11px 0 10px 16px;
            text-align: left;
            vertical-align: top;
            position: relative;
            min-width: 120px;
            padding-right: 15px;
        }

        .table_body__cell:first-child {
            min-width: 0;
        }

        .table_body__cell--right {
            width: 70%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding-left: 15px;

        }

        .table_body__cell--left {
            width: 150px;
            display: flex;
            justify-content: right;
            align-items: center;
            padding-right: 15px;
            font-weight: bold;
        }

        .table_body__cell--error {
            font-size: 9px;
            color: red;
        }

        .table_body__cell--file {

        }

        select {
            min-width: 300px;
        }

        .remove_item_button {
            width: 31px;
            cursor: pointer;
        }

        .menu_header {
            display: flex;
            align-items: center;
        }

        .menu_header h2 {
            margin-right: 25px;
        }

        .menu_row {
            width: 700px;
            text-align: center;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid black;
        }

        .menu_cell {
            width: 100%;
        }

        .menu_row:first-child {
            border-top: 1px solid black;
        }

        .menu_buttons_divider {
            width: 1px;
            height: 35px;
            background-color: black;
        }

        .form {
            width: 45%;
            background-color: #aebbc0;
            float: left;
            margin-left: 50px;
            margin-bottom: 25px;
            margin-top: 15px;
            border-radius: 15px;
            background-image: -webkit-linear-gradient(top, #b9c7cd, #aab6b8);
            background-image: linear-gradient(to bottom, #b9c7cd, #aab6b8);
            border: 1px solid;
            border-color: #d9e0e4 #89979d #919b9d #ebeef0;
        }

        .form_inner {
            flex-direction: column;
            display: flex;
            min-height: 250px;
            align-items: center;
            justify-content: center;
        }

        .form_title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 24px;
        }

        .form_inputs__item {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }

        .form_inputs__title {
            margin-right: 7px;
            font-size: 13px;
            font-weight: bold;
        }

        .id_cell {
            width: 35px;
        }

        .remove_cell {
            width: 35px;
            cursor: pointer;
        }
    </style>

    <?php
    $tabControl = new CAdminTabControl("tabControl", $aTabs);
    $tabControl->Begin();

    $tabControl->BeginNextTab(); ?>

    <div class="table_wrapper">
        <input type="button" value="Добавить шаблон" class="add_button"
               onclick="document.location.href = 'unibot_message_template_add.php?bot=<?= $bot['ID'] ?>'">
        <div class="table">
            <div class="table_head">
                <div class="table_head__row">
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            ID
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Сообщение
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Кнопки
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Меню
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Файл
                        </div>
                    </div>
                </div>
            </div>
            <div class="table_body">
                <?php foreach ($message_templates as $message_template): ?>
                    <div class="table_body__row">
                        <div class="table_body__cell">
                            <a href="unibot_message_template_update.php?bot=<?= $_GET['bot'] ?>&message=<?= $message_template['ID'] ?>">
                                <?= $message_template['ID'] ?>
                            </a>
                        </div>
                        <div class="table_body__cell">
                            <?= $message_template['UF_MESSAGE'] ?>
                        </div>

                        <div class="table_body__cell">
                            <?php if (is_array($message_template['UF_BUTTONS'])) {
                                $buttons_str = '';
                                foreach ($message_template['UF_BUTTONS'] as $button) {
                                    $buttons_str .= array_column($inline_buttons, 'UF_TEXT', "ID")[$button] . "<hr> ";
                                }
                                echo $buttons_str;
                            }
                            ?>
                        </div>
                        <div class="table_body__cell">
                            <?php if ($message_template['UF_MENU']) {
                                echo array_column($menus, 'UF_NAME', 'ID')[$message_template['UF_MENU']];
                            } ?>
                        </div>
                        <div class="table_body__cell  table_body__cell--file">
                            <?php

                            if ($message_template['UF_FILE']) {
                                $file_array = CFile::GetFileArray($message_template['UF_FILE']);
                                if (CFile::IsImage($file_array['ORIGINAL_NAME'])) {
                                    echo '<img width="200px" src="' . $file_array['SRC'] . '" alt="">';
                                } else {
                                    echo $file_array['ORIGINAL_NAME'];
                                }
                            }

                            ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

    <div class="table_wrapper">
        <input type="button" value="Добавить сообщение" class="add_button"
               onclick="document.location.href = 'unibot_message_add.php?bot=<?= $bot['ID'] ?>'">
        <div class="table">
            <div class="table_head">
                <div class="table_head__row">
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            ID
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Сообщение
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Команда
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Сегменты
                        </div>
                    </div>
                </div>
            </div>
            <div class="table_body">
                <?php foreach ($messages as $message): ?>
                    <div class="table_body__row">
                        <div class="table_body__cell">
                            <a href="unibot_message_update.php?bot=<?= $_GET['bot'] ?>&message=<?= $message['ID'] ?>">
                                <?= $message['ID'] ?>
                            </a>

                        </div>
                        <div class="table_body__cell">
                            <?php

                            $cur_message_templates = MessageController::get_templates($message['ID']);

                            $messages_str = '';

                            foreach ($cur_message_templates as $key => $template) {
                                $messages_str .= "<b>Сообщение " . ($key + 1) . "</b> [" . $template['ID'] . "]<br>";

                                if (strlen($template['UF_MESSAGE']) > 200) {
                                    $messages_str .= "<div class='message_template--short'>" . substr($template['UF_MESSAGE'], 0, 197) . "...</div>";
                                } else {
                                    $messages_str .= "<div class='message_template--short'>" . $template['UF_MESSAGE'] . "</div>";
                                }

                                if ($key < count($cur_message_templates) - 1) {
                                    $messages_str .= "<hr>";
                                }

                            }

                            echo $messages_str;

                            ?>
                        </div>
                        <div class="table_body__cell">
                            <?= $message['UF_COMMAND'] ?>
                        </div>
                        <div class="table_body__cell">

                            <?php if (!$message['UF_SEGMENTS']): ?>
                                Для всех
                            <?php else:
                                $segments_str = "";
                                foreach ($message['UF_SEGMENTS'] as $segment_id) {
                                    $segments_str .= array_column($segments, 'UF_NAME', 'ID')[$segment_id] . "<br>";
                                }
                                echo $segments_str;
                                ?>

                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php $tabControl->BeginNextTab(); ?>

    <div class="table_wrapper">
        <input type="button" value="Добавить кнопку" class="add_button"
               onclick="document.location.href = 'unibot_button_add.php?bot=<?= $bot['ID'] ?>'">
        <div class="table">
            <div class="table_head">
                <div class="table_head__row">
                    <div class="table_head__cell id_cell">
                        <div class="table_head__cell--inner">
                            ID
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Текст
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Тип
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Описание
                        </div>
                    </div>
                    <div class="table_head__cell remove_item_button">
                        <div class="table_head__cell--inner ">

                        </div>
                    </div>
                </div>
            </div>
            <div class="table_body">
                <?php foreach ($all_buttons as $button): ?>
                    <div class="table_body__row">
                        <div class="table_body__cell">
                            <a href="unibot_button_update.php?bot=<?= $bot['ID'] ?>&button_id=<?= $button['ID'] ?>&button_kind=<?= $button['KIND'] == 'Кнопка сообщений' ? 'inline' : 'reply' ?>">
                                <?= $button['ID'] ?>
                            </a>

                        </div>
                        <div class="table_body__cell">
                            <?= $button['UF_TEXT'] ?>
                        </div>
                        <div class="table_body__cell">
                            <?= $button['KIND'] ?>
                        </div>
                        <div class="table_body__cell">
                            <?= $button['UF_DESCRIPTION'] ?>
                        </div>
                        <div class="table_body__cell remove_item_button">
                            &#10006;
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

    <?php $tabControl->BeginNextTab(); ?>

    <div class="table_wrapper">
        <input type="button" value="Добавить меню" class="add_button"
               onclick="document.location.href = 'unibot_menu_add.php?bot=<?= $bot['ID'] ?>'">
        <?php foreach ($menus as $menu): ?>
            <div class="menu_header">
                <h2>Меню <?= $menu['UF_NAME'] ?></h2>
                <input type="button" value="Редактировать"
                       onclick="document.location.href = 'unibot_menu_update.php?bot=<?= $bot['ID'] ?>&menu=<?= $menu['ID'] ?>'"
                >
            </div>

            <div class="menu_wrapper">
                <?php

                unset($menu['ID']);
                unset($menu['UF_NAME']);
                unset($menu['UF_BOT_ID']);

                foreach ($menu as $row):
                    if (is_array($row)) :
                        ?>
                        <div class="menu_row">
                            <?php foreach ($row as $cell): ?>
                                <div class="menu_buttons_divider"></div>
                                <div class="menu_cell">
                                    <?= array_column($reply_buttons, 'UF_TEXT', 'ID')[$cell] ?>
                                </div>
                            <?php endforeach; ?>
                            <div class="menu_buttons_divider"></div>
                        </div>
                    <?php
                    endif;
                endforeach; ?>
            </div>

        <?php endforeach; ?>
    </div>

    <?php $tabControl->BeginNextTab(); ?>

    <div class="table_wrapper" id="segments">

        <div class="table table--mini">
            <div class="table_head">
                <div class="table_head__row">
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            ID
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Название
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Публичный
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">

                        </div>
                    </div>
                </div>
            </div>
            <div class="table_body" id="segments_list">

                <div class="table_body__row" v-for="segment in segments">
                    <div class="table_body__cell">
                        {{ segment.ID }}
                    </div>
                    <div class="table_body__cell">
                        {{ segment.UF_NAME }}
                    </div>
                    <div class="table_body__cell">
                        {{ segment.UF_PUBLIC === "1" ? "Да" : "Нет" }}
                    </div>
                    <div class="table_body__cell remove_cell" v-on:click="remove_segment(segment.ID)">
                        &#10006;
                    </div>
                </div>

            </div>
        </div>

        <div class="form" id="add_segment">
            <div class="form_inner">
                <div class="form_title">
                    Новый сегмент
                </div>
                <div class="form_inputs">
                    <div class="form_inputs__item">
                        <span class="form_inputs__title">Название</span>
                        <input type="text" v-model="segment_name">
                    </div>
                    <div class="form_inputs__item">
                        <span class="form_inputs__title">Публичный</span>
                        <input type="checkbox" v-model="segment_public">
                    </div>
                </div>
                <div class="form_submit">
                    <input type="button" value="Добавить сегмент" v-on:click="add_segment">
                </div>
            </div>
        </div>

    </div>

    <script>
        const add_button = BX.Vue.create({

            el: '#segments',

            data: {
                segment_name: '',
                segment_public: true,
                segments: []
            },

            methods: {

                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                get: async function (url) {
                    const response = await fetch(url, {
                        method: 'GET',
                    })
                    return response.json();
                },

                add_segment: function () {
                    let data = new FormData
                    data.append('segment_name', this.segment_name)
                    data.append('segment_public', this.segment_public)
                    data.append('bot', <?=$bot['ID']?>)
                    data.append('user', <?=$USER->GetID()?>)

                    this.post("/bitrix/admin/unibot_ajax_segment_add.php", data)
                        .then((data) => {
                            this.new_segment = data.data
                        })
                        .finally(() => {
                            this.get_segments()
                        })
                },

                get_segments: function () {
                    this.get("/bitrix/admin/unibot_ajax_segment.php?bot="
                        + <?=$_GET['bot']?> + '&user=' + <?=$USER->GetID()?>)
                        .then((data) => {
                            this.segments = data.data
                            console.log(data)
                        })
                },

                remove_segment: function (id) {
                    let data = new FormData;
                    data.append('segment', id)
                    data.append('bot', <?=$bot['ID']?>)
                    data.append('user', <?=$USER->GetID()?>)
                    this.post("/bitrix/admin/unibot_ajax_segment_remove.php", data)
                        .then((data) => {
                            this.get_segments()
                            console.log(data.data)
                        })

                }
            },

            created: function () {
                this.get_segments()
            }
        })
    </script>

    <div class="table_wrapper">
        <div class="table">
            <div class="table_head">
                <div class="table_head__row">
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            ID
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Имя
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Имя пользователя
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Телефон
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            ID чата
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Сегменты
                        </div>
                    </div>
                    <div class="table_head__cell">
                        <div class="table_head__cell--inner">
                            Дата регистрации
                        </div>
                    </div>
                </div>
            </div>
            <div class="table_body">
                <?php foreach ($users as $user): ?>
                    <div class="table_body__row">
                        <div class="table_body__cell">
                            <a href="unibot_user_update.php?bot=<?= $_GET['bot'] ?>&tg_user=<?= $user['ID'] ?>">
                                <?= $user['ID'] ?>
                            </a>
                        </div>
                        <div class="table_body__cell">
                            <?= $user['UF_NAME'] ?>
                        </div>
                        <div class="table_body__cell">
                            <?= $user['UF_USERNAME'] ?>
                        </div>
                        <div class="table_body__cell">
                            <?= $user['UF_PHONE'] ?>
                        </div>
                        <div class="table_body__cell">
                            <?= $user['UF_CHAT_ID'] ?>
                        </div>
                        <div class="table_body__cell">
                            <?php
                            if ($user['UF_SEGMENT']) {
                                if (is_array($user['UF_SEGMENT'])) {
                                    $segments_str = '';
                                    foreach ($user['UF_SEGMENT'] as $segment) {
                                        $segments_str .= array_column($segments, 'UF_NAME', 'ID')[$segment] . "<br>";
                                    }
                                    echo $segments_str;
                                }
                            }
                            ?>
                        </div>
                        <div class="table_body__cell">
                            <?= $user['UF_DATE_REGISTRATION'] ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php $tabControl->BeginNextTab(); ?>


    <div class="table_wrapper" id="bot_settings">
        <div class="table">
            <div class="table_body">
                <div class="table_body__row--settings">
                    <div class="table_body__cell--left">Имя бота</div>
                    <div class="table_body__cell--right">
                        <input type="text" v-model="bot_name">
                        <div class="table_body__cell--error" v-if="name_match_error">Недопустимые символы, разрешенные
                            0-9 a-z A-z : _ - .
                        </div>
                    </div>

                </div>
                <div class="table_body__row--settings">
                    <div class="table_body__cell--left">Токен</div>
                    <div class="table_body__cell--right">
                        <input type="text" v-model="bot_token">
                        <div class="table_body__cell--error" v-if="token_match_error">Недопустимые символы, разрешенные
                            0-9 a-z A-z : _ - .
                        </div>
                    </div>
                </div>
                <div class="table_body__row--settings">
                    <div class="table_body__cell--left">
                        <input type="button" value="Обновить" v-on:click="update_bot">
                    </div>
                    <div class="table_body__cell--right">
                        <!--                        <input type="button" value="Проверить" onclick="alert('ВСЕ ОЧЕНЬ ХУЕВО!!!!!!')" style="height: 500px">-->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $tabControl->End(); ?>

    <script>

        const bot_settings = BX.Vue.create({

            el: '#bot_settings',

            data: {
                bot_name: '',
                bot_old_name: '',
                bot_token: '',
                bot_old_token: '',
                bot_operator: '',

                bot_users_list: [],

                name_match_error: false,
                token_match_error: false,
            },

            methods: {

                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                get: async function (url) {
                    const response = await fetch(url, {
                        method: 'GET',
                    })
                    return response.json();
                },

                update_bot: function () {

                    if (!this.name_match_error && !this.token_match_error) {
                        let data = new FormData
                        data.append('bot_name', this.bot_name)
                        data.append('bot_old_name', this.bot_old_name)
                        data.append('bot_token', this.bot_token)
                        data.append('bot', <?=$_GET['bot']?>)
                        data.append('user', <?=$USER->GetID()?>)
                        this.post('/bitrix/admin/unibot_ajax_bot_update.php', data)
                            .then((data) => {
                                console.log(data)
                                if (data.success) {
                                    this.get_bot_data()
                                }
                            })
                    } else {
                        console.log('Недопустимые символы')
                    }

                },

                get_bot_data: function () {
                    this.get('/bitrix/admin/unibot_ajax_settings.php?bot=' + <?=$_GET['bot']?> + '&user=<?=$USER->GetID()?>')
                        .then((data) => {
                            console.log(data)
                            this.bot_name = data.bot.UF_NAME
                            this.bot_old_name = data.bot.UF_NAME
                            this.bot_token = data.bot.UF_API_KEY
                            this.bot_users_list = data.users
                        })
                },

                check_fields: function (field) {
                    return field.match(/^([0-9a-zA-Z:_\-.]+)$/)
                }

            },

            created: function () {
                this.get_bot_data()
            },

            watch: {
                bot_name: function () {
                    this.name_match_error = !this.check_fields(this.bot_name);
                },

                bot_token: function () {
                    this.token_match_error = !this.check_fields(this.bot_token);
                }
            }

        })

    </script>

<?php
endif;

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php'; ?>
