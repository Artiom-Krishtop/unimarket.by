<?php

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MenuModel;
use Brainforce\Unibot\Models\ReplyModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_GET['bot']) && isset($_GET['user'])) {
    $bot = BotModel::get_bot_by_id($_GET['bot'], $_GET['user']);
}

if (isset($bot) && $bot):

    try {

        $data = [];
        $data['reply_buttons'] = ReplyModel::get_for_bot($bot['ID']);

        if (isset($_GET['menu'])) {
            $menu = MenuModel::get_for_bot($bot['ID'],['*'], ['ID' => $_GET['menu']])[0];
            $data['menu'] = $menu;
        }

        echo json_encode(['data' => $data]);

    } catch (Exception $e) {

        echo json_encode(['error' => $e->getMessage()]) ;

    }

endif;