<?php
/** @global $APPLICATION */

use Brainforce\Unibot\Models\BotModel;
use Bitrix\Main\UI\Extension;

require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_before.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_admin_after.php';

CModule::IncludeModule('brainforce.unibot');
Extension::load("ui.vue");

global $USER;

if (isset($_GET['bot'])) {
    $bot = BotModel::get_bot_by_id($_GET['bot'], $USER->GetID());
}

if (isset($bot) && $bot): ?>

    <style>
        .table_wrapper {
            background-color: white;
            padding: 40px;
            width: 80%;
        }

        .table_title {
            font-size: 26px;
            margin-bottom: 40px;
        }

        .table {
            display: flex;
            flex-direction: column;
        }

        .table_row {

            display: flex;
            margin-bottom: 20px;
        }

        .table_cell {
            min-height: 40px;
            width: 25%;
        }

        select {
            max-width: 95%;
        }
    </style>

    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/preloader.css">
    <link rel="stylesheet" href="/bitrix/css/brainforce.unibot/alert.css">
    <div class="table_wrapper" id="add_menu">
        <input type="button" value="Назад" onclick="location.href = 'unibot_admin.php?bot=<?=$_GET['bot']?>'" style="margin-bottom: 15px">

        <div class="alert_message alert_message--success" v-if="success">
            Пользователь обновлен
        </div>

        <div class="alert_message alert_message--error" v-if="error">
            Пользователь не обновлен
        </div>

        <div class="preloader" v-if="is_fetching">
            <div class="lds-dual-ring"></div>
        </div>
        <div class="table_title">
            Добавление меню
        </div>
        <div class="table">
            <div class="table_row">
                <label>
                    Название
                    <input type="text" v-model="menu_title">
                </label>
            </div>
            <div class="table_row">
                <div class="table_cell">Колонка 1</div>
                <div class="table_cell">Колонка 2</div>
                <div class="table_cell">Колонка 3</div>
                <div class="table_cell">Колонка 4</div>
            </div>
            <div class="table_row" v-for="(row, row_index) in rows">
                <div class="table_cell" v-for="(cell, cell_index) in row">
                    <select v-model="rows[row_index][cell_index]">
                        <option v-for="button in buttons" v-bind:value="button.ID">{{ button.UF_TEXT }}</option>
                    </select>
                </div>
            </div>
            <div class="table_row">
                <div class="table_cell">
                    <input type="button" value="Отправить" v-on:click="add_menu">
                </div>
            </div>
        </div>
    </div>

    <script>
        const add_message = BX.Vue.create({

            el: '#add_menu',

            data: {

                menu_title: '',
                rows: [
                    ['', '', '', ''],
                    ['', '', '', ''],
                    ['', '', '', ''],
                ],

                buttons: [],
                menu: [],
                is_fetching: true,
                success: false,
                error: false
            },

            methods: {

                post: async function (url, data) {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: data
                    })
                    return response.json();
                },

                get: async function (url) {
                    const response = await fetch(url, {
                        method: 'GET',
                    })
                    return response.json();
                },

                add_menu: function () {
                    this.is_fetching = true
                    let data = new FormData;

                    this.rows.forEach((row, index) => {

                        row.forEach((cell) => {

                            if (cell !== "") {
                                data.append('UF_ROW_' + (index + 1) + "[]", cell)
                            }

                        })
                    })

                    data.append('UF_NAME', this.menu_title)
                    data.append('user', <?=$USER->GetID()?>)
                    data.append('bot', <?=$_GET['bot']?>)
                    data.append('menu', <?=$_GET['menu']?>)

                    this.post("/bitrix/admin/unibot_ajax_menu_update.php", data)

                        .then((data) => {
                            if (data.error) {

                                this.error = true
                                this.success = false

                            } else {

                                this.error = false
                                this.success = true

                            }

                            console.log(data)
                        })
                        .finally(() => {
                            this.is_fetching = false
                        })

                }

            },

            created: function () {

                this.get('/bitrix/admin/unibot_ajax_menu.php?bot='
                    + <?=$_GET['bot']?> + '&user=' + <?=$USER->GetID()?> + '&menu=' + <?=$_GET['menu']?>)
                    .then((data => {

                        console.log(data)

                        this.menu = data.data.menu;
                        this.menu_title = data.data.menu.UF_NAME

                        if (Array.isArray(this.menu.UF_ROW_1)) {
                            let row_1 = this.menu.UF_ROW_1.reverse();
                            row_1.forEach((cell) => {
                                this.rows[0].unshift(cell)
                                this.rows[0].pop()
                            })
                        }

                        if (Array.isArray(this.menu.UF_ROW_2)) {
                            let row_2 = this.menu.UF_ROW_2.reverse();
                            row_2.forEach((cell) => {
                                this.rows[1].unshift(cell)
                                this.rows[1].pop()
                            })
                        }

                        if (Array.isArray(this.menu.UF_ROW_3)) {
                            let row_3 = this.menu.UF_ROW_3.reverse();
                            row_3.forEach((cell) => {
                                this.rows[2].unshift(cell)
                                this.rows[2].pop()
                            })
                        }

                        this.buttons = data.data.reply_buttons
                        this.buttons.unshift({
                            ID: "",
                            UF_TEXT: ('Не выбрано')
                        })
                    })).finally(() => {
                            this.is_fetching = false
                        })

            }
        })
    </script>

<?php

endif;

require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_admin.php'; ?>
