<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Bitrix\Main\DB\SqlQueryException;
use Brainforce\Unibot\Dto\MenuDto;
use Brainforce\Unibot\Models\BotModel;
use Brainforce\Unibot\Models\MenuModel;

CModule::IncludeModule('brainforce.unibot');

if (isset($_POST['bot']) && isset($_POST['user'])) {
    $bot = BotModel::get_bot_by_id($_POST['bot'], $_POST['user']);
}

if (isset($bot) && $bot) {

    try {
        $menu_dto = new MenuDto();
        $menu_dto->name = $_POST['UF_NAME'];
        $menu_dto->bot_id = $_POST['bot'];

        if (isset($_POST['UF_ROW_1'])) {
            $menu_dto->row_1 = $_POST['UF_ROW_1'];
        }
        if (isset($_POST['UF_ROW_2'])) {
            $menu_dto->row_2 = $_POST['UF_ROW_2'];
        }
        if (isset($_POST['UF_ROW_3'])) {
            $menu_dto->row_3 = $_POST['UF_ROW_3'];
        }
        $new_menu = MenuModel::add($menu_dto);

        echo json_encode(['success' => $new_menu]);

    } catch (SqlQueryException | Exception $e) {

        echo json_encode(['error' => $e->getMessage()]);

    }

}