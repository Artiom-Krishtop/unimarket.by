<?php
$MESS['BRAINFORCE_UNIBOT_NAME'] = 'UNI-bot: универсальный Telegram-bot для вашего сайта';
$MESS['BRAINFORCE_UNIBOT_MODULE_DESCRIPTION'] = 'Управление вашим Telegram ботом через админку сайта.';
$MESS['BRAINFORCE_UNIBOT_PARTNER_NAME'] = 'BrainForce';
$MESS["BRAINFORCE_UNIBOT_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста, обновите систему.";
$MESS["BRAINFORCE_UNIBOT_PARTNER_URI"] = "https://brainforce.by";