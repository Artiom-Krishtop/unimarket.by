<?
$arModuleVersion = array(
    "VERSION" => "3.0.6",
    "VERSION_DATE" => "2020-01-23 13:01:00"
);
