<?
$MESS["COMPONENT_BEGATEWAY_FAIL_TITLE"] = "ТРАНЗАКЦИЯ БЫЛА ОТКЛОНЕНА";
$MESS["COMPONENT_BEGATEWAY_FAIL_ORDER_DESC"] = "Описание:";
$MESS["COMPONENT_BEGATEWAY_FAIL_AMOUNT"] = "Сумма:";
$MESS["COMPONENT_BEGATEWAY_FAIL_UID"] = "UID транзакции:";
$MESS["COMPONENT_BEGATEWAY_FAIL_REJECTION_REASON"] = "Причина отказа:";
$MESS["COMPONENT_BEGATEWAY_FAIL_REJECTION_DESC"] = "Платеж был отклонен вашим банком по причине указанной выше.
Пожалуйста, примите во внимание, что мы показываем вам причину в том виде, в котором ее сообщает ваш банк, и иногда причина может быть не очень понятна.
Мы рекомендуем вам связаться с вашим банком и попросить разрешить для вашей карты платеж на <span>#amount#</span> <span>#currency#</span> в пользу продавца с идентификатором <span>#bdesc#</span>.
После того, как банк подтвердит разрешение, попробуйте сделать оплату еще раз.";
