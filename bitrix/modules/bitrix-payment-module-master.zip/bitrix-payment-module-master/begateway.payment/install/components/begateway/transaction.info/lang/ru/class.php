<?
$MESS["COMPONENT_BEGATEWAY_NO_TRANS_INFO"]     = "Информация по транзакции не может быть получена";
$MESS["COMPONENT_BEGATEWAY_NO_TOKEN_ACCESS"]   = "Токен не принадлежит данному пользователю";
$MESS["COMPONENT_BEGATEWAY_NO_UID_TOKEN_ACCESS"] = "UID оплаты не совпадает с токеном оплаты";
$MESS["COMPONENT_BEGATEWAY_FAIL_TOKEN_QUERY"]  = "Ошибка получения информации по транзакции";
$MESS["COMPONENT_BEGATEWAY_WRONG_ORDER_ID"]    = "Неизвестный идентификатор заказа";
$MESS["COMPONENT_BEGATEWAY_WRONG_PAYMENT_ID"]  = "Неизвестный идентификатор оплаты";
$MESS["COMPONENT_BEGATEWAY_WRONG_TRACKING_ID"] = "Неизвестный токен платежа";
$MESS['COMPONENT_BEGATEWAY_SALE_MODULE_NOT_INSTALL']="Модуль Интернет-магазин не установлен.";
