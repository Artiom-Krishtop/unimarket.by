<?
$MESS["COMPONENT_BEGATEWAY_SUCCESS_TITLE"] = "ОПЛАТА ПРОШЛА УСПЕШНО";
$MESS["COMPONENT_BEGATEWAY_SUCCESS_ORDER_DESC"] = "Описание:";
$MESS["COMPONENT_BEGATEWAY_SUCCESS_AMOUNT"] = "Сумма:";
$MESS["COMPONENT_BEGATEWAY_SUCCESS_UID"] = "UID транзакции:";
$MESS["COMPONENT_BEGATEWAY_SUCCESS_AUTH_CODE"] = "Коде авторизации:";
$MESS["COMPONENT_BEGATEWAY_SUCCESS_AUTH_NUMBER"] = "Номер авторизации в системе обслуживания банка:";
$MESS["COMPONENT_BEGATEWAY_SUCCESS_BILLING_DESCRIPTOR"] = "Вы можете найти этот платёж в Вашей банковской выписке по идентификатору:";
